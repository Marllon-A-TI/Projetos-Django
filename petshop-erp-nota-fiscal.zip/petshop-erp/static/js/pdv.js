(function () {
  "use strict";

  // Mostra recebido, falta e troco na tela de venda do PDV. O total vem do
  // próprio vendas.js (elemento #total-venda); aqui só lemos o texto.
  var totalTela = document.getElementById("total-venda");
  var recebidoTela = document.getElementById("total-recebido");
  var rotulo = document.getElementById("rotulo-diferenca");
  var diferencaTela = document.getElementById("valor-diferenca");
  var formulario = document.getElementById("form-venda");

  if (!totalTela || !recebidoTela || !formulario) {
    return;
  }

  var formatoMoeda = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  });

  function numero(texto) {
    var limpo = String(texto).replace(/[^0-9,]/g, "").replace(",", ".");
    var valor = parseFloat(limpo);
    return isNaN(valor) ? 0 : valor;
  }

  function atualizar() {
    var total = numero(totalTela.textContent);
    var recebido = 0;
    formulario
      .querySelectorAll("input[name='DINHEIRO'], input[name='PIX'], input[name='DEBITO'], input[name='CREDITO'], input[name='OUTROS']")
      .forEach(function (campo) {
        var valor = parseFloat(String(campo.value).replace(",", "."));
        recebido += isNaN(valor) ? 0 : valor;
      });
    var diferenca = Math.round((recebido - total) * 100) / 100;
    recebidoTela.textContent = formatoMoeda.format(recebido);
    if (diferenca < 0) {
      rotulo.textContent = "Falta";
      diferencaTela.textContent = formatoMoeda.format(-diferenca);
    } else {
      rotulo.textContent = "Troco";
      diferencaTela.textContent = formatoMoeda.format(diferenca);
    }
  }

  formulario.addEventListener("input", atualizar);
  new MutationObserver(atualizar).observe(totalTela, {
    childList: true,
    characterData: true,
    subtree: true,
  });
  atualizar();
})();
