document.addEventListener("DOMContentLoaded", function () {
  // Pede confirmação antes de enviar formulários marcados com data-confirm.
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (evento) {
      if (!window.confirm(form.dataset.confirm)) {
        evento.preventDefault();
      }
    });
  });

  // Evita envio duplicado (duplo clique) em formulários marcados.
  document
    .querySelectorAll("form[data-evitar-duplo-envio]")
    .forEach(function (form) {
      form.addEventListener("submit", function (evento) {
        if (evento.defaultPrevented) {
          return;
        }
        form.querySelectorAll("button[type=submit]").forEach(function (botao) {
          botao.disabled = true;
        });
      });
    });

  // Botões com data-imprimir abrem a impressão do navegador.
  document.querySelectorAll("[data-imprimir]").forEach(function (botao) {
    botao.addEventListener("click", function () {
      window.print();
    });
  });

  // Seleção de vários produtos na lista (ações em lote).
  document.querySelectorAll("form[data-lote]").forEach(function (form) {
    var itens = Array.prototype.slice.call(
      form.querySelectorAll("input[data-lote-item]")
    );
    var pagina = form.querySelector("[data-lote-pagina]");
    var todosFiltro = form.querySelector("[data-lote-todos-filtro]");
    var botoes = form.querySelectorAll("[data-lote-acao]");
    var contador = form.querySelector("[data-lote-contador]");

    function atualizar() {
      var marcados = itens.filter(function (i) { return i.checked; }).length;
      var todos = todosFiltro && todosFiltro.checked;
      if (pagina) {
        pagina.checked = itens.length > 0 && marcados === itens.length;
        pagina.indeterminate = marcados > 0 && marcados < itens.length;
      }
      if (todos) {
        contador.textContent = "Todos os " + form.dataset.total + " produtos da busca selecionados";
      } else if (marcados === 0) {
        contador.textContent = "Nenhum produto selecionado";
      } else {
        contador.textContent = marcados + " selecionado(s)";
      }
      botoes.forEach(function (b) { b.disabled = !(marcados > 0 || todos); });
    }

    if (pagina) {
      pagina.addEventListener("change", function () {
        itens.forEach(function (i) { i.checked = pagina.checked; });
        if (!pagina.checked && todosFiltro) { todosFiltro.checked = false; }
        atualizar();
      });
    }
    if (todosFiltro) {
      todosFiltro.addEventListener("change", function () {
        itens.forEach(function (i) { i.checked = todosFiltro.checked; });
        atualizar();
      });
    }
    itens.forEach(function (i) {
      i.addEventListener("change", function () {
        if (!i.checked && todosFiltro) { todosFiltro.checked = false; }
        atualizar();
      });
    });
    atualizar();
  });

  // Mensagens de sucesso somem sozinhas depois de alguns segundos.
  document.querySelectorAll(".alert-success").forEach(function (alerta) {
    window.setTimeout(function () {
      if (window.bootstrap && document.body.contains(alerta)) {
        window.bootstrap.Alert.getOrCreateInstance(alerta).close();
      }
    }, 6000);
  });
});