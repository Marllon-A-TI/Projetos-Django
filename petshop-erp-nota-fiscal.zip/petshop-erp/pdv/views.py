from django.conf import settings
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View
from django.views.generic import DetailView, ListView

from core.mixins import VendedorOuAdministradorRequiredMixin, eh_administrador
from core.utils import moeda
from logs.models import LogAcao
from logs.utils import registrar_acao
from vendas.forms import ItemVendaFormSet

from . import services
from .forms import (
    AbrirCaixaForm,
    FecharCaixaForm,
    MovimentoCaixaForm,
    PagamentoForm,
)
from .models import SessaoCaixa


def _mensagem(erro):
    return " ".join(erro.messages)


def _imprimir_cupom_automatico(request, venda):
    """Imprime o cupom da venda do PDV. Nunca atrapalha a venda, que já está gravada."""
    if not getattr(settings, "IMPRESSAO_AUTO_PDV", True):
        return
    try:
        from impressao.services import imprimir_venda_pdv_automatico

        trabalho, aviso = imprimir_venda_pdv_automatico(venda, request.user)
        if trabalho is not None:
            registrar_acao(request, LogAcao.Acao.IMPRESSAO,
                           f"{trabalho.titulo}: {trabalho.get_status_display()}")
        if aviso:
            messages.warning(request, aviso)
    except Exception:
        messages.warning(request, "A venda foi registrada, mas o cupom não pôde ser impresso agora.")


def _sessoes_visiveis(usuario):
    """Administrador vê todos os caixas; operador vê só os seus."""
    consulta = SessaoCaixa.objects.select_related("operador", "fechado_por")
    if not eh_administrador(usuario):
        consulta = consulta.filter(operador=usuario)
    return consulta


class PainelCaixaView(VendedorOuAdministradorRequiredMixin, View):
    """Tela inicial do PDV: abrir o caixa ou acompanhar o caixa aberto."""

    def get(self, request):
        sessao = services.sessao_aberta_do(request.user)
        contexto = {"sessao": sessao}
        if sessao:
            contexto.update(
                resumo=services.resumo_sessao(sessao),
                form_movimento=MovimentoCaixaForm(),
                form_fechar=FecharCaixaForm(),
                movimentos=sessao.movimentos.select_related("usuario")[:10],
            )
        else:
            contexto["form_abrir"] = AbrirCaixaForm()
        return render(request, "pdv/painel.html", contexto)


class AbrirCaixaView(VendedorOuAdministradorRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request):
        form = AbrirCaixaForm(request.POST)
        if not form.is_valid():
            messages.error(request, "Confira os dados da abertura do caixa.")
            return redirect("pdv:painel")
        try:
            with transaction.atomic():
                sessao = services.abrir_caixa(
                    operador=request.user,
                    fundo_troco=form.cleaned_data["fundo_troco"],
                    terminal=form.cleaned_data["terminal"],
                )
                registrar_acao(
                    request,
                    LogAcao.Acao.CAIXA,
                    f"Abertura do caixa #{sessao.pk} ({sessao.terminal}), "
                    f"fundo de troco {moeda(sessao.fundo_troco)}",
                )
        except ValidationError as erro:
            messages.error(request, _mensagem(erro))
        else:
            messages.success(request, f"Caixa #{sessao.pk} aberto.")
        return redirect("pdv:painel")


class MovimentoCaixaView(VendedorOuAdministradorRequiredMixin, View):
    """Sangria e suprimento no caixa aberto do próprio usuário."""

    http_method_names = ["post"]

    def post(self, request):
        sessao = services.sessao_aberta_do(request.user)
        if sessao is None:
            messages.error(request, "Abra o caixa antes de fazer sangria ou suprimento.")
            return redirect("pdv:painel")

        form = MovimentoCaixaForm(request.POST)
        if not form.is_valid():
            messages.error(request, "Confira tipo, valor e motivo do movimento.")
            return redirect("pdv:painel")
        try:
            with transaction.atomic():
                movimento = services.registrar_movimento(
                    sessao=sessao, usuario=request.user, **form.cleaned_data
                )
                registrar_acao(
                    request,
                    LogAcao.Acao.CAIXA,
                    f"{movimento.get_tipo_display()} de {moeda(movimento.valor)} "
                    f"no caixa #{sessao.pk}: {movimento.motivo}",
                )
        except ValidationError as erro:
            messages.error(request, _mensagem(erro))
        else:
            messages.success(
                request,
                f"{movimento.get_tipo_display()} de {moeda(movimento.valor)} registrada.",
            )
        return redirect("pdv:painel")


class FecharCaixaView(VendedorOuAdministradorRequiredMixin, View):
    """O dono do caixa fecha o próprio; o administrador pode fechar qualquer um."""

    http_method_names = ["post"]

    def post(self, request, pk):
        sessao = get_object_or_404(_sessoes_visiveis(request.user), pk=pk)
        form = FecharCaixaForm(request.POST)
        if not form.is_valid():
            messages.error(request, "Informe o dinheiro contado na gaveta.")
            return redirect("pdv:painel")
        try:
            with transaction.atomic():
                sessao = services.fechar_caixa(
                    sessao=sessao, usuario=request.user, **form.cleaned_data
                )
                registrar_acao(
                    request,
                    LogAcao.Acao.CAIXA,
                    f"Fechamento do caixa #{sessao.pk}: esperado "
                    f"{moeda(sessao.valor_esperado)}, contado "
                    f"{moeda(sessao.valor_contado)}, diferença "
                    f"{moeda(sessao.diferenca)}",
                )
        except ValidationError as erro:
            messages.error(request, _mensagem(erro))
            return redirect("pdv:painel")
        messages.success(request, f"Caixa #{sessao.pk} fechado.")
        return redirect("pdv:sessao_detail", pk=sessao.pk)


class VendaPdvView(VendedorOuAdministradorRequiredMixin, View):
    """Venda no caixa: mesmos itens da venda comum, mais as formas de pagamento."""

    template_name = "pdv/venda_form.html"

    def get_formset(self, dados=None):
        return ItemVendaFormSet(
            dados,
            form_kwargs={"pode_alterar_preco": eh_administrador(self.request.user)},
        )

    def renderizar(self, request, sessao, formset, form_pagamento):
        return render(
            request,
            self.template_name,
            {
                "sessao": sessao,
                "formset": formset,
                "form_pagamento": form_pagamento,
                "eh_administrador": eh_administrador(request.user),
            },
        )

    def sessao_ou_redirecionar(self, request):
        """(sessao, None) se há caixa aberto; senão (None, redirecionamento)."""
        sessao = services.sessao_aberta_do(request.user)
        if sessao is None:
            messages.warning(request, "Abra o caixa para vender pelo PDV.")
            return None, redirect("pdv:painel")
        return sessao, None

    def get(self, request):
        sessao, desvio = self.sessao_ou_redirecionar(request)
        if desvio:
            return desvio
        return self.renderizar(request, sessao, self.get_formset(), PagamentoForm())

    def post(self, request):
        sessao, desvio = self.sessao_ou_redirecionar(request)
        if desvio:
            return desvio
        formset = self.get_formset(request.POST)
        form_pagamento = PagamentoForm(request.POST)

        if formset.is_valid() and form_pagamento.is_valid():
            itens = formset.itens()
            try:
                with transaction.atomic():
                    venda, troco = services.registrar_venda_pdv(
                        sessao=sessao,
                        operador=request.user,
                        itens=itens,
                        pagamentos=form_pagamento.pagamentos(),
                    )
                    registrar_acao(
                        request,
                        LogAcao.Acao.VENDA,
                        f"Venda #{venda.pk} (caixa #{sessao.pk}): "
                        f"{len(itens)} item(ns), total {moeda(venda.valor_total)}, "
                        f"troco {moeda(troco)}",
                    )
            except ValidationError as erro:
                messages.error(request, _mensagem(erro))
            else:
                texto = f"Venda #{venda.pk} registrada. Total: {moeda(venda.valor_total)}."
                if troco:
                    texto += f" TROCO: {moeda(troco)}."
                messages.success(request, texto)
                _imprimir_cupom_automatico(request, venda)
                return redirect("vendas:detail", pk=venda.pk)

        return self.renderizar(request, sessao, formset, form_pagamento)


class SessaoListView(VendedorOuAdministradorRequiredMixin, ListView):
    template_name = "pdv/sessao_list.html"
    context_object_name = "sessoes"
    paginate_by = 25

    def get_queryset(self):
        return _sessoes_visiveis(self.request.user)

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["eh_administrador"] = eh_administrador(self.request.user)
        return contexto


class SessaoDetailView(VendedorOuAdministradorRequiredMixin, DetailView):
    template_name = "pdv/sessao_detail.html"
    context_object_name = "sessao"

    def get_queryset(self):
        return _sessoes_visiveis(self.request.user)

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        sessao = self.object
        contexto["resumo"] = services.resumo_sessao(sessao)
        contexto["movimentos"] = sessao.movimentos.select_related("usuario")
        contexto["vendas_pdv"] = sessao.vendas_pdv.select_related("venda")
        return contexto
