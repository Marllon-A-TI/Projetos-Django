from decimal import Decimal

from django import forms

from core.forms import BootstrapFormMixin, aplicar_classe_bootstrap

from .models import TERMINAL_PADRAO, FormaPagamento, MovimentoCaixa

VALOR = {"max_digits": 12, "decimal_places": 2, "min_value": Decimal("0")}


class AbrirCaixaForm(BootstrapFormMixin, forms.Form):
    terminal = forms.CharField(label="Terminal", max_length=30, initial=TERMINAL_PADRAO)
    fundo_troco = forms.DecimalField(
        label="Fundo de troco (R$)", initial=Decimal("0.00"), **VALOR
    )


class MovimentoCaixaForm(BootstrapFormMixin, forms.Form):
    tipo = forms.ChoiceField(label="Tipo", choices=MovimentoCaixa.Tipo.choices)
    valor = forms.DecimalField(
        label="Valor (R$)", max_digits=12, decimal_places=2, min_value=Decimal("0.01")
    )
    motivo = forms.CharField(label="Motivo", max_length=200)


class FecharCaixaForm(BootstrapFormMixin, forms.Form):
    valor_contado = forms.DecimalField(label="Dinheiro contado na gaveta (R$)", **VALOR)
    observacao = forms.CharField(
        label="Observação", required=False, widget=forms.Textarea(attrs={"rows": 2})
    )


class PagamentoForm(BootstrapFormMixin, forms.Form):
    """Um campo por forma de pagamento; o que ficar em branco vale zero."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for forma, rotulo in FormaPagamento.choices:
            self.fields[forma] = forms.DecimalField(
                label=rotulo, required=False, **VALOR
            )
            aplicar_classe_bootstrap(self.fields[forma].widget)

    def pagamentos(self):
        """{forma: valor} só com o que foi preenchido. Depois de is_valid()."""
        return {
            forma: valor
            for forma, valor in self.cleaned_data.items()
            if valor
        }
