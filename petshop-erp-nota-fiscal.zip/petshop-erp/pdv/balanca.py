"""
Etiqueta de balança (EAN-13 que começa com "2"): código do produto + peso ou valor.

Formato configurável por loja (as balanças variam), padrão mais comum:
    2 CCCCCC VVVVV D     prefixo(1) + código(6) + valor(5) + dígito verificador(1)
 - modo PESO : VVVVV = peso em gramas  (12345 = 12,345 kg)
 - modo PRECO: VVVVV = valor em centavos (o peso sai do preço cadastrado)

Sem Django: o mesmo algoritmo existe em static/js/vendas.js (o leitor roda no navegador).
"""

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal


@dataclass(frozen=True)
class FormatoBalanca:
    prefixo: str = "2"
    digitos_codigo: int = 6
    digitos_valor: int = 5
    modo: str = "PESO"  # ou "PRECO"


def dv_ean13(doze):
    soma = sum(int(c) * (3 if i % 2 else 1) for i, c in enumerate(doze))
    return (10 - soma % 10) % 10


def ean13_valido(codigo):
    return len(codigo) == 13 and codigo.isdigit() and dv_ean13(codigo[:12]) == int(codigo[12])


def interpretar(codigo, formato=FormatoBalanca()):
    """
    Devolve (codigo_do_produto, valor_inteiro) ou None se não for etiqueta de balança.
    `valor_inteiro` são gramas (PESO) ou centavos (PRECO).
    """
    codigo = (codigo or "").strip()
    f = formato
    if not ean13_valido(codigo) or not codigo.startswith(f.prefixo):
        return None
    if len(f.prefixo) + f.digitos_codigo + f.digitos_valor != 12:
        return None
    inicio = len(f.prefixo)
    produto = codigo[inicio:inicio + f.digitos_codigo]
    valor = int(codigo[inicio + f.digitos_codigo:12])
    return produto, valor


def quantidade_da_etiqueta(valor, formato, preco_unitario=None):
    """Quantidade (kg) a partir do valor lido. PRECO exige o preço por kg do produto."""
    if formato.modo == "PESO":
        return (Decimal(valor) / 1000).quantize(Decimal("0.001"))
    if not preco_unitario:
        raise ValueError("Produto sem preço: não dá para calcular o peso pelo valor da etiqueta.")
    return (Decimal(valor) / 100 / Decimal(preco_unitario)).quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
