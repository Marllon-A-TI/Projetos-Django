"""
PDV: sessão de caixa, movimentos (sangria/suprimento), vínculo da venda com o
caixa e formas de pagamento.

Não altera o app vendas: a venda continua sendo criada por
Venda.registrar_venda(); aqui ficam só os dados novos, ligados a ela.
"""

from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Q

from core.models import ModeloBase, ModeloImutavel, ModeloProtegido

TERMINAL_PADRAO = "CAIXA 01"


class FormaPagamento(models.TextChoices):
    DINHEIRO = "DINHEIRO", "Dinheiro"
    PIX = "PIX", "PIX"
    DEBITO = "DEBITO", "Cartão de débito"
    CREDITO = "CREDITO", "Cartão de crédito"
    OUTROS = "OUTROS", "Outros"


# Código do meio de pagamento (tPag) da NF-e/NFC-e 4.00. Usado nas etapas
# fiscais; já fica aqui para o PDV e o documento fiscal usarem a mesma base.
CODIGO_FISCAL_PAGAMENTO = {
    FormaPagamento.DINHEIRO: "01",
    FormaPagamento.CREDITO: "03",
    FormaPagamento.DEBITO: "04",
    FormaPagamento.PIX: "17",
    FormaPagamento.OUTROS: "99",
}


class SessaoCaixa(ModeloBase, ModeloProtegido):
    """Um turno de caixa: da abertura (com fundo de troco) ao fechamento."""

    class Status(models.TextChoices):
        ABERTO = "ABERTO", "Aberto"
        FECHADO = "FECHADO", "Fechado"

    terminal = models.CharField("terminal", max_length=30, default=TERMINAL_PADRAO)
    operador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="sessoes_caixa",
        verbose_name="operador",
    )
    status = models.CharField(
        "situação", max_length=10, choices=Status.choices, default=Status.ABERTO
    )
    aberto_em = models.DateTimeField("aberto em", auto_now_add=True)
    fundo_troco = models.DecimalField(
        "fundo de troco", max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    fechado_em = models.DateTimeField("fechado em", null=True, blank=True)
    fechado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="sessoes_caixa_fechadas",
        verbose_name="fechado por",
    )
    valor_esperado = models.DecimalField(
        "dinheiro esperado", max_digits=12, decimal_places=2, null=True, blank=True
    )
    valor_contado = models.DecimalField(
        "dinheiro contado", max_digits=12, decimal_places=2, null=True, blank=True
    )
    observacao = models.TextField("observação do fechamento", blank=True, default="")

    class Meta:
        verbose_name = "sessão de caixa"
        verbose_name_plural = "sessões de caixa"
        ordering = ["-aberto_em", "-id"]
        indexes = [
            models.Index(fields=["operador", "-aberto_em"], name="sessaocx_oper_aberto_idx"),
            models.Index(fields=["status"], name="sessaocx_status_idx"),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["operador"],
                condition=Q(status="ABERTO"),
                name="caixa_um_aberto_por_operador",
            ),
            models.UniqueConstraint(
                fields=["terminal"],
                condition=Q(status="ABERTO"),
                name="caixa_um_aberto_por_terminal",
            ),
            models.CheckConstraint(
                condition=Q(fundo_troco__gte=0), name="caixa_fundo_nao_negativo"
            ),
            models.CheckConstraint(
                condition=Q(status="ABERTO")
                | (
                    Q(fechado_em__isnull=False)
                    & Q(valor_contado__isnull=False)
                    & Q(valor_esperado__isnull=False)
                ),
                name="caixa_fechado_tem_conferencia",
            ),
        ]

    def __str__(self):
        return f"Caixa #{self.pk} ({self.terminal})"

    @property
    def aberto(self):
        return self.status == self.Status.ABERTO

    @property
    def diferenca(self):
        """Contado menos esperado (negativo = faltou dinheiro)."""
        if self.valor_contado is None or self.valor_esperado is None:
            return None
        return self.valor_contado - self.valor_esperado


class MovimentoCaixa(ModeloImutavel):
    """Sangria (retirada) ou suprimento (reforço) de dinheiro do caixa."""

    class Tipo(models.TextChoices):
        SANGRIA = "SANGRIA", "Sangria"
        SUPRIMENTO = "SUPRIMENTO", "Suprimento"

    sessao = models.ForeignKey(
        SessaoCaixa,
        on_delete=models.PROTECT,
        related_name="movimentos",
        verbose_name="caixa",
    )
    tipo = models.CharField("tipo", max_length=12, choices=Tipo.choices)
    valor = models.DecimalField("valor", max_digits=12, decimal_places=2)
    motivo = models.CharField("motivo", max_length=200)
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="movimentos_caixa",
        verbose_name="usuário responsável",
    )
    criado_em = models.DateTimeField("data", auto_now_add=True)

    class Meta:
        verbose_name = "movimento de caixa"
        verbose_name_plural = "movimentos de caixa"
        ordering = ["-criado_em", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=Q(valor__gt=0), name="movimentocaixa_valor_positivo"
            ),
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} de {self.valor} no {self.sessao}"


class VendaCaixa(ModeloImutavel):
    """Liga uma venda ao caixa em que foi feita e guarda o troco dado."""

    venda = models.OneToOneField(
        "vendas.Venda",
        on_delete=models.PROTECT,
        related_name="caixa_info",
        verbose_name="venda",
    )
    sessao = models.ForeignKey(
        SessaoCaixa,
        on_delete=models.PROTECT,
        related_name="vendas_pdv",
        verbose_name="caixa",
    )
    troco = models.DecimalField(
        "troco", max_digits=12, decimal_places=2, default=Decimal("0.00")
    )
    criado_em = models.DateTimeField("criado em", auto_now_add=True)

    class Meta:
        verbose_name = "venda no caixa"
        verbose_name_plural = "vendas no caixa"
        ordering = ["-id"]
        constraints = [
            models.CheckConstraint(
                condition=Q(troco__gte=0), name="vendacaixa_troco_nao_negativo"
            ),
        ]

    def __str__(self):
        return f"Venda #{self.venda_id} no {self.sessao}"


class PagamentoVenda(ModeloImutavel):
    """
    Parte do total de uma venda paga por uma forma de pagamento.
    `valor` é o valor APLICADO à venda (já sem o troco): a soma dos
    pagamentos de uma venda é sempre igual ao total dela.
    """

    venda = models.ForeignKey(
        "vendas.Venda",
        on_delete=models.PROTECT,
        related_name="pagamentos",
        verbose_name="venda",
    )
    forma = models.CharField("forma", max_length=10, choices=FormaPagamento.choices)
    valor = models.DecimalField("valor", max_digits=12, decimal_places=2)
    criado_em = models.DateTimeField("criado em", auto_now_add=True)

    class Meta:
        verbose_name = "pagamento de venda"
        verbose_name_plural = "pagamentos de vendas"
        ordering = ["venda_id", "id"]
        indexes = [models.Index(fields=["forma"], name="pagvenda_forma_idx")]
        constraints = [
            models.CheckConstraint(
                condition=Q(valor__gt=0), name="pagamentovenda_valor_positivo"
            ),
        ]

    def __str__(self):
        return f"{self.get_forma_display()} {self.valor} (venda #{self.venda_id})"
