import django.db.models.deletion
from decimal import Decimal
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('vendas', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='SessaoCaixa',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('terminal', models.CharField(default='CAIXA 01', max_length=30, verbose_name='terminal')),
                ('status', models.CharField(choices=[('ABERTO', 'Aberto'), ('FECHADO', 'Fechado')], default='ABERTO', max_length=10, verbose_name='situação')),
                ('aberto_em', models.DateTimeField(auto_now_add=True, verbose_name='aberto em')),
                ('fundo_troco', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12, verbose_name='fundo de troco')),
                ('fechado_em', models.DateTimeField(blank=True, null=True, verbose_name='fechado em')),
                ('valor_esperado', models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True, verbose_name='dinheiro esperado')),
                ('valor_contado', models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True, verbose_name='dinheiro contado')),
                ('observacao', models.TextField(blank=True, default='', verbose_name='observação do fechamento')),
                ('fechado_por', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='sessoes_caixa_fechadas', to=settings.AUTH_USER_MODEL, verbose_name='fechado por')),
                ('operador', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='sessoes_caixa', to=settings.AUTH_USER_MODEL, verbose_name='operador')),
            ],
            options={
                'verbose_name': 'sessão de caixa',
                'verbose_name_plural': 'sessões de caixa',
                'ordering': ['-aberto_em', '-id'],
            },
        ),
        migrations.CreateModel(
            name='MovimentoCaixa',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('tipo', models.CharField(choices=[('SANGRIA', 'Sangria'), ('SUPRIMENTO', 'Suprimento')], max_length=12, verbose_name='tipo')),
                ('valor', models.DecimalField(decimal_places=2, max_digits=12, verbose_name='valor')),
                ('motivo', models.CharField(max_length=200, verbose_name='motivo')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='data')),
                ('sessao', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='movimentos', to='pdv.sessaocaixa', verbose_name='caixa')),
                ('usuario', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='movimentos_caixa', to=settings.AUTH_USER_MODEL, verbose_name='usuário responsável')),
            ],
            options={
                'verbose_name': 'movimento de caixa',
                'verbose_name_plural': 'movimentos de caixa',
                'ordering': ['-criado_em', '-id'],
            },
        ),
        migrations.CreateModel(
            name='VendaCaixa',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('troco', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=12, verbose_name='troco')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('sessao', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='vendas_pdv', to='pdv.sessaocaixa', verbose_name='caixa')),
                ('venda', models.OneToOneField(on_delete=django.db.models.deletion.PROTECT, related_name='caixa_info', to='vendas.venda', verbose_name='venda')),
            ],
            options={
                'verbose_name': 'venda no caixa',
                'verbose_name_plural': 'vendas no caixa',
                'ordering': ['-id'],
            },
        ),
        migrations.CreateModel(
            name='PagamentoVenda',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('forma', models.CharField(choices=[('DINHEIRO', 'Dinheiro'), ('PIX', 'PIX'), ('DEBITO', 'Cartão de débito'), ('CREDITO', 'Cartão de crédito'), ('OUTROS', 'Outros')], max_length=10, verbose_name='forma')),
                ('valor', models.DecimalField(decimal_places=2, max_digits=12, verbose_name='valor')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('venda', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='pagamentos', to='vendas.venda', verbose_name='venda')),
            ],
            options={
                'verbose_name': 'pagamento de venda',
                'verbose_name_plural': 'pagamentos de vendas',
                'ordering': ['venda_id', 'id'],
            },
        ),
        migrations.AddIndex(
            model_name='sessaocaixa',
            index=models.Index(fields=['operador', '-aberto_em'], name='sessaocx_oper_aberto_idx'),
        ),
        migrations.AddIndex(
            model_name='sessaocaixa',
            index=models.Index(fields=['status'], name='sessaocx_status_idx'),
        ),
        migrations.AddConstraint(
            model_name='sessaocaixa',
            constraint=models.UniqueConstraint(condition=models.Q(('status', 'ABERTO')), fields=('operador',), name='caixa_um_aberto_por_operador'),
        ),
        migrations.AddConstraint(
            model_name='sessaocaixa',
            constraint=models.UniqueConstraint(condition=models.Q(('status', 'ABERTO')), fields=('terminal',), name='caixa_um_aberto_por_terminal'),
        ),
        migrations.AddConstraint(
            model_name='sessaocaixa',
            constraint=models.CheckConstraint(condition=models.Q(('fundo_troco__gte', 0)), name='caixa_fundo_nao_negativo'),
        ),
        migrations.AddConstraint(
            model_name='sessaocaixa',
            constraint=models.CheckConstraint(condition=models.Q(('status', 'ABERTO'), models.Q(('fechado_em__isnull', False), ('valor_contado__isnull', False), ('valor_esperado__isnull', False)), _connector='OR'), name='caixa_fechado_tem_conferencia'),
        ),
        migrations.AddConstraint(
            model_name='movimentocaixa',
            constraint=models.CheckConstraint(condition=models.Q(('valor__gt', 0)), name='movimentocaixa_valor_positivo'),
        ),
        migrations.AddConstraint(
            model_name='vendacaixa',
            constraint=models.CheckConstraint(condition=models.Q(('troco__gte', 0)), name='vendacaixa_troco_nao_negativo'),
        ),
        migrations.AddIndex(
            model_name='pagamentovenda',
            index=models.Index(fields=['forma'], name='pagvenda_forma_idx'),
        ),
        migrations.AddConstraint(
            model_name='pagamentovenda',
            constraint=models.CheckConstraint(condition=models.Q(('valor__gt', 0)), name='pagamentovenda_valor_positivo'),
        ),
    ]
