from django.urls import path

from . import views

app_name = "pdv"

urlpatterns = [
    path("", views.PainelCaixaView.as_view(), name="painel"),
    path("abrir/", views.AbrirCaixaView.as_view(), name="abrir"),
    path("movimento/", views.MovimentoCaixaView.as_view(), name="movimento"),
    path("venda/", views.VendaPdvView.as_view(), name="venda"),
    path("caixas/", views.SessaoListView.as_view(), name="sessao_list"),
    path("caixas/<int:pk>/", views.SessaoDetailView.as_view(), name="sessao_detail"),
    path("caixas/<int:pk>/fechar/", views.FecharCaixaView.as_view(), name="fechar"),
]
