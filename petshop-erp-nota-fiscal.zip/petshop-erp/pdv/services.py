"""
Regras do PDV/caixa, independentes de tela (reutilizáveis por API e pelas
próximas etapas: fiscal, impressão). Tudo que grava é atômico.
"""

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction
from django.db.models import Sum
from django.utils import timezone

from core.utils import valor_item
from vendas.models import Venda

from .models import (
    TERMINAL_PADRAO,
    FormaPagamento,
    MovimentoCaixa,
    PagamentoVenda,
    SessaoCaixa,
    VendaCaixa,
)

CENTAVOS = Decimal("0.01")
ZERO = Decimal("0.00")


def _dinheiro(valor):
    return Decimal(valor).quantize(CENTAVOS, rounding=ROUND_HALF_UP)


def sessao_aberta_do(usuario):
    """Caixa aberto do operador, ou None."""
    if not usuario.is_authenticated:
        return None
    return SessaoCaixa.objects.filter(
        operador=usuario, status=SessaoCaixa.Status.ABERTO
    ).first()


def _travar_aberta(sessao_pk):
    sessao = SessaoCaixa.objects.select_for_update().get(pk=sessao_pk)
    if not sessao.aberto:
        raise ValidationError("Este caixa já está fechado.")
    return sessao


@dataclass
class ResumoCaixa:
    fundo_troco: Decimal
    qtd_vendas: int
    total_vendas: Decimal
    por_forma: dict  # forma -> total aplicado
    suprimentos: Decimal
    sangrias: Decimal
    troco_dado: Decimal

    @property
    def linhas_formas(self):
        """[(rótulo, total)] de todas as formas de pagamento, para as telas."""
        return [(rotulo, self.por_forma.get(forma, ZERO)) for forma, rotulo in FormaPagamento.choices]

    @property
    def dinheiro_esperado(self):
        """Dinheiro que deveria estar na gaveta agora."""
        return (
            self.fundo_troco
            + self.por_forma.get(FormaPagamento.DINHEIRO, ZERO)
            + self.suprimentos
            - self.sangrias
        )


def resumo_sessao(sessao):
    pagamentos = (
        PagamentoVenda.objects.filter(venda__caixa_info__sessao=sessao)
        .values("forma")
        .annotate(total=Sum("valor"))
    )
    por_forma = {forma: ZERO for forma, _ in FormaPagamento.choices}
    for linha in pagamentos:
        por_forma[linha["forma"]] = linha["total"]

    vendas = VendaCaixa.objects.filter(sessao=sessao).aggregate(
        total=Sum("venda__valor_total"), troco=Sum("troco")
    )
    movimentos = {
        linha["tipo"]: linha["total"]
        for linha in sessao.movimentos.values("tipo").annotate(total=Sum("valor"))
    }
    return ResumoCaixa(
        fundo_troco=sessao.fundo_troco,
        qtd_vendas=sessao.vendas_pdv.count(),
        total_vendas=vendas["total"] or ZERO,
        por_forma=por_forma,
        suprimentos=movimentos.get(MovimentoCaixa.Tipo.SUPRIMENTO, ZERO),
        sangrias=movimentos.get(MovimentoCaixa.Tipo.SANGRIA, ZERO),
        troco_dado=vendas["troco"] or ZERO,
    )


def abrir_caixa(*, operador, fundo_troco, terminal=TERMINAL_PADRAO):
    fundo_troco = _dinheiro(fundo_troco)
    terminal = (terminal or "").strip() or TERMINAL_PADRAO
    if fundo_troco < 0:
        raise ValidationError("O fundo de troco não pode ser negativo.")
    try:
        with transaction.atomic():
            return SessaoCaixa.objects.create(
                operador=operador, terminal=terminal, fundo_troco=fundo_troco
            )
    except IntegrityError:
        raise ValidationError(
            "Já existe um caixa aberto para este operador ou neste terminal."
        )


def registrar_movimento(*, sessao, tipo, valor, motivo, usuario):
    """Sangria ou suprimento. A sangria não pode passar do dinheiro na gaveta."""
    valor = _dinheiro(valor)
    motivo = (motivo or "").strip()
    if valor <= 0:
        raise ValidationError("Informe um valor maior que zero.")
    if not motivo:
        raise ValidationError("Informe o motivo.")
    if tipo not in MovimentoCaixa.Tipo.values:
        raise ValidationError("Tipo de movimento inválido.")

    with transaction.atomic():
        sessao = _travar_aberta(sessao.pk)
        if tipo == MovimentoCaixa.Tipo.SANGRIA:
            disponivel = resumo_sessao(sessao).dinheiro_esperado
            if valor > disponivel:
                raise ValidationError(
                    f"Sangria maior que o dinheiro no caixa (R$ {disponivel})."
                )
        return MovimentoCaixa.objects.create(
            sessao=sessao, tipo=tipo, valor=valor, motivo=motivo[:200], usuario=usuario
        )


def validar_pagamentos(total, pagamentos):
    """
    `pagamentos`: {forma: valor recebido}. Devolve ([(forma, valor aplicado)], troco).

    Só o dinheiro gera troco; cartão/PIX/outros não podem passar do total.
    """
    total = _dinheiro(total)
    recebidos = {}
    for forma, valor in (pagamentos or {}).items():
        if forma not in FormaPagamento.values:
            raise ValidationError(f"Forma de pagamento inválida: {forma}.")
        valor = _dinheiro(valor or 0)
        if valor < 0:
            raise ValidationError("Valores de pagamento não podem ser negativos.")
        if valor > 0:
            recebidos[forma] = valor

    soma = sum(recebidos.values(), ZERO)
    if soma < total:
        raise ValidationError(f"Pagamento insuficiente: faltam R$ {total - soma}.")

    dinheiro = recebidos.pop(FormaPagamento.DINHEIRO, ZERO)
    sem_dinheiro = sum(recebidos.values(), ZERO)
    if sem_dinheiro > total:
        raise ValidationError(
            "Cartão, PIX e outros não podem passar do total (só dinheiro dá troco)."
        )

    dinheiro_aplicado = total - sem_dinheiro
    troco = dinheiro - dinheiro_aplicado
    aplicados = list(recebidos.items())
    if dinheiro_aplicado > 0:
        aplicados.insert(0, (FormaPagamento.DINHEIRO, dinheiro_aplicado))
    return aplicados, troco


def registrar_venda_pdv(*, sessao, operador, itens, pagamentos):
    """
    Venda no caixa: usa Venda.registrar_venda (estoque, histórico e fluxo de
    caixa financeiro) e grava pagamentos e vínculo com o caixa, tudo na mesma
    transação. Devolve (venda, troco).
    """
    total = _dinheiro(sum(valor_item(i["quantidade"], i["preco"]) for i in itens))
    aplicados, troco = validar_pagamentos(total, pagamentos)

    with transaction.atomic():
        sessao = _travar_aberta(sessao.pk)
        if sessao.operador_id != operador.pk:
            raise ValidationError("Este caixa pertence a outro operador.")

        venda = Venda.registrar_venda(vendedor=operador, itens=itens)
        if venda.valor_total != total:  # defesa: nunca gravar pagamento divergente
            raise ValidationError("O total da venda mudou. Refaça a venda.")

        VendaCaixa.objects.create(venda=venda, sessao=sessao, troco=troco)
        PagamentoVenda.objects.bulk_create(
            [PagamentoVenda(venda=venda, forma=f, valor=v) for f, v in aplicados]
        )
    return venda, troco


def fechar_caixa(*, sessao, valor_contado, usuario, observacao=""):
    """Confere o dinheiro contado com o esperado e encerra o caixa."""
    valor_contado = _dinheiro(valor_contado)
    if valor_contado < 0:
        raise ValidationError("O valor contado não pode ser negativo.")

    with transaction.atomic():
        sessao = _travar_aberta(sessao.pk)
        sessao.valor_esperado = resumo_sessao(sessao).dinheiro_esperado
        sessao.valor_contado = valor_contado
        sessao.observacao = (observacao or "").strip()
        sessao.status = SessaoCaixa.Status.FECHADO
        sessao.fechado_em = timezone.now()
        sessao.fechado_por = usuario
        sessao.save()
    return sessao
