"""
Testes do PDV/caixa. Rodar:  python manage.py test pdv
(precisa do PostgreSQL configurado no .env; o Django cria um banco de teste).
"""

from decimal import Decimal

from django.contrib.auth.models import Group, User
from django.core.exceptions import ValidationError
from django.test import TestCase, override_settings
from django.urls import reverse

from accounts.models import GRUPO_ADMINISTRADOR, GRUPO_VENDEDOR
from estoque.models import MovimentacaoEstoque
from financeiro.models import FluxoCaixa
from logs.models import LogAcao
from produtos.models import Produto
from vendas.models import Venda

from . import services
from .models import FormaPagamento, MovimentoCaixa, PagamentoVenda, SessaoCaixa

D = Decimal


@override_settings(
    SECURE_SSL_REDIRECT=False, SESSION_COOKIE_SECURE=False, CSRF_COOKIE_SECURE=False
)
class BaseTeste(TestCase):
    @classmethod
    def setUpTestData(cls):
        admin_grupo = Group.objects.create(name=GRUPO_ADMINISTRADOR)
        vend_grupo = Group.objects.create(name=GRUPO_VENDEDOR)
        cls.admin = User.objects.create_user("admin", password="x-12345678")
        cls.admin.groups.add(admin_grupo)
        cls.vendedor = User.objects.create_user("vend", password="x-12345678")
        cls.vendedor.groups.add(vend_grupo)
        cls.outro = User.objects.create_user("outro", password="x-12345678")
        cls.outro.groups.add(vend_grupo)

    def criar_produto(self, nome="Ração", preco="10.00", estoque=20, codigo="789"):
        produto = Produto.objects.create(
            nome=nome, codigo_barras=codigo, preco_venda=D(preco)
        )
        MovimentacaoEstoque.registrar(
            produto=produto,
            tipo=MovimentacaoEstoque.Tipo.ENTRADA,
            quantidade=estoque,
            usuario=self.admin,
        )
        produto.refresh_from_db()
        return produto

    def abrir(self, usuario=None, fundo="100.00", terminal="CAIXA 01"):
        return services.abrir_caixa(
            operador=usuario or self.vendedor, fundo_troco=D(fundo), terminal=terminal
        )

    def itens(self, produto, quantidade=2):
        return [{"produto": produto, "quantidade": quantidade, "preco": produto.preco_venda}]


class ServicosCaixaTests(BaseTeste):
    def test_abrir_caixa_unico_por_operador_e_por_terminal(self):
        self.abrir()
        with self.assertRaises(ValidationError):
            self.abrir(terminal="CAIXA 02")  # mesmo operador
        with self.assertRaises(ValidationError):
            self.abrir(usuario=self.outro)  # mesmo terminal
        self.assertEqual(SessaoCaixa.objects.count(), 1)

    def test_fundo_negativo_recusado(self):
        with self.assertRaises(ValidationError):
            self.abrir(fundo="-1")

    def test_venda_pdv_com_dinheiro_gera_troco_e_integra_estoque_e_financeiro(self):
        produto = self.criar_produto()
        sessao = self.abrir()
        venda, troco = services.registrar_venda_pdv(
            sessao=sessao,
            operador=self.vendedor,
            itens=self.itens(produto, 2),
            pagamentos={FormaPagamento.DINHEIRO: D("50.00")},
        )
        self.assertEqual(venda.valor_total, D("20.00"))
        self.assertEqual(troco, D("30.00"))
        produto.refresh_from_db()
        self.assertEqual(produto.quantidade, 18)
        self.assertTrue(FluxoCaixa.objects.filter(descricao=f"Venda #{venda.pk}").exists())
        pagamento = PagamentoVenda.objects.get(venda=venda)
        self.assertEqual((pagamento.forma, pagamento.valor), ("DINHEIRO", D("20.00")))
        self.assertEqual(venda.caixa_info.sessao, sessao)

    def test_pagamento_misto(self):
        produto = self.criar_produto()
        sessao = self.abrir()
        venda, troco = services.registrar_venda_pdv(
            sessao=sessao,
            operador=self.vendedor,
            itens=self.itens(produto, 3),  # 30,00
            pagamentos={"PIX": D("10.00"), "DINHEIRO": D("25.00")},
        )
        self.assertEqual(troco, D("5.00"))
        formas = {p.forma: p.valor for p in venda.pagamentos.all()}
        self.assertEqual(formas, {"PIX": D("10.00"), "DINHEIRO": D("20.00")})

    def test_pagamento_insuficiente_ou_cartao_acima_do_total_nao_grava_nada(self):
        produto = self.criar_produto()
        sessao = self.abrir()
        for pagamentos in ({"DINHEIRO": D("5")}, {"CREDITO": D("50")}, {}):
            with self.assertRaises(ValidationError):
                services.registrar_venda_pdv(
                    sessao=sessao,
                    operador=self.vendedor,
                    itens=self.itens(produto, 2),
                    pagamentos=pagamentos,
                )
        self.assertEqual(Venda.objects.count(), 0)
        produto.refresh_from_db()
        self.assertEqual(produto.quantidade, 20)

    def test_estoque_insuficiente_desfaz_pagamentos(self):
        produto = self.criar_produto(estoque=1)
        sessao = self.abrir()
        with self.assertRaises(ValidationError):
            services.registrar_venda_pdv(
                sessao=sessao,
                operador=self.vendedor,
                itens=self.itens(produto, 5),
                pagamentos={"DINHEIRO": D("50")},
            )
        self.assertEqual(PagamentoVenda.objects.count(), 0)
        self.assertEqual(Venda.objects.count(), 0)

    def test_venda_em_caixa_de_outro_operador_ou_fechado_recusada(self):
        produto = self.criar_produto()
        sessao = self.abrir()
        with self.assertRaises(ValidationError):
            services.registrar_venda_pdv(
                sessao=sessao, operador=self.outro,
                itens=self.itens(produto), pagamentos={"DINHEIRO": D("20")},
            )
        services.fechar_caixa(sessao=sessao, valor_contado=D("100"), usuario=self.vendedor)
        with self.assertRaises(ValidationError):
            services.registrar_venda_pdv(
                sessao=sessao, operador=self.vendedor,
                itens=self.itens(produto), pagamentos={"DINHEIRO": D("20")},
            )

    def test_sangria_suprimento_e_fechamento_com_diferenca(self):
        produto = self.criar_produto()
        sessao = self.abrir(fundo="100.00")
        services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor, itens=self.itens(produto, 2),
            pagamentos={"DINHEIRO": D("20.00")},
        )
        services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor, itens=self.itens(produto, 1),
            pagamentos={"PIX": D("10.00")},
        )
        services.registrar_movimento(
            sessao=sessao, tipo=MovimentoCaixa.Tipo.SUPRIMENTO, valor=D("50"),
            motivo="Reforço de troco", usuario=self.vendedor,
        )
        services.registrar_movimento(
            sessao=sessao, tipo=MovimentoCaixa.Tipo.SANGRIA, valor=D("120"),
            motivo="Recolhimento ao cofre", usuario=self.vendedor,
        )
        resumo = services.resumo_sessao(sessao)
        self.assertEqual(resumo.qtd_vendas, 2)
        self.assertEqual(resumo.total_vendas, D("30.00"))
        # 100 fundo + 20 dinheiro + 50 suprimento - 120 sangria
        self.assertEqual(resumo.dinheiro_esperado, D("50.00"))

        fechada = services.fechar_caixa(
            sessao=sessao, valor_contado=D("45.00"), usuario=self.vendedor
        )
        self.assertEqual(fechada.status, SessaoCaixa.Status.FECHADO)
        self.assertEqual(fechada.valor_esperado, D("50.00"))
        self.assertEqual(fechada.diferenca, D("-5.00"))

    def test_sangria_maior_que_o_dinheiro_e_movimento_sem_motivo_recusados(self):
        sessao = self.abrir(fundo="10.00")
        with self.assertRaises(ValidationError):
            services.registrar_movimento(
                sessao=sessao, tipo="SANGRIA", valor=D("50"), motivo="x", usuario=self.vendedor
            )
        with self.assertRaises(ValidationError):
            services.registrar_movimento(
                sessao=sessao, tipo="SUPRIMENTO", valor=D("5"), motivo="  ", usuario=self.vendedor
            )
        self.assertEqual(MovimentoCaixa.objects.count(), 0)

    def test_nao_fecha_duas_vezes_e_nao_exclui(self):
        sessao = self.abrir()
        services.fechar_caixa(sessao=sessao, valor_contado=D("100"), usuario=self.vendedor)
        with self.assertRaises(ValidationError):
            services.fechar_caixa(sessao=sessao, valor_contado=D("100"), usuario=self.vendedor)
        with self.assertRaises(Exception):
            sessao.delete()
        # fechado, o operador pode abrir outro caixa
        self.abrir()


class TelasPdvTests(BaseTeste):
    def test_exige_login_e_perfil(self):
        self.assertEqual(self.client.get(reverse("pdv:painel")).status_code, 302)
        sem_perfil = User.objects.create_user("sem", password="x-12345678")
        self.client.force_login(sem_perfil)
        self.assertEqual(self.client.get(reverse("pdv:painel")).status_code, 403)

    def test_fluxo_completo_pela_interface(self):
        produto = self.criar_produto()
        self.client.force_login(self.vendedor)
        self.assertContains(self.client.get(reverse("pdv:painel")), "Abrir caixa")

        # sem caixa aberto, a venda do PDV volta para o painel
        self.assertRedirects(self.client.get(reverse("pdv:venda")), reverse("pdv:painel"))

        self.client.post(reverse("pdv:abrir"), {"terminal": "CAIXA 01", "fundo_troco": "50"})
        sessao = SessaoCaixa.objects.get()

        resposta = self.client.post(
            reverse("pdv:venda"),
            {
                "form-TOTAL_FORMS": "1", "form-INITIAL_FORMS": "0",
                "form-MIN_NUM_FORMS": "1", "form-MAX_NUM_FORMS": "1000",
                "form-0-produto": str(produto.pk), "form-0-quantidade": "2",
                "DINHEIRO": "30",
            },
        )
        venda = Venda.objects.get()
        self.assertRedirects(resposta, reverse("vendas:detail", args=[venda.pk]))
        self.assertContains(self.client.get(reverse("vendas:detail", args=[venda.pk])), "Troco")

        self.client.post(
            reverse("pdv:movimento"), {"tipo": "SUPRIMENTO", "valor": "10", "motivo": "troco"}
        )
        resposta = self.client.post(
            reverse("pdv:fechar", args=[sessao.pk]), {"valor_contado": "80", "observacao": ""}
        )
        self.assertRedirects(resposta, reverse("pdv:sessao_detail", args=[sessao.pk]))
        sessao.refresh_from_db()
        self.assertEqual(sessao.valor_esperado, D("80.00"))  # 50 + 20 + 10
        self.assertEqual(sessao.diferenca, D("0.00"))
        self.assertEqual(LogAcao.objects.filter(acao=LogAcao.Acao.CAIXA).count(), 3)
        self.assertTrue(LogAcao.objects.filter(acao=LogAcao.Acao.VENDA).exists())

    def test_operador_nao_ve_nem_fecha_caixa_de_outro_mas_admin_sim(self):
        sessao = self.abrir(usuario=self.vendedor)
        self.client.force_login(self.outro)
        self.assertEqual(
            self.client.get(reverse("pdv:sessao_detail", args=[sessao.pk])).status_code, 404
        )
        resposta = self.client.post(
            reverse("pdv:fechar", args=[sessao.pk]), {"valor_contado": "100"}
        )
        self.assertEqual(resposta.status_code, 404)
        sessao.refresh_from_db()
        self.assertTrue(sessao.aberto)

        self.client.force_login(self.admin)
        self.assertEqual(
            self.client.get(reverse("pdv:sessao_detail", args=[sessao.pk])).status_code, 200
        )
        self.client.post(reverse("pdv:fechar", args=[sessao.pk]), {"valor_contado": "100"})
        sessao.refresh_from_db()
        self.assertFalse(sessao.aberto)
        self.assertEqual(sessao.fechado_por, self.admin)

    def test_venda_comum_continua_funcionando_sem_caixa(self):
        produto = self.criar_produto()
        venda = Venda.registrar_venda(vendedor=self.vendedor, itens=self.itens(produto))
        self.client.force_login(self.vendedor)
        resposta = self.client.get(reverse("vendas:detail", args=[venda.pk]))
        self.assertEqual(resposta.status_code, 200)
        self.assertNotContains(resposta, "Troco")
