from django.contrib import admin

from core.admin import SomenteLeituraAdminMixin
from core.utils import moeda

from .models import MovimentoCaixa, PagamentoVenda, SessaoCaixa, VendaCaixa


@admin.register(SessaoCaixa)
class SessaoCaixaAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("numero", "terminal", "operador", "status", "aberto_em", "fechado_em")
    list_filter = ("status", "terminal", "operador")
    list_select_related = ("operador",)
    date_hierarchy = "aberto_em"
    list_per_page = 50

    @admin.display(description="Caixa", ordering="id")
    def numero(self, obj):
        return f"#{obj.pk}"


@admin.register(MovimentoCaixa)
class MovimentoCaixaAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("sessao", "tipo", "valor_moeda", "motivo", "usuario", "criado_em")
    list_filter = ("tipo",)
    list_select_related = ("sessao", "usuario")
    list_per_page = 50

    @admin.display(description="Valor", ordering="valor")
    def valor_moeda(self, obj):
        return moeda(obj.valor)


@admin.register(VendaCaixa)
class VendaCaixaAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("venda", "sessao", "troco_moeda", "criado_em")
    list_select_related = ("venda", "sessao")
    list_per_page = 50

    @admin.display(description="Troco", ordering="troco")
    def troco_moeda(self, obj):
        return moeda(obj.troco)


@admin.register(PagamentoVenda)
class PagamentoVendaAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("venda", "forma", "valor_moeda", "criado_em")
    list_filter = ("forma",)
    list_select_related = ("venda",)
    list_per_page = 50

    @admin.display(description="Valor", ordering="valor")
    def valor_moeda(self, obj):
        return moeda(obj.valor)
