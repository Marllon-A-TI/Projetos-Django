# Pet Shop ERP: diagnóstico, produção e Excel

Baseado na leitura do projeto real enviado (`petshop-erp.zip`). Nada foi inventado: onde algo não pôde ser verificado, está dito.

## 1. Diagnóstico da arquitetura

**Apps (8):** `core` (mixins, base de models, middleware de acesso, filtros), `accounts` (usuários e grupos), `produtos`, `estoque`, `vendas`, `financeiro`, `dashboard`, `logs`. Django 5.2, PostgreSQL via `psycopg 3`, `gunicorn`, `whitenoise`, `python-decouple`. Sem JavaScript de build: Bootstrap e Chart.js locais em `static/vendor`.

**Padrões em uso (todos devem ser preservados):**

- **Class Based Views** finas, com mixins de `core/mixins.py`; listagens com `FiltroListViewMixin` + um `FiltroForm` com método `filtrar()`.
- **Models-base** em `core/models.py`: `ModeloBase` (criado/atualizado), `ModeloProtegido` (não exclui), `ModeloImutavel` (não altera nem exclui; `update()` e `delete()` em lote bloqueados). Usados por `MovimentacaoEstoque`, `LogAcao`, `Venda`, `ItemVenda`, `FluxoCaixa`.
- **Regra de ouro do estoque:** `Produto.quantidade` não pode ser gravada por `save()` (levanta `EstoqueProtegidoError`); só `MovimentacaoEstoque.registrar()` altera o saldo, com `select_for_update`, histórico imutável e *constraints* no banco que garantem saldo consistente.
- **Serviços em classmethod** com `transaction.atomic` (`Venda.registrar_venda`, `MovimentacaoEstoque.registrar`) e módulo de serviços no dashboard.
- **Templates** com `base.html` (navbar Bootstrap, perfil decide o menu), parciais (`campo`, `form_corpo`, `filtro`, `paginacao`, `mensagens`) e filtros em `core_tags`.

**Permissões (3 camadas):** (1) `ControleAcessoMiddleware` define o perfil mínimo por app (`PERFIS_POR_APP`); (2) cada view usa `AdministradorRequiredMixin` ou `VendedorOuAdministradorRequiredMixin` (login → redireciona; sem perfil → 403); (3) os templates escondem o que o perfil não pode usar. Perfis = grupos `Administrador` e `Vendedor` (`accounts/models.py`, criados por `manage.py criar_grupos`); superusuário passa em tudo. Importante: o app `produtos` está liberado para Vendedor na camada 1, então **qualquer view nova de produtos que seja só de administrador precisa do mixin na própria view**.

**Logs:** `LogAcao` (imutável) guarda usuário, ação, IP, data e descrição. Gravação por `registrar_acao(request, acao, descricao)` ou `LogFormValidMixin` (grava na mesma transação do objeto). `AuditoriaMiddleware` calcula o IP (`CLIENT_IP_HEADER`), bloqueia excesso de logins errados (429) e audita POSTs do `/admin/`; sinais registram login/logout/falha. Há também log de aplicação em `var/log/petshop.log` com rotação.

## 2. Diagnóstico de Produtos

`Produto`: nome, código de barras, categoria, fornecedor, quantidade (protegida), estoque mínimo, preço de custo/venda (≥ 0 por constraint), ativo. Índices em nome, código e categoria. **O código de barras não é único no banco**; a unicidade é só validada no `ProdutoForm`.
CRUD: lista (filtros, paginação 25; vendedor só vê ativos e não vê custo), detalhe, criar/editar (só admin, com log; estoque inicial vira movimentação de ENTRADA), ativar/desativar, excluir (bloqueado se houver movimentações/vendas).

## 3. Diagnóstico da infraestrutura atual

Já existia e está bem feito: `deploy/` (Gunicorn em `127.0.0.1:8000`, serviço systemd, `atualizar.sh`, exemplo de Caddyfile e de `.env` de produção), `scripts/` (backup diário com `pg_dump`, retenção, restauração e teste de restauração), `settings.py` guiado por `.env` (DEBUG falso por padrão, HSTS, cookies seguros, proxy). **Então a hospedagem não exige mudança de código.**

**O que o projeto não tinha:** nenhuma parte de Excel. O módulo de produtos terminava no CRUD, o `LogAcao` não tinha ações de importação/exportação e o `openpyxl` não estava no `requirements.txt`. Tudo isso foi criado agora, reaproveitando `ModeloImutavel`, `registrar_acao`, os mixins de perfil, `BootstrapFormMixin` e os parciais de template existentes.

## 4. Plano de hospedagem

Ver **`deploy/ORACLE_CLOUD.md`** (passo a passo, firewall, Caddy/Nginx, SSL, backup, custos, limites). Resumo: uma VM Ampere A1 (1 OCPU/6 GB) com Ubuntu 24.04, PostgreSQL local, Gunicorn, Caddy; custo R$ 0 (domínio opcional). Dois alertas: o Always Free hoje é **2 OCPU/12 GB** (não 4/24) e instâncias ociosas podem ser recuperadas, por isso o **backup externo é obrigatório**.

## 5. Alterações necessárias para produção

Nenhuma no código. Só configuração no `.env` (modelo em `deploy/env.producao.exemplo`): `DJANGO_DEBUG=False`, `DJANGO_ALLOWED_HOSTS`, `DJANGO_CSRF_TRUSTED_ORIGINS`, nova `DJANGO_SECRET_KEY`, `DJANGO_ADMIN_URL`, `CLIENT_IP_HEADER=HTTP_X_FORWARDED_FOR`, cookies seguros e SSL redirect ligados.

## 6. Importar Excel (implementado)

Menu **Produtos → Importar Excel** (somente Administrador). Fluxo: upload → validações do arquivo (extensão, 5 MB, é um zip `.xlsx` real, tamanho descompactado) → leitura em modo *read-only* linha a linha → validação de **todas** as linhas → só então grava, em uma `transaction.atomic`.

- **Chave:** código de barras. **Obrigatórias:** Código de barras, Nome, Estoque, Preço de venda. **Opcionais:** Categoria, Fornecedor, Estoque mínimo, Preço de custo, Ativo. Cabeçalhos aceitam variações sem acento (ex.: "EAN", "Quantidade", "Preço").
- **Valida:** colunas ausentes/duplicadas, vazios, tipos, negativos, casas decimais, tamanhos de texto, duplicidade na planilha, duplicidade no cadastro, limite de 20.000 linhas. Mostra até 100 erros com o número da linha; qualquer erro = nada é gravado.
- **Produto existente:** atualiza preço de venda, preço de custo (se informado) e estoque; **preserva** nome, categoria, fornecedor, estoque mínimo e situação.
- **Produto novo:** criado com `bulk_create`.
- **Estoque respeita a regra do projeto:** nada de `save()` em `quantidade`. Existente recebe movimentação **AJUSTE** (a planilha vira o saldo contado); novo recebe **ENTRADA**. Isso é feito por `MovimentacaoEstoque.registrar_lote()` (novo, em lote: `select_for_update` + `bulk_create` + `bulk_update`), então o histórico e as constraints continuam valendo.
- **Log:** uma ação `IMPORTACAO` com arquivo e contagens, gravada na mesma transação.
- **Desempenho:** a leitura/validação de 20.000 linhas levou ~1 s no teste; consultas em lotes de 2.000, gravação em lotes de 1.000.

## 7. Exportar Excel (implementado)

Menu **Produtos → Exportar Excel**: download imediato (GET), todos os produtos (inclusive inativos), as 9 colunas do model, em ordem de nome. Só Administrador (inclui preço de custo). Textos gravados como texto (zeros à esquerda preservados e **sem execução de fórmulas** se o nome começar com `=`, `+`, `-`, `@`). Cabeçalho `Cache-Control: no-store`. Gera log `EXPORTACAO`. O arquivo exportado é o modelo da importação (exportar → editar → importar funciona).

## 8. Arquivos alterados

| Arquivo | Mudança |
|---|---|
| `requirements.txt` | `+ openpyxl>=3.1,<4.0` (única dependência nova) |
| `logs/models.py` | `+ IMPORTACAO`, `+ EXPORTACAO` em `LogAcao.Acao` |
| `logs/migrations/0003_alter_logacao_acao.py` | **novo**: só atualiza as `choices` (sem alterar tabelas); rode `migrate` |
| `estoque/models.py` | `+ MovimentacaoEstoque.registrar_lote()` e `import timezone` |
| `produtos/excel.py` | **novo**: lê/valida/gera XLSX (só openpyxl, sem Django, sem banco) |
| `produtos/importacao.py` | **novo**: grava a importação (atômica, em lote, via movimentações) |
| `templates/produtos/produto_importar.html` | **novo**: tela de importação (layout padrão do projeto) |
| `produtos/forms.py` | `+ ImportarProdutosForm` |
| `produtos/views.py` | `+ ProdutoImportarView`, `+ ProdutoExportarView` |
| `produtos/urls.py` | `+ importar/`, `+ exportar/` |
| `templates/base.html` | "Produtos" vira dropdown (só administrador) |
| `produtos/tests.py` | 11 testes novos |
| `deploy/ORACLE_CLOUD.md`, `RELATORIO.md` | documentação |

O diff exato está em `alteracoes.patch` (a nova migração, `excel.py`, `importacao.py` e o template aparecem como arquivos novos).

## 9. Novas URLs, forms, views, templates e menu

- URLs: `produtos:importar` (`/produtos/importar/`), `produtos:exportar` (`/produtos/exportar/`).
- Form: `ImportarProdutosForm` (um campo de arquivo). Views: `ProdutoImportarView` (FormView), `ProdutoExportarView` (View GET).
- Template novo: `produto_importar.html` (usa `form_corpo`, `campo` e `mensagens` existentes). Menu: dropdown Produtos → Lista / Importar Excel / Exportar Excel.

## 10. Como testar localmente

1. `pip install -r requirements.txt` (traz o `openpyxl`) e `python manage.py check`.
2. `python manage.py test produtos` (precisa do PostgreSQL do `.env`; o Django cria e apaga um banco de teste).
3. Manual: entre como Administrador → Produtos → **Exportar Excel** → abra, altere preço/estoque de uma linha, acrescente uma linha nova → **Importar Excel** → confira a mensagem, a lista, a tela de Estoque (movimentações "Importação Excel") e Logs.
4. Planilha com erro (estoque negativo, código repetido, coluna faltando): deve mostrar a lista de erros e não gravar nada.
5. Entre como Vendedor: o menu não mostra as opções e as URLs devolvem 403.

## 11. Como testar em produção

Checklist da seção 10 de `deploy/ORACLE_CLOUD.md`. Antes da primeira importação real, rode `./scripts/backup_db.sh` e importe primeiro uma planilha pequena.

## 12. Segurança (verificado em `settings.py`)

| Item | Situação | Ajuste |
|---|---|---|
| `DEBUG` | padrão `False`; o `.env` enviado tem `True` (desenvolvimento) | `False` em produção |
| `ALLOWED_HOSTS` / CSRF | lidos do `.env`; `.env` enviado só tem localhost | colocar o domínio e `CSRF_TRUSTED_ORIGINS` com `https://` |
| Sessão | 8 h, `HttpOnly`, `SameSite=Lax`, cookie seguro se não for DEBUG | manter |
| HTTPS/HSTS/proxy | `SECURE_PROXY_SSL_HEADER`, SSL redirect e HSTS por `.env` | HSTS 3600 → 1 ano depois de validar |
| Upload | não há `MEDIA`; planilha é lida em memória/temporário e descartada | 5 MB (form) + 6 MB (Caddy) + proteção contra zip bomb |
| Permissões | importar/exportar só Administrador (view + teste) | — |
| Admin | URL configurável (`DJANGO_ADMIN_URL`) | trocar o padrão |

**Atenção ao `.env` dentro do zip:** o arquivo foi enviado junto com o projeto. Não li nem repeti os valores, mas por ele ter circulado, recomendo gerar uma nova `DJANGO_SECRET_KEY` e uma nova senha de banco para produção (a nuvem terá as suas de qualquer forma) e nunca versionar o `.env` (já está no `.gitignore`).

## 13. Riscos

- **Os testes Django novos não foram executados.** O ambiente de análise não tinha Django nem rede para instalá-lo. O que foi realmente executado: compilação de todos os arquivos alterados e testes do `excel.py` (leitura, erros, ida e volta, proteção contra fórmula, 20.000 linhas, limites). `registrar_lote`, form e views foram revisados contra o código existente, mas rode `python manage.py test produtos` antes de confiar.
- **Código de barras não é único no banco:** se o cadastro tiver códigos repetidos, a importação recusa as linhas afetadas e pede correção (comportamento intencional e seguro).
- **Importação por AJUSTE sobrescreve o saldo** com o valor da planilha. Se houver vendas entre exportar e importar, o saldo volta ao valor antigo. Oriente: importe logo após exportar, ou use a importação como "contagem de estoque".
- Preços/estoque com formato de texto incomum (ex.: "1,5 mil") são recusados com mensagem, não adivinhados.
- Oracle: recuperação de instância ociosa, falta de capacidade A1 e limite de 2 OCPU/12 GB (detalhes no runbook).
- Operação síncrona: 20.000 linhas ficam bem abaixo do `timeout` de 60 s do Gunicorn, mas arquivos muito maiores precisariam de fila (não recomendado agora).

## 14. Melhorias futuras (em ordem de valor)

1. Tornar `codigo_barras` único no banco (índice único parcial para não vazios) depois de limpar duplicidades.
2. Pré-visualização ("vai criar X, atualizar Y") com confirmação antes de gravar.
3. Botão "Baixar modelo vazio" e coluna `Ação` (ex.: ENTRADA em vez de AJUSTE).
4. Exportar respeitando os filtros da lista; exportar movimentações e vendas.
5. Monitoramento externo gratuito (UptimeRobot) e alerta de falha de backup por e-mail.
6. CI simples (GitHub Actions) rodando `manage.py test` a cada commit.

---

# Fase 1 · Etapa 1 — Núcleo do PDV e caixa (app `pdv`)

Primeira etapa do ecossistema de automação comercial/fiscal/impressão. Entrega a base de que as etapas fiscais e de impressão dependem: **sessão de caixa, operador, formas de pagamento, troco, sangria, suprimento e fechamento**.

## Auditoria que orientou o desenho

| Encontrado | Decisão |
|---|---|
| `Venda.registrar_venda` já cuida de estoque, histórico e `FluxoCaixa` | reutilizado sem alteração; o PDV só o chama |
| Não existia caixa, pagamento nem troco | novo app `pdv`, ligado à venda por modelos próprios (sem migration em `vendas`) |
| `LogAcao.acao` tem 10 caracteres | uma ação nova `CAIXA` (só `choices`, sem mudar a coluna) |
| Permissões por app em `PERFIS_POR_APP` + mixins | `pdv` liberado para Vendedor e Administrador; operador só vê os próprios caixas, Administrador vê todos |
| Dashboard soma `Venda` | vendas do PDV entram nele automaticamente |
| Tela de venda e `vendas.js` (leitor de código de barras) | reutilizados na tela do PDV (`templates/vendas/_item_linha.html`, `vendas.js`) |

## Regras de negócio

- Um caixa aberto por operador **e** por terminal (restrição no banco).
- `valor` do pagamento é o valor **aplicado** à venda; a soma dos pagamentos é sempre o total. Só **dinheiro** gera troco; cartão/PIX/outros não passam do total.
- Dinheiro esperado = fundo + vendas em dinheiro + suprimentos − sangrias. Sangria maior que o dinheiro na gaveta é recusada.
- Fechamento grava esperado, contado, quem fechou e quando; a diferença (sobra/falta) é calculada. Caixa fechado não aceita venda nem movimento e não é excluído.
- Venda, pagamentos e vínculo com o caixa são gravados na mesma transação: se qualquer parte falhar, nada é gravado (inclusive estoque).
- A venda comum (`/vendas/nova/`) continua existindo e **não** depende de caixa.
- `CODIGO_FISCAL_PAGAMENTO` (tPag da NF-e/NFC-e) já está em `pdv/models.py` para as etapas fiscais usarem a mesma base.

## Arquivos

Novos: `pdv/` (models, services, forms, views, urls, admin, tests, migration 0001), `logs/migrations/0004_alter_logacao_acao.py`, `templates/pdv/*`, `static/js/pdv.js`.
Alterados: `config/settings.py` (app), `config/urls.py` (`/pdv/`), `core/middleware.py` (perfil do app), `logs/models.py` (ação `CAIXA`), `templates/base.html` (item PDV), `templates/vendas/venda_detail.html` (bloco de pagamento, só aparece se houver).

## Migrations: `pdv.0001_initial` (4 tabelas novas) e `logs.0004` (só rótulos). Nenhuma tabela existente é alterada.

## Próximas etapas (dependem desta)

1. Empresa/emitente e certificado A1 (multiempresa) · 2. Documentos fiscais (NFC-e primeiro) · 3. Impressão (fila, ESC/POS, gaveta, cupom não fiscal) · 4. Equipamentos (balança, produtos pesáveis) · 5. NF-e/NFS-e/SAT, eventos e contingência.
Decisões que travam a etapa fiscal: regime tributário/CNPJ/UF da loja, modelos de impressora/balança (a emissão fiscal ficou definida: direto na SEFAZ, gratuita; ver Etapas 2 e 3).

## Como validar

`python manage.py migrate` · `python manage.py makemigrations --check` (deve dizer "No changes") · `python manage.py test pdv produtos`.
**Não executado no ambiente de desenvolvimento** (sem Django instalado): o código foi compilado e conferido por análise estática; os testes em `pdv/tests.py` precisam ser rodados na sua máquina.

---

# Fase 1 · Etapa 2 — Empresa emitente e prontidão fiscal (app `fiscal`)

## Decisão de arquitetura: emissão 100% gratuita, direto na SEFAZ

Sem provedor pago. O sistema monta o XML, assina com o **seu** certificado A1 e (Etapa 4) transmite direto aos web services da SEFAZ. Software, bibliotecas (`lxml`, `cryptography`) e web services da SEFAZ são gratuitos.
**Único custo inevitável:** o certificado digital A1 (e-CNPJ), exigido por lei para qualquer emissão de NFC-e, com ou sem provedor. Não existe certificado A1 válido gratuito; o preço varia por certificadora, consulte o contador.

## O que a etapa entrega
- `fiscal.Empresa`: dados cadastrais, regime (CRT), endereço com código IBGE, ambiente, série da NFC-e e **ID** do CSC. Multiempresa desde já (uma "padrão" garantida por restrição no banco). Não pode ser excluída (só desativada).
- **Segredos fora do banco:** o `.pfx`, a senha dele e o código CSC ficam no PC da loja, no `.env` (ver Etapa 3).
- Validação de CNPJ numérico **e alfanumérico** (regra da Receita para CNPJs novos a partir de jul/2026).
- Tela de **prontidão** (por empresa): lista o que impede emitir e avisos.
- Somente Administrador (middleware + mixin); criação/edição auditadas (`LogAcao`).

---

# Fase 1 · Etapa 3 — Núcleo da NFC-e: documento, numeração, XML, assinatura e QR-Code

Esta etapa gera e **assina** a NFC-e de uma venda do PDV. **Ainda não transmite** à SEFAZ (Etapa 4): a nota fica "Assinada (aguardando envio)".

## Como cada parte funciona
| Parte | Onde | Observação |
|---|---|---|
| Chave de acesso (44) | `fiscal/nfce/chave.py` | módulo 11; confere com o exemplo do manual; aceita CNPJ alfanumérico |
| XML NFC-e 4.00 | `fiscal/nfce/xml.py` | modelo 65, emissão normal, consumidor não identificado, Simples Nacional (CSOSN), sem grupo IBS/CBS (ver aviso) |
| Assinatura XMLDSig | `fiscal/nfce/assinatura.py` | enveloped, C14N, RSA-SHA1/digest SHA-1 (exigência do leiaute); a nota só é gravada se a assinatura se verifica |
| QR-Code v2.00 online | `fiscal/nfce/qrcode.py` | `chave\|2\|tpAmb\|idCSC\|SHA1(...+CSC)`; idCSC sem zeros à esquerda (manual do DANFE NFC-e) |
| Certificado A1 | `fiscal/nfce/certificado.py` | lê `.pfx` do disco; valida senha, validade e CNPJ do titular |
| Numeração | `SequenciaNumeracao` | por empresa/modelo/série/ambiente, com trava de linha; se a geração falhar, o número **não** é consumido |
| Documento e trilha | `DocumentoFiscal`, `EventoFiscal` | evento é imutável; documento não pode ser excluído |
| Dados fiscais do produto | `ProdutoFiscal` | NCM, CEST, CFOP, unidade, origem, CSOSN (o cadastro de produtos não foi alterado) |

Integração: usa `Venda`, `ItemVenda`, `PagamentoVenda` e o troco do PDV. Formas de pagamento seguem `CODIGO_FISCAL_PAGAMENTO` (tPag). Em dinheiro, `vPag` = valor aplicado + troco e `vTroco` informado.

## Configuração no PC da loja (`.env`, ver `loja/env.loja.exemplo`)
```
FISCAL_CERT_PFX=C:\PetShopERP\certificado\empresa.pfx
FISCAL_CERT_SENHA="senha-do-certificado"
FISCAL_CSC_HOMOLOGACAO=codigo-csc-de-homologacao
FISCAL_CSC_PRODUCAO=codigo-csc-de-producao
```
Cuidados: o `.pfx` fica **fora** da pasta do projeto e fora de qualquer zip/backup compartilhado; faça cópia segura dele; o CSC é gerado no portal da SEFAZ do RJ (contador ou acesso com o certificado).

## Como usar
1. Fiscal → Empresa emitente: cadastre a empresa (ambiente **Homologação**) e confira a tela de prontidão.
2. Fiscal → Produtos sem dados fiscais: preencha NCM/CFOP/CSOSN (**confirme com o contador**).
3. Faça uma venda no PDV; em Vendas → detalhe, botão **Gerar NFC-e (assinar)**.
4. Fiscal → Notas fiscais: veja a rastreabilidade e baixe o XML.

## O que NÃO foi possível validar aqui (leia antes de produção)
- **Não há XSD oficial offline nem acesso à SEFAZ** neste ambiente: o XML foi conferido por regras do leiaute que conheço e por ser bem formado, **não** validado contra o schema nem recebido por um autorizador. Rejeições de homologação são esperadas e normais; a Etapa 4 inclui a leitura do retorno e dos motivos.
- **Endereços do QR-Code/consulta do RJ** (`fiscal/nfce/enderecos.py`) vêm de conhecimento prévio; o portal da SEFAZ-RJ bloqueou minha consulta. Confirme em <https://nfce.encat.org/desenvolvedor/qrcode/> ou ajuste `FISCAL_QRCODE_URL` / `FISCAL_URL_CHAVE` no `.env`.
- **IBS/CBS (reforma tributária, NT 2025.002):** conforme a v1.52 consultada, em produção a ausência do grupo não é rejeitada para CRT 1 ("implementação futura"), mas há datas de homologação em andamento e o texto muda. Reconfira a NT vigente antes de produção.
- Testes Django e migrations (`fiscal.0002`) não foram executados aqui. O **núcleo puro** (chave, QR, XML, assinatura com certificado de teste, leitura de `.pfx`, adulteração detectada) foi executado e passou.
- Regime diferente de Simples Nacional, NFC-e com destinatário identificado, ST e demais tributações exigem revisão do contador.

Novos: `fiscal/nfce/*`, modelos/migration `fiscal.0002`, `templates/fiscal/*` (documentos, produtos pendentes). Alterados: `fiscal/{models,forms,views,urls,services,admin}.py`, `config/settings.py` (endereços opcionais), `requirements.txt` (`lxml`, `cryptography`), `templates/base.html` (menu Fiscal em dropdown), `templates/produtos/produto_detail.html` (botão Dados fiscais), `templates/vendas/venda_detail.html` (bloco NFC-e, só Administrador), `loja/env.loja.exemplo`.

## Validar
`pip install -r requirements.txt` · `python manage.py migrate` · `python manage.py makemigrations --check` · `python manage.py test fiscal pdv`.

## Próxima etapa (4): transmissão à SEFAZ (feita, ver Etapa 4 abaixo)
SOAP com certificado de cliente (mTLS) ao autorizador, leitura do protocolo/rejeições (status Autorizada/Rejeitada), consulta por chave, cancelamento e inutilização, DANFE NFC-e e emissão pelo PDV. Só pode ser validada de fato com certificado, CSC e inscrição estadual reais em homologação.


---

# Fase 1 · Etapa 4 — Transmissão à SEFAZ, contingência, cancelamento e inutilização

Continua 100% gratuita: o sistema fala **direto com a SEFAZ** usando o seu certificado A1 (único custo: o certificado).

## O que faz
| Função | Onde | Como funciona |
|---|---|---|
| Canal seguro | `fiscal/nfce/canal.py` | SOAP 1.2 com certificado de cliente (mTLS). Arquivos temporários do certificado são apagados após o uso. Cadeia ICP-Brasil: `FISCAL_CA_BUNDLE` no `.env` se o Windows/Python não a reconhecer |
| Envio | `services.transmitir` | autorização síncrona; trata cStat 100/150 (autorizada), rejeição (guarda o motivo) e 204 (duplicidade → consulta pela chave) |
| Consulta | `services.consultar` | sincroniza a situação da nota com a SEFAZ |
| Cancelamento | `services.cancelar` | evento 110111 com justificativa (15+ caracteres); a SEFAZ decide se o prazo permite |
| Inutilização | `services.inutilizar` | faixa de números não usados; registro imutável |
| Status do serviço | `services.status_servico` | tela **Fiscal → Status da SEFAZ** |
| Contingência offline | `services.emitir_nfce` | sem internet/SEFAZ fora: emite com `tpEmis=9`, justificativa e QR-Code offline; fica "Assinada" e é enviada depois |
| Reenvio | `manage.py transmitir_notas --continuo` | tarefa agendada "PetShopERP - Notas fiscais"; o sistema tenta a cada 60 s; o prazo legal para transmitir nota de contingência (hoje 24 h) **não é checado pelo sistema**, confirme com o contador |
| nfeProc | `sefaz.montar_nfe_proc` | NFe + protocolo, guardado em `xml_autorizado` (é o XML que vale) |

Regras de segurança: nota "normal" assinada há mais de 4 minutos é **regerada** (mesmo número, data nova) antes de enviar, para não estourar o prazo da SEFAZ; a numeração só é consumida se a geração der certo; tudo é auditado em `EventoFiscal` (imutável) e `LogAcao`.

## O que NÃO foi possível validar aqui
- O XML não foi validado contra o **XSD oficial** e nada foi enviado a uma SEFAZ de verdade: rejeições na primeira homologação são esperadas. Os motivos aparecem na nota.
- Endereços: RJ autoriza NFC-e pela **SVRS**. As URLs vêm do portal da SVRS; "RJ em SVRS" foi confirmado só em homologação e por fonte de terceiros. Sobrescreva com `FISCAL_URL_<SERVICO>` no `.env` se algum endereço divergir.
- QR-Code offline (`digVal`): assumi o hexadecimal minúsculo do texto base64 do DigestValue; confirme na homologação.
- Para testar de verdade você precisa de: certificado A1, CSC de homologação e inscrição estadual habilitada para NFC-e.

## Validar
`python manage.py test fiscal` (usa uma SEFAZ falsa; não precisa de internet). Reenvio manual: `python manage.py transmitir_notas`.

---

# Fase 1 · Etapa 5 — Impressão, fila, gaveta e monitoramento (app `impressao`)

## Auditoria que orientou o desenho
- Venda e PDV já existiam e **não foram alterados**; a impressão é um consumidor deles (lê venda, pagamentos, caixa, nota fiscal).
- A regra de ouro: **imprimir nunca bloqueia uma venda**. O trabalho é gravado (bytes + prévia) e só depois enviado; se a impressora falhar, fica na fila e é tentado de novo.
- Reaproveitado: mixins de permissão, `LogFormValidMixin`, `registrar_acao`, modelos protegidos/imutáveis, middleware por app, estilo dos templates.

## Estrutura
| Parte | Arquivo | Função |
|---|---|---|
| ESC/POS | `escpos.py` | texto, alinhamento, negrito, tamanho, linha, QR nativo, EAN-13, Code128, corte, gaveta; prévia em texto |
| Documentos | `documentos.py` | cupom não fiscal, DANFE NFC-e (lido do XML da nota), pedido, etiqueta, senha, recibo, comprovante de caixa, teste, abrir gaveta |
| Transportes | `transports.py` | rede (porta 9100), impressora do Windows (`pywin32`, opcional), serial (`pyserial`, opcional), arquivo (teste) |
| Fila e regras | `services.py` | enfileirar, tentativas com espera crescente (5 s até 5 min, 5 tentativas), reimprimir, tentar de novo, cancelar, monitorar, senha diária |
| Telas | `views.py`, `templates/impressao/*` | Impressoras (só Administrador), Fila (Administrador vê tudo; Vendedor, os seus), detalhe com prévia |
| Serviço | `manage.py processar_impressoes --continuo` | tarefa agendada "PetShopERP - Impressao" |

## Onde aparecem os botões
Venda (Imprimir cupom / pedido) · PDV (Abrir gaveta, Emitir senha) · Caixa (Imprimir na térmica) · Produto (Etiqueta, com cópias; Administrador) · Nota fiscal (Imprimir DANFE; Administrador) · menu **Impressão**. Ao fechar uma venda no PDV o cupom sai sozinho **se houver impressora cadastrada** (desligue com `IMPRESSAO_AUTO_PDV=False` no `.env`).

## Marcas e configuração
Daruma, Elgin, Bematech e Epson térmicas falam o núcleo ESC/POS. As diferenças (colunas, página de código dos acentos, tipo de corte, pino da gaveta) são **campos da impressora**, não código: ajuste em Impressão → Impressoras e use **Imprimir teste**. Dica: conecte a impressora por **rede (IP fixo)** quando possível; USB/serial exigem instalar `pywin32`/`pyserial` (`.venv\Scripts\pip install pywin32`) e a tarefa agendada roda como SYSTEM, que pode não enxergar impressoras USB instaladas só para o seu usuário (use `-AoEntrar` no `instalar_tarefas.ps1` nesse caso).

## Migrations e dados
`impressao.0001_initial` (3 tabelas novas) e `logs.0005` (só rótulo `IMPRESSAO`). Nenhuma tabela existente foi alterada.

## O que NÃO foi possível validar aqui
- **Nenhuma impressora real foi testada** (você ainda não tem). Os comandos seguem o ESC/POS de manual; a rede foi testada com um servidor local simulado. Espere ajustar página de código/corte/gaveta no primeiro teste.
- Django, migrations e testes (`python manage.py test impressao`) não foram executados neste ambiente.
- QR-Code do DANFE usa o QR nativo da impressora (modelos muito antigos podem não ter); a etiqueta usa EAN-13/Code128 nativos.

## Validar
`pip install -r requirements.txt` · `python manage.py migrate` · `python manage.py makemigrations --check` · `python manage.py test pdv fiscal impressao` · em Impressão → Impressoras: cadastre uma impressora tipo **Arquivo**, clique em **Imprimir teste** e abra o arquivo em `var\impressao`.

---

# Fechamento do escopo: o que foi feito e o que ficou de fora (com motivo)

| Pedido | Situação |
|---|---|
| NFC-e: emissão, assinatura, QR-Code, DANFE, consulta, cancelamento, inutilização, contingência, certificado A1 | **Feito** (Etapas 2–5), sem validação em SEFAZ real |
| PDV: caixa, operadores, sangria, suprimento, fechamento, cupom não fiscal | **Feito** (Etapa 1 e 5) |
| Impressão: fila, reimpressão, ESC/POS (Daruma/Elgin/Bematech), gaveta, senhas, etiquetas, pedidos, comprovantes, monitoramento | **Feito** (Etapa 5), sem hardware real |
| Auditoria/rastreabilidade | **Feito**: `LogAcao`, `EventoFiscal`, `TrabalhoImpressao` |
| Multiempresa/estado | **Parcial**: empresas múltiplas e UF por empresa; endereços de SEFAZ cadastrados só para RJ/SVRS (outros estados: informe `FISCAL_URL_*`) |
| Leitor de código de barras | **Já funciona** (leitor USB age como teclado; o PDV já aceita) |
| Balança e produtos pesáveis | **Feito na Etapa 6** (abaixo): venda por kg, estoque fracionado e leitura de etiqueta de balança. Comunicação direta com a balança (cabo/protocolo) **não** foi feita |
| NF-e (modelo 55), CC-e, DANFE em PDF, cadastro de clientes | **Feito na Etapa 7** (abaixo), só venda **dentro do mesmo estado**, sem validação em SEFAZ real e sem contingência. Inutilização de NF-e não foi feita (só NFC-e) |
| NFS-e | **Adiado**: é **municipal** (cada prefeitura tem seu sistema/padrão); só dá para fazer com o manual do seu município |
| SAT | **Não se aplica ao RJ** (é do estado de SP); a NFC-e cobre o varejo no RJ |
| API desacoplada / SaaS | **Preparado**: núcleos sem Django (`fiscal/nfce`, `impressao/escpos.py`), serviços em `services.py`, multiempresa. API HTTP externa não foi criada (sem demanda atual) |


---

# Fase 1 · Etapa 6 — Produtos pesáveis (kg) e etiqueta de balança

## O que mudou (e por quê é seguro)
- **Quantidade agora aceita fração (3 casas)** em `Produto.quantidade`, `MovimentacaoEstoque` (quantidade/anterior/nova) e `ItemVenda.quantidade`. No banco vira `numeric(12,3)`; os dados existentes são convertidos sem perda (2 → 2,000).
- O novo campo `core.fields.QuantidadeField` devolve **inteiro quando a quantidade é inteira** (2) e decimal só quando há fração (0,745). Por isso telas, Excel, dashboard e contas que já existiam continuam iguais.
- **Produto novo campo "vendido por peso"** (`Produto.pesavel`, padrão: não). Produto por unidade continua exigindo quantidade **inteira** (venda, estoque, entrada manual, estoque inicial). Não dá para desmarcar "por peso" enquanto o estoque for fracionado.
- **Arredondamento por item (meio para cima), igual à NFC-e**: `ItemVenda.subtotal`, total da venda, total do PDV, tela e XML usam a mesma regra (`core.utils.valor_item`), então o total da venda sempre bate com a nota.
- NFC-e: quantidade com 4 casas; produto "por peso" com unidade fiscal "UN" sai como **KG** automaticamente. Cupom/etiqueta mostram KG.
- Reaproveitado sem alteração: `Venda.registrar_venda`, `MovimentacaoEstoque.registrar` (só ganharam a leitura decimal), permissões, auditoria, caixa.

## Etiqueta de balança (leitor de código de barras)
Etiqueta EAN-13 que começa com `2`: `2 CCCCCC VVVVV D` (código do produto + peso em gramas, ou valor em centavos). Cadastre o produto por peso com o **código de barras = os 6 dígitos do código da balança** (zeros à esquerda não importam) e passe a etiqueta no leitor da tela de venda/PDV: o produto entra com o peso lido. Sem etiqueta, digite o peso (campo aceita 0,745). O formato é configurável no `.env` (`BALANCA_PREFIXO`, `BALANCA_DIGITOS_CODIGO`, `BALANCA_DIGITOS_VALOR`, `BALANCA_MODO=PESO|PRECO`): **confira no manual da sua balança**, pois varia entre marcas.

## Migrations
`produtos.0003`, `estoque.0003`, `vendas.0002` (alteram o tipo das colunas de quantidade e criam checagens de "não negativo"). **Faça backup antes de migrar** (`loja\backup_banco.bat`). A conversão não apaga dados, mas mexe em tabelas de vendas e estoque.

## O que NÃO foi possível validar aqui
- Django/migrations/testes não foram executados (`python manage.py test vendas.test_pesaveis`). Confira `makemigrations --check` depois de migrar.
- O leitor de etiqueta foi testado só no algoritmo (Python e `node --check`); falta teste no navegador com leitor e balança reais.
- Não há integração direta com balança por cabo (Toledo/Filizola/etc.): o peso entra por etiqueta ou digitação.
- Estoque mínimo continua inteiro; Excel importa/exporta quantidade, mas a importação de estoque fracionado não foi tratada (aceita inteiros).


---

# Fase 1 · Etapa 7 — NF-e (modelo 55), clientes, Carta de Correção e DANFE em PDF

## O que foi feito (reaproveitando a NFC-e)
- **Mesmo motor da NFC-e**: montagem de XML, assinatura A1, canal SOAP/mTLS, numeração, protocolo, consulta e cancelamento ganharam o parâmetro `modelo` ("65" ou "55"). Nada da NFC-e foi alterado no comportamento.
- **Clientes** (`fiscal.Cliente`): nome, CPF/CNPJ validado, indicador de IE, endereço, código IBGE. Tela em *Fiscal → Clientes (NF-e)*; só administrador.
- **Emissão**: na tela da venda (administrador) há "Emitir NF-e" com a escolha do destinatário. A venda pode ter uma NFC-e **e** uma NF-e. Numeração e série próprias (`Empresa.serie_nfe`, padrão 1).
- **Regras aplicadas**: bloqueia cliente de outro estado; venda sem pagamento sai com `tPag 90`; sem QR-Code; em homologação o nome do destinatário recebe o texto exigido; só emite com a SEFAZ no ar (a NF-e **não** tem contingência offline).
- **Carta de Correção (CC-e)**: evento 110110 assinado, texto de 15 a 1000 caracteres, sequência de 1 a 20 por nota, guardada em `fiscal.CartaCorrecao` (imutável). Carta recusada não consome a sequência.
- **DANFE em PDF** (reportlab): botão "DANFE (PDF)" na nota. A impressora térmica continua só para NFC-e.
- Cancelamento de NF-e usa o mesmo botão da NFC-e.

## Migrations
- `fiscal.0004_nfe_modelo55` (nova tabela `Cliente`, `CartaCorrecao`, campos `serie_nfe` e `cliente`, rótulos). Nenhuma tabela existente é alterada além de colunas novas.
- Nova dependência: `reportlab` (`pip install -r requirements.txt`).

## O que NÃO foi possível validar aqui (leia antes de produção)
- Django não roda neste ambiente: **migrations e testes Django não foram executados**. Só o núcleo puro (XML 55, assinatura, CC-e, validadores, PDF) foi testado.
- XML **não foi validado contra o XSD oficial** nem enviado a uma SEFAZ real. Teste em homologação antes de usar.
- Endereços de NF-e do RJ via SVRS vieram de fonte de terceiros; confirme no Portal da NF-e e, se preciso, use `FISCAL_URL_NFE_*` no `.env`.
- DANFE em PDF é um **layout simplificado** (dados completos, mas não idêntico ao leiaute oficial).
- Só Simples Nacional (CSOSN). CFOP e demais dados tributários **confirme com seu contador**. Campos de IBS/CBS (reforma tributária) não foram incluídos.
- Fora do escopo: NF-e interestadual, transporte/frete, inutilização de NF-e, NFS-e (municipal) e SAT (não se aplica ao RJ).

## Validar
```
pip install -r requirements.txt
python manage.py makemigrations --check
python manage.py migrate
python manage.py test fiscal pdv impressao vendas.test_pesaveis
```


---

# Preparação para domínio próprio (configuração 100% no `.env`)

- **`.env.example`** agora é o modelo completo, com todas as variáveis comentadas (núcleo, hosts, HTTPS/proxy, servidor, banco, backup, e-mail, fiscal, impressão, balança).
- **`DJANGO_DOMINIO`**: uma linha só; é somada a `ALLOWED_HOSTS` e `CSRF_TRUSTED_ORIGINS` (com `https://`). Lógica pura em `config/dominios.py` (testada em `config/test_dominios.py`).
- **Novas variáveis**: `SITE_NOME`, `SITE_URL` (nome/endereço mostrados no sistema, via `core.context_processors.site`), `SERVIDOR_HOST/PORTA/THREADS/PROXY_CONFIAVEL`, `DB_SSLMODE`, `DJANGO_SESSAO_HORAS`, `DJANGO_HSTS_SUBDOMINIOS`, `DJANGO_LOG_LEVEL`, `EMAIL_*`. Todas têm padrão igual ao comportamento anterior: **quem não mexer no `.env` não vê diferença**.
- **Servidor**: `loja\iniciar_servidor.bat` agora roda `python -m config.servidor` (Waitress lendo o `.env`). `instalar_tarefas.ps1` abre no firewall a porta do `.env`. `backup_banco.bat` usa `DB_HOST`/`DB_PORT`.
- **Passo a passo**: `loja/DOMINIO.md`.
- **Não validado**: não foi possível rodar Django/Waitress aqui; a opção `SERVIDOR_PROXY_CONFIAVEL` (Cloudflare Tunnel/Nginx) é a mais sujeita a ajuste: se o login falhar após ligar o domínio, siga a seção 3 do `DOMINIO.md` e me envie o erro.
