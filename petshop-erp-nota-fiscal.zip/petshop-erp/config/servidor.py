"""
Servidor de produção (Waitress) lido do .env, para a porta e os proxies não ficarem fixos:
    python -m config.servidor
Variáveis (todas opcionais): SERVIDOR_HOST (0.0.0.0), SERVIDOR_PORTA (8000),
SERVIDOR_THREADS (8) e SERVIDOR_PROXY_CONFIAVEL (ex.: 127.0.0.1, para Cloudflare Tunnel/Nginx
na mesma máquina: faz o sistema entender que o acesso original foi por HTTPS e ver o IP real).
"""

from decouple import config
from waitress import serve

from config.wsgi import application


def main():
    opcoes = dict(
        host=config("SERVIDOR_HOST", default="0.0.0.0"),
        port=config("SERVIDOR_PORTA", default=8000, cast=int),
        threads=config("SERVIDOR_THREADS", default=8, cast=int),
    )
    proxy = config("SERVIDOR_PROXY_CONFIAVEL", default="").strip()
    if proxy:
        opcoes.update(
            trusted_proxy=proxy,
            trusted_proxy_count=1,
            trusted_proxy_headers={"x-forwarded-for", "x-forwarded-proto", "x-forwarded-host"},
        )
    print(f"Servidor em http://{opcoes['host']}:{opcoes['port']} (proxy confiável: {proxy or 'nenhum'})", flush=True)
    serve(application, **opcoes)


if __name__ == "__main__":
    main()
