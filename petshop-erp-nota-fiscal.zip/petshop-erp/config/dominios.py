"""
Funções puras (sem Django) para montar hosts e origens confiáveis a partir do
domínio informado no .env (DJANGO_DOMINIO). Aceita "meusite.com.br",
"https://meusite.com.br/", vários separados por vírgula e porta ("meusite.com.br:8443").
"""

import re


def normalizar_dominios(texto):
    """Devolve a lista de domínios limpos (sem http://, sem barra, minúsculos, sem repetição)."""
    vistos = []
    for bruto in (texto or "").split(","):
        item = re.sub(r"^[a-z]+://", "", bruto.strip().lower()).split("/")[0].strip()
        if item and item not in vistos:
            vistos.append(item)
    return vistos


def hosts_e_origens(dominios, https=True):
    """
    (hosts, origens) para ALLOWED_HOSTS e CSRF_TRUSTED_ORIGINS.
    Com https=True as origens são https://; com https=False, http://.
    """
    esquema = "https" if https else "http"
    hosts = [re.sub(r":\d+$", "", d) for d in dominios]
    origens = [f"{esquema}://{d}" for d in dominios]
    return hosts, origens
