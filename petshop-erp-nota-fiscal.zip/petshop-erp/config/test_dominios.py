from django.test import SimpleTestCase

from .dominios import hosts_e_origens, normalizar_dominios


class DominiosTests(SimpleTestCase):
    def test_normaliza_url_colada_e_repetidos(self):
        self.assertEqual(
            normalizar_dominios(" https://Loja.Exemplo.com.br/ , loja.exemplo.com.br,www.exemplo.com.br "),
            ["loja.exemplo.com.br", "www.exemplo.com.br"],
        )

    def test_vazio(self):
        self.assertEqual(normalizar_dominios(""), [])
        self.assertEqual(normalizar_dominios(None), [])

    def test_hosts_e_origens_com_porta(self):
        hosts, origens = hosts_e_origens(["a.com.br", "b.com.br:8443"])
        self.assertEqual(hosts, ["a.com.br", "b.com.br"])
        self.assertEqual(origens, ["https://a.com.br", "https://b.com.br:8443"])
        self.assertEqual(hosts_e_origens(["a.com.br"], https=False)[1], ["http://a.com.br"])
