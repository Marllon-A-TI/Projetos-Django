@echo off
rem Backup do banco do Pet Shop ERP (pg_dump). Mantem os 30 mais recentes.
rem Se BACKUP_COPIA_EXTERNA estiver no .env, copia o arquivo para la tambem.
setlocal
cd /d "%~dp0.."
if not exist var\backups mkdir var\backups
if not exist var\log mkdir var\log

set "DB_USER=petshop_user"
set "DB_NAME=petshop_db"
set "DB_HOST=localhost"
set "DB_PORT=5432"
set "COPIA="
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  if /i "%%A"=="DB_USER" set "DB_USER=%%B"
  if /i "%%A"=="DB_NAME" set "DB_NAME=%%B"
  if /i "%%A"=="DB_HOST" set "DB_HOST=%%B"
  if /i "%%A"=="DB_PORT" set "DB_PORT=%%B"
  if /i "%%A"=="DB_PASSWORD" set "PGPASSWORD=%%B"
  if /i "%%A"=="BACKUP_COPIA_EXTERNA" set "COPIA=%%B"
)

set "PGBIN="
for /d %%D in ("C:\Program Files\PostgreSQL\*") do set "PGBIN=%%D\bin"
if not defined PGBIN (
  echo [%date% %time%] ERRO: PostgreSQL nao encontrado em C:\Program Files\PostgreSQL >> var\log\backup.log
  exit /b 1
)

for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmm"') do set "DATA=%%I"
set "ARQUIVO=var\backups\petshop_%DATA%.dump"

"%PGBIN%\pg_dump.exe" -h %DB_HOST% -p %DB_PORT% -U %DB_USER% -Fc -f "%ARQUIVO%" %DB_NAME%
if errorlevel 1 (
  echo [%date% %time%] ERRO no pg_dump >> var\log\backup.log
  if exist "%ARQUIVO%" del "%ARQUIVO%"
  exit /b 1
)

rem Confere que o arquivo gerado e legivel
"%PGBIN%\pg_restore.exe" -l "%ARQUIVO%" >nul 2>&1
if errorlevel 1 (
  echo [%date% %time%] ERRO: backup gerado esta corrompido: %ARQUIVO% >> var\log\backup.log
  exit /b 1
)

if defined COPIA (
  if exist "%COPIA%\" (
    copy /y "%ARQUIVO%" "%COPIA%\" >nul
    if errorlevel 1 (echo [%date% %time%] AVISO: nao consegui copiar para %COPIA% >> var\log\backup.log)
  ) else (
    echo [%date% %time%] AVISO: pasta de copia nao existe: %COPIA% >> var\log\backup.log
  )
)

powershell -NoProfile -Command "Get-ChildItem 'var\backups\petshop_*.dump' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 30 | Remove-Item -Force"
echo [%date% %time%] OK %ARQUIVO% >> var\log\backup.log
exit /b 0
