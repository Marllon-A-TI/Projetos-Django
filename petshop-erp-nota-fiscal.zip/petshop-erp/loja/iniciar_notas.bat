@echo off
rem Reenvia a SEFAZ as NFC-e pendentes (contingencia ou queda de internet).
rem Chamado pela Tarefa Agendada "PetShopERP - Notas fiscais". Reinicia sozinho se parar.
cd /d "%~dp0.."
if not exist var\log mkdir var\log
:inicio
".venv\Scripts\python.exe" manage.py transmitir_notas --continuo --intervalo 60 >> var\log\notas.log 2>&1
ping -n 11 127.0.0.1 >nul
goto inicio
