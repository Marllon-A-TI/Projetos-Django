@echo off
rem Imprime os trabalhos que ficaram na fila de impressao (impressora desligada, sem papel...).
rem Chamado pela Tarefa Agendada "PetShopERP - Impressao". Reinicia sozinho se parar.
cd /d "%~dp0.."
if not exist var\log mkdir var\log
:inicio
".venv\Scripts\python.exe" manage.py processar_impressoes --continuo --intervalo 5 >> var\log\impressao.log 2>&1
ping -n 11 127.0.0.1 >nul
goto inicio
