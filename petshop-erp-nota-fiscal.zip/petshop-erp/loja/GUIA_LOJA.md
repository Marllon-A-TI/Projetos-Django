# Pet Shop ERP no PC da loja (Windows, sem pagar nada)

Resultado final: ao ligar o PC da loja, o sistema sobe sozinho. Qualquer celular, tablet ou computador **conectado ao mesmo Wi-Fi/rede da loja** abre `http://IP-DO-PC:8000`. Você nunca mais digita `runserver`.

Arquitetura: `Aparelhos da loja → Waitress (servidor, porta 8000 por padrão; troca em `SERVIDOR_PORTA` no `.env`) → Django → PostgreSQL`, tudo dentro do PC da loja.

> Os scripts da pasta `loja/` foram escritos com cuidado, mas **não puderam ser testados num Windows real** por quem os criou. Siga os passos na ordem e, se algo falhar, envie a mensagem de erro inteira junto com o número do passo.

Recomendação: faça primeiro todo o roteiro no **seu** computador (troque "IP do PC da loja" por `localhost`) para ensaiar. Depois repita no PC da loja.

---

## Passo 1: Preparar o PC da loja

1. **Não deixar o PC dormir** (se ele suspender, o sistema some da rede). Em Configurações → Sistema → Energia (ou "Energia e bateria"), ajuste **Suspender/Hibernar para "Nunca"** quando ligado na tomada. A tela pode apagar à vontade.
2. **Rede como "Privada".** Em Configurações → Rede e Internet → (Wi-Fi ou Ethernet) → sua rede → **Tipo de perfil de rede: Privada**. Em rede "Pública" o Windows bloqueia o acesso dos outros aparelhos.
3. **Fixar o endereço (IP) do PC**, senão ele pode mudar e os aparelhos deixam de achar o sistema. O jeito mais confiável é no **roteador**: procure "Reserva de DHCP" ou "IP estático por MAC" e reserve um IP para este PC. Se preferir fixar no Windows: Configurações → Rede e Internet → sua conexão → "Atribuição de IP" → Editar → Manual. Se tiver dúvida, me diga o modelo do roteador.
4. Veja o IP atual: abra o PowerShell e rode `ipconfig`. Anote o **"Endereço IPv4"** (algo como `192.168.0.25`). Daqui para frente ele aparece como `IP_DO_PC`.
5. Crie a pasta `C:\PetShop` (sem espaços no caminho) e copie para dentro dela a pasta do projeto, ficando `C:\PetShop\petshop-erp`. Não copie o seu `.env` antigo nem a pasta `.venv` do seu computador; criaremos novos aqui.

## Passo 2: Instalar o Python

Instale o Python **da mesma forma e versão que você usa no seu computador** (python.org/downloads). Confirme no PowerShell:

```
python --version
```

Deve mostrar a versão. Se disser que não encontrou o comando, a instalação não colocou o Python no caminho (PATH): refaça marcando a opção "Add python.exe to PATH" (ou equivalente) e abra um PowerShell novo.

## Passo 3: Instalar o PostgreSQL

1. Baixe o instalador para Windows em https://www.postgresql.org/download/windows/ (botão "Download the installer", que leva ao site da EDB; a versão mais recente é a 18).
2. Execute e vá avançando. Os pontos que importam:
   - **Senha do superusuário `postgres`:** escolha e **anote** (só letras e números).
   - **Porta:** deixe 5432.
   - Pode deixar todos os componentes marcados (inclui o pgAdmin e o SQL Shell).
3. No final, se perguntar sobre o "Stack Builder", pode cancelar/desmarcar.
4. O PostgreSQL já se instala como **serviço do Windows**, então inicia sozinho com o PC.

### Criar o usuário e o banco

Abra o programa **SQL Shell (psql)** no menu Iniciar. Aperte **Enter** quatro vezes (Server, Database, Port, Username: ficam nos padrões) e digite a senha do `postgres`. Depois rode, uma linha por vez (troque `SENHA_DO_BANCO` por uma senha nova, só letras e números, e anote):

```
CREATE USER petshop_user WITH PASSWORD 'SENHA_DO_BANCO';
CREATE DATABASE petshop_db OWNER petshop_user ENCODING 'UTF8' TEMPLATE template0 LOCALE_PROVIDER icu ICU_LOCALE 'pt-BR' LOCALE 'C';
\q
```

Se o segundo comando der erro, use esta versão alternativa (funciona sempre; só ordena os nomes pela tabela de caracteres em vez do alfabeto):

```
CREATE DATABASE petshop_db OWNER petshop_user ENCODING 'UTF8' TEMPLATE template0 LC_COLLATE 'C' LC_CTYPE 'C';
```

## Passo 4: Instalar o sistema

No PowerShell:

```
cd C:\PetShop\petshop-erp
python -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Se o último comando falhar em algum pacote (principalmente `psycopg`), envie a mensagem inteira.

### Criar o arquivo de configuração `.env`

```
copy loja\env.loja.exemplo .env
.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(60))"
notepad .env
```

O segundo comando imprime uma chave: copie. No Bloco de Notas, troque:
- `COLE_AQUI_A_CHAVE_GERADA` pela chave copiada;
- as **duas** ocorrências de `IP_DO_PC` pelo IP do passo 1;
- `DJANGO_ADMIN_URL` por um nome só seu (ex.: `gestao-7k2x/`);
- `SENHA_DO_BANCO` pela senha do banco do passo 3.

Salve (Ctrl+S) e feche. Confirme que o arquivo se chama `.env` e **não** `.env.txt`.

### Preparar o banco e os arquivos visuais

```
.venv\Scripts\python.exe manage.py migrate
.venv\Scripts\python.exe manage.py criar_grupos
.venv\Scripts\python.exe manage.py collectstatic --noinput
.venv\Scripts\python.exe manage.py createsuperuser
```

No último, escolha login, e-mail e uma senha forte: será o seu Administrador.

## Passo 5: Testar na mão (uma vez)

```
.venv\Scripts\python.exe -m config.servidor
```

Abra no navegador do próprio PC `http://localhost:8000`: deve aparecer a tela de login com o visual completo. Entre com o administrador. Feche o teste com **Ctrl+C** no PowerShell.

## Passo 6: Ligar sozinho com o Windows

Abra o PowerShell **como Administrador** (botão direito no PowerShell → Executar como administrador) e rode:

```
cd C:\PetShop\petshop-erp
powershell -ExecutionPolicy Bypass -File .\loja\instalar_tarefas.ps1
```

O script cria duas Tarefas Agendadas (servidor ao ligar o PC e backup diário às 21:00), libera a porta 8000 no firewall (só para redes privadas), liga o servidor e mostra os endereços de acesso.

**Se depois de reiniciar o PC o sistema não subir sozinho:** rode o script de novo com `-AoEntrar` no final. Nesse modo o servidor inicia quando o usuário entra no Windows. Se a loja usar login automático, resolve.

## Passo 7: Testar tudo

1. No PC da loja: `http://localhost:8000` abre e dá login.
2. No **celular** (conectado ao Wi-Fi da loja): `http://IP_DO_PC:8000` abre e dá login.
3. **Reinicie o PC**, espere 2 minutos e teste de novo o endereço (sem digitar nada no PC): tem que abrir sozinho.
4. Entre como Administrador → **Produtos → Importar Excel** e carregue a sua lista de produtos reais.
5. Confira o backup: abra o Agendador de Tarefas (menu Iniciar → "Agendador de Tarefas"), clique com o botão direito em "PetShopERP - Backup diario" → Executar. Em seguida veja se apareceu um arquivo `.dump` em `C:\PetShop\petshop-erp\var\backups` e a linha "OK" em `var\log\backup.log`.

## Impressora térmica (quando comprar)
1. Ligue a impressora **na rede (cabo) com IP fixo** ou por USB. Imprima o autoteste dela para ver o IP.
2. Entre como Administrador → **Impressão → Impressoras → Nova impressora**. Rede: informe o IP (ex.: `192.168.0.50`). USB: instale `pywin32` (`.venv\Scripts\pip install pywin32`) e informe o nome da impressora no Windows.
3. Clique em **Verificar** e depois **Imprimir teste**. Acentos errados? mude a "página de código". Não corta? troque o "tipo de corte". Gaveta não abre? marque "tem gaveta" e tente o outro pino.
4. As tarefas "PetShopERP - Impressao" e "PetShopERP - Notas fiscais" (criadas pelo `instalar_tarefas.ps1`) reenviam sozinhas o que ficou pendente. Logs em `var\log\impressao.log` e `var\log\notas.log`.

## Backups (importante)

O backup diário fica no **mesmo PC**: se o disco morrer, ele vai junto. Faça uma destas duas coisas:
- Pendrive ou HD externo: no `.env`, tire o `#` da linha `BACKUP_COPIA_EXTERNA` e ponha a letra da unidade (ex.: `BACKUP_COPIA_EXTERNA=E:\Backups`, criando a pasta antes). A cópia só acontece com o dispositivo conectado.
- Google Drive para computador (ou OneDrive): aponte `BACKUP_COPIA_EXTERNA` para uma pasta sincronizada.

Além disso, uma vez por semana use **Produtos → Exportar Excel**, que também serve de cópia dos produtos.

**Restaurar um backup** (apaga e recria os dados do banco com os do arquivo; pare o servidor antes):

```
Stop-ScheduledTask -TaskName "PetShopERP - Servidor"
& "C:\Program Files\PostgreSQL\18\bin\pg_restore.exe" --clean --if-exists -h localhost -U petshop_user -d petshop_db "C:\PetShop\petshop-erp\var\backups\ARQUIVO.dump"
Start-ScheduledTask -TaskName "PetShopERP - Servidor"
```

(O número `18` é a versão que você instalou.)

## Atualizar o sistema no futuro

1. Pare o servidor: `Stop-ScheduledTask -TaskName "PetShopERP - Servidor"` (se continuar respondendo, `taskkill /f /im waitress-serve.exe`).
2. Copie os arquivos novos **por cima**, sem apagar `.env`, `.venv` e `var`.
3. No PowerShell, na pasta do projeto:
   ```
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   .venv\Scripts\python.exe manage.py migrate
   .venv\Scripts\python.exe manage.py collectstatic --noinput
   Start-ScheduledTask -TaskName "PetShopERP - Servidor"
   ```
4. Antes de atualizar, rode um backup manual (Agendador de Tarefas → Executar).

## Quando algo não funciona

| Sintoma | Causa provável e solução |
|---|---|
| O celular não abre o endereço | Rede do PC está como "Pública" (passo 1); celular em outro Wi-Fi (ex.: visitantes); IP do PC mudou (`ipconfig`); servidor parado (veja o próximo item). |
| Servidor parado | Olhe `var\log\servidor.log` (últimas linhas) e `Get-ScheduledTask "PetShopERP*" \| Get-ScheduledTaskInfo`. Tente o passo 5 na mão para ver o erro na tela. |
| "Bad Request (400)" | O IP usado no navegador não está em `DJANGO_ALLOWED_HOSTS` no `.env`. Ajuste e reinicie a tarefa. |
| Erro de CSRF no login | Confira `DJANGO_CSRF_TRUSTED_ORIGINS` (com `http://` e a porta `:8000`). |
| Login "não pega" / volta ao login | As quatro linhas `DJANGO_BEHIND_PROXY`, `DJANGO_SECURE_SSL_REDIRECT`, `DJANGO_HSTS_SECONDS`, `DJANGO_COOKIES_SECURE` devem estar como no modelo. |
| Tela sem visual (sem cores) | Faltou o `collectstatic` do passo 4. |
| Depois de reiniciar o PC o sistema não volta | Rode `instalar_tarefas.ps1 -AoEntrar` (passo 6). |

Reiniciar o servidor: `Stop-ScheduledTask -TaskName "PetShopERP - Servidor"` e depois `Start-ScheduledTask -TaskName "PetShopERP - Servidor"`.

## Segurança (resumo)

- O acesso é por HTTP (sem cadeado) dentro da rede da loja: quem estiver no mesmo Wi-Fi poderia, em teoria, ver o tráfego. Use senha forte no Wi-Fi e **não** libere a porta 8000 no roteador para a internet.
- Use senhas fortes nos usuários do sistema e mantenha o Windows atualizado.
- O PC da loja guarda todos os dados: use uma conta de Windows com senha e mantenha os backups externos.
- Acesso de fora da loja, no futuro: dá para adicionar depois (por exemplo com Tailscale), sem mudar o que foi feito aqui.
