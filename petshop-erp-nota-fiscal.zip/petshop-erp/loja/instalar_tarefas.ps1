# Cria as Tarefas Agendadas do Pet Shop ERP e libera a porta do servidor (SERVIDOR_PORTA, padrao 8000) no firewall.
# Execute no PowerShell COMO ADMINISTRADOR:
#   powershell -ExecutionPolicy Bypass -File .\loja\instalar_tarefas.ps1
# Se o servidor nao subir sozinho ao ligar o PC, rode de novo com -AoEntrar
# (inicia quando o usuario entra no Windows, em vez de ao ligar).
param([switch]$AoEntrar)
$ErrorActionPreference = "Stop"

$eAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $eAdmin) {
    Write-Host "ERRO: abra o PowerShell como Administrador (botao direito > Executar como administrador)." -ForegroundColor Red
    exit 1
}

$raiz = Split-Path -Parent $PSScriptRoot
$servidor = Join-Path $PSScriptRoot "iniciar_servidor.bat"
$backup = Join-Path $PSScriptRoot "backup_banco.bat"
$usuario = "$env:USERDOMAIN\$env:USERNAME"

# Porta do servidor: SERVIDOR_PORTA do .env (padrao 8000)
$porta = 8000
$arquivoEnv = Join-Path $raiz ".env"
if (Test-Path $arquivoEnv) {
    $achou = Select-String -Path $arquivoEnv -Pattern '^\s*SERVIDOR_PORTA\s*=\s*(\d+)' | Select-Object -First 1
    if ($achou) { $porta = [int]$achou.Matches[0].Groups[1].Value }
}

if (-not (Test-Path (Join-Path $raiz ".venv\Scripts\waitress-serve.exe"))) {
    Write-Host "ERRO: .venv\Scripts\waitress-serve.exe nao encontrado. Rode o pip install -r requirements.txt antes." -ForegroundColor Red
    exit 1
}

if ($AoEntrar) {
    $gatilhoServidor = New-ScheduledTaskTrigger -AtLogOn -User $usuario
    $principal = New-ScheduledTaskPrincipal -UserId $usuario -LogonType Interactive -RunLevel Limited
} else {
    $gatilhoServidor = New-ScheduledTaskTrigger -AtStartup
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
}

$config = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew

$acaoServidor = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$servidor`"" -WorkingDirectory $raiz
Register-ScheduledTask -TaskName "PetShopERP - Servidor" -Action $acaoServidor -Trigger $gatilhoServidor `
    -Principal $principal -Settings $config -Force | Out-Null

$acaoBackup = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$backup`"" -WorkingDirectory $raiz
$gatilhoBackup = New-ScheduledTaskTrigger -Daily -At "21:00"
Register-ScheduledTask -TaskName "PetShopERP - Backup diario" -Action $acaoBackup -Trigger $gatilhoBackup `
    -Principal $principal -Settings $config -Force | Out-Null

$impressao = Join-Path $PSScriptRoot "iniciar_impressao.bat"
$notas = Join-Path $PSScriptRoot "iniciar_notas.bat"
$acaoImpressao = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$impressao`"" -WorkingDirectory $raiz
Register-ScheduledTask -TaskName "PetShopERP - Impressao" -Action $acaoImpressao -Trigger $gatilhoServidor `
    -Principal $principal -Settings $config -Force | Out-Null
$acaoNotas = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$notas`"" -WorkingDirectory $raiz
Register-ScheduledTask -TaskName "PetShopERP - Notas fiscais" -Action $acaoNotas -Trigger $gatilhoServidor `
    -Principal $principal -Settings $config -Force | Out-Null

Remove-NetFirewallRule -DisplayName "PetShop ERP (porta $porta)" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "PetShop ERP (porta $porta)" -Direction Inbound -Protocol TCP -LocalPort $porta `
    -Action Allow -Profile Private,Domain | Out-Null

Start-ScheduledTask -TaskName "PetShopERP - Servidor"
Start-ScheduledTask -TaskName "PetShopERP - Impressao"
Start-ScheduledTask -TaskName "PetShopERP - Notas fiscais"

Write-Host ""
Write-Host "Pronto. Tarefas criadas e servidor iniciado." -ForegroundColor Green
Write-Host "Acesse de qualquer aparelho da loja (mesma rede) em um destes enderecos:"
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike "169.254*" -and $_.IPAddress -ne "127.0.0.1" } |
    ForEach-Object { Write-Host ("  http://" + $_.IPAddress + ":" + $porta) }
Write-Host "Backup diario as 21:00 (var\backups). Logs em var\log."
