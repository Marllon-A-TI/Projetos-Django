# Quando comprar um domínio: o que trocar

Tudo é feito no arquivo `.env` (pasta do projeto). **Nenhum código muda.**

## 1) Escolha como o domínio chega até o PC da loja
- **Cloudflare Tunnel (recomendado, gratuito):** o PC da loja "liga para fora" e não precisa abrir porta no roteador nem ter IP fixo. O HTTPS é automático. Instale o `cloudflared`, aponte `petshop.seudominio.com.br` para `http://localhost:8000` (a porta do `SERVIDOR_PORTA`).
- **Nginx/Caddy no próprio PC ou numa VPS:** também serve; use o HTTPS que ele fornecer.

## 2) Ajuste o `.env`
| Variável | Valor com domínio |
|---|---|
| `DJANGO_DOMINIO` | `petshop.seudominio.com.br` (vários: separe por vírgula; pode colar com `https://`) |
| `SITE_URL` | `https://petshop.seudominio.com.br` |
| `DJANGO_BEHIND_PROXY` | `True` |
| `DJANGO_SECURE_SSL_REDIRECT` | `True` |
| `DJANGO_HSTS_SECONDS` | `31536000` (só depois de confirmar que o HTTPS funciona; comece com `300`) |
| `DJANGO_COOKIES_SECURE` | `True` |
| `SERVIDOR_PROXY_CONFIAVEL` | `127.0.0.1` (túnel/Nginx na mesma máquina) |
| `CLIENT_IP_HEADER` | `HTTP_CF_CONNECTING_IP` (Cloudflare) ou `HTTP_X_REAL_IP` (Nginx) |

`DJANGO_DOMINIO` já é somado a `DJANGO_ALLOWED_HOSTS` e `DJANGO_CSRF_TRUSTED_ORIGINS`: você pode manter o IP da loja funcionando junto. Atenção: com `DJANGO_COOKIES_SECURE=True` o acesso por `http://IP_DO_PC:8000` deixa de permitir login. Se quiser os dois jeitos, use o domínio também dentro da loja.

## 3) Reinicie e confira
1. Reinicie o servidor (Tarefa Agendada "PetShopERP - Servidor", ou reinicie o PC).
2. Abra `https://petshop.seudominio.com.br`: deve aparecer o login e o cadeado.
3. Se der erro **403 CSRF** ao entrar: o domínio está diferente do `DJANGO_DOMINIO` (confira `www.`) ou o `COOKIES_SECURE` está `True` sem HTTPS.
4. Se der **400 Bad Request**: o domínio não está em `DJANGO_DOMINIO`/`DJANGO_ALLOWED_HOSTS`.

## 4) Troque também (segurança)
- `DJANGO_SECRET_KEY`: gere uma nova só se quiser; **todos serão desconectados** (as senhas continuam valendo). Comando: `.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(60))"`.
- `DJANGO_ADMIN_URL`: um endereço só seu.
- `DJANGO_DEBUG=False`.

## Para voltar à rede local
Comente `DJANGO_DOMINIO` e volte os quatro itens de HTTPS para `False`/`0`.
