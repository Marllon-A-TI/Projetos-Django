@echo off
rem Inicia o Pet Shop ERP (servidor Waitress; porta e demais ajustes vem do .env: SERVIDOR_PORTA etc.).
rem Chamado pela Tarefa Agendada "PetShopERP - Servidor". Se o servidor parar
rem por algum erro, espera 10 segundos e inicia de novo.
cd /d "%~dp0.."
if not exist var\log mkdir var\log
:inicio
echo [%date% %time%] iniciando >> var\log\servidor.log
".venv\Scripts\python.exe" -m config.servidor >> var\log\servidor.log 2>&1
ping -n 11 127.0.0.1 >nul
goto inicio
