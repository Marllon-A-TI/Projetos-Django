from django.conf import settings


def site(request):
    """Nome do sistema e endereço público (vindos do .env), disponíveis em todos os templates."""
    return {"SITE_NOME": settings.SITE_NOME, "SITE_URL": settings.SITE_URL}
