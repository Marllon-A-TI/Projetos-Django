"""
Campo de quantidade que aceita fração (kg) e continua parecendo inteiro
quando a quantidade é inteira.

No banco é numeric(12,3). Ao ler, 2.000 volta como o inteiro 2 e 0.745 como
Decimal("0.745"): telas, JSON, Excel e contas que já existiam continuam
funcionando sem mudança.
"""

from decimal import Decimal

from django.db import models


class QuantidadeField(models.DecimalField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("max_digits", 12)
        kwargs.setdefault("decimal_places", 3)
        super().__init__(*args, **kwargs)

    def from_db_value(self, value, expression, connection):
        if value is None:
            return None
        valor = Decimal(value)
        if valor == valor.to_integral_value():
            return int(valor)
        return valor.normalize()
