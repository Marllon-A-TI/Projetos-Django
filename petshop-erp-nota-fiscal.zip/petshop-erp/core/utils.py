from decimal import Decimal

from django.utils.formats import number_format


def moeda(valor):
    """Formata um valor como moeda brasileira, por exemplo: R$ 1.234,56."""
    if valor is None:
        return "-"
    return "R$ " + number_format(Decimal(valor), decimal_pos=2, force_grouping=True)

from decimal import ROUND_HALF_UP, InvalidOperation  # noqa: E402

CENTAVOS = Decimal("0.01")
MILESIMOS = Decimal("0.001")


def valor_item(quantidade, preco):
    """Total do item arredondado ao centavo (meio para cima), como a NFC-e exige."""
    return (Decimal(quantidade) * Decimal(preco)).quantize(CENTAVOS, rounding=ROUND_HALF_UP)


def ler_quantidade(valor, pesavel=False):
    """
    Converte para Decimal com no máximo 3 casas. Produto não pesável só aceita
    número inteiro. Levanta ValueError com texto pronto para o usuário.
    """
    try:
        numero = Decimal(str(valor).replace(",", ".").strip())
    except (InvalidOperation, ValueError, AttributeError):
        raise ValueError("Quantidade inválida.")
    if not numero.is_finite():
        raise ValueError("Quantidade inválida.")
    if numero != numero.quantize(MILESIMOS):
        raise ValueError("Use no máximo 3 casas decimais (ex.: 0,745 kg).")
    if not pesavel and numero != numero.to_integral_value():
        raise ValueError("Este produto é vendido por unidade: use quantidade inteira.")
    return numero
