from django import template

from core.mixins import eh_administrador as _eh_administrador
from core.utils import moeda as _moeda

register = template.Library()


@register.filter
def eh_administrador(usuario):
    """Uso: {% if user|eh_administrador %}"""
    return _eh_administrador(usuario)


@register.filter
def moeda(valor):
    """Uso: {{ valor|moeda }}  ->  R$ 1.234,56"""
    return _moeda(valor)

@register.simple_tag
def balanca_attrs():
    """Atributos data-* do campo do leitor com o formato da etiqueta de balança (settings)."""
    from django.conf import settings
    from django.utils.html import format_html

    return format_html(
        'data-balanca-prefixo="{}" data-balanca-codigo="{}" data-balanca-valor="{}" data-balanca-modo="{}"',
        settings.BALANCA_PREFIXO, settings.BALANCA_DIGITOS_CODIGO,
        settings.BALANCA_DIGITOS_VALOR, settings.BALANCA_MODO,
    )


@register.simple_tag
def documento_fiscal_existe(venda, modelo):
    """True se a venda já tem documento fiscal desse modelo ("65" NFC-e, "55" NF-e)."""
    return venda.documentos_fiscais.filter(modelo=modelo).exists()
