from django.urls import path

from . import views

app_name = "fiscal"

urlpatterns = [
    path("", views.EmpresaListView.as_view(), name="empresa_list"),
    path("empresas/nova/", views.EmpresaCreateView.as_view(), name="empresa_create"),
    path("empresas/<int:pk>/", views.EmpresaDetailView.as_view(), name="empresa_detail"),
    path("empresas/<int:pk>/editar/", views.EmpresaUpdateView.as_view(), name="empresa_update"),
    path("produtos/", views.ProdutosPendentesView.as_view(), name="produtos_pendentes"),
    path("produtos/<int:produto_pk>/", views.ProdutoFiscalUpdateView.as_view(), name="produto_fiscal"),
    path("documentos/", views.DocumentoListView.as_view(), name="documento_list"),
    path("documentos/<int:pk>/", views.DocumentoDetailView.as_view(), name="documento_detail"),
    path("documentos/<int:pk>/xml/", views.DocumentoXmlView.as_view(), name="documento_xml"),
    path("vendas/<int:pk>/nfce/gerar/", views.NfceGerarView.as_view(), name="nfce_gerar"),
    path("documentos/<int:pk>/transmitir/", views.DocumentoTransmitirView.as_view(), name="documento_transmitir"),
    path("documentos/<int:pk>/consultar/", views.DocumentoConsultarView.as_view(), name="documento_consultar"),
    path("documentos/<int:pk>/regerar/", views.DocumentoRegerarView.as_view(), name="documento_regerar"),
    path("documentos/<int:pk>/cancelar/", views.DocumentoCancelarView.as_view(), name="documento_cancelar"),
    path("clientes/", views.ClienteListView.as_view(), name="cliente_list"),
    path("clientes/novo/", views.ClienteCreateView.as_view(), name="cliente_create"),
    path("clientes/<int:pk>/editar/", views.ClienteUpdateView.as_view(), name="cliente_update"),
    path("vendas/<int:pk>/nfe/gerar/", views.NfeGerarView.as_view(), name="nfe_gerar"),
    path("documentos/<int:pk>/carta/", views.DocumentoCartaView.as_view(), name="documento_carta"),
    path("documentos/<int:pk>/danfe.pdf", views.DocumentoDanfePdfView.as_view(), name="documento_danfe_pdf"),
    path("status/", views.StatusServicoView.as_view(), name="status_servico"),
    path("inutilizacao/", views.InutilizacaoView.as_view(), name="inutilizacao"),
]
