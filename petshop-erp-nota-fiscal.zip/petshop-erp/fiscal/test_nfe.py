"""
Testes da NF-e modelo 55, clientes, Carta de Correção e DANFE em PDF.
Rodar:  python manage.py test fiscal.test_nfe
"""

import re
from decimal import Decimal as D

from django.core.exceptions import ValidationError
from django.test import SimpleTestCase
from django.urls import reverse

from estoque.models import MovimentacaoEstoque
from pdv import services as pdv_services
from produtos.models import Produto

from . import services
from .danfe_pdf import gerar_danfe_pdf
from .models import CartaCorrecao, Cliente, DocumentoFiscal, EventoFiscal, ProdutoFiscal
from .nfce import assinatura
from .nfce import enderecos
from .tests import BaseFiscal, criar_empresa
from .validators import cpf_valido, documento_valido


class ValidadoresTests(SimpleTestCase):
    def test_cpf(self):
        self.assertTrue(cpf_valido("529.982.247-25"))
        self.assertFalse(cpf_valido("111.111.111-11"))
        self.assertFalse(cpf_valido("529.982.247-24"))

    def test_documento_aceita_cpf_ou_cnpj(self):
        self.assertTrue(documento_valido("52998224725"))
        self.assertTrue(documento_valido("11222333000181"))
        self.assertFalse(documento_valido("123"))


class EnderecosNfeTests(SimpleTestCase):
    def test_nfe_usa_host_proprio_e_homologacao_separada(self):
        prod = enderecos.url_servico("RJ", "1", "autorizacao", modelo="55")
        homo = enderecos.url_servico("RJ", "2", "autorizacao", modelo="55")
        self.assertIn("nfe.svrs", prod)
        self.assertIn("nfe-homologacao.svrs", homo)
        self.assertNotEqual(prod, enderecos.url_servico("RJ", "1", "autorizacao", modelo="65"))


DADOS_CLIENTE = dict(
    nome="Maria Cliente", documento="52998224725", ind_ie="9", inscricao_estadual="",
    email="", telefone="", logradouro="Rua B", numero="5", complemento="", bairro="Centro",
    municipio="Itaboraí", codigo_municipio_ibge="3301900", uf="RJ", cep="24800000",
)


class NfeBase(BaseFiscal):
    def setUp(self):
        super().setUp()
        self.empresa = criar_empresa(serie_nfe=1)
        self.produto = Produto.objects.create(nome="Ração Premium", codigo_barras="7891000100103",
                                              preco_venda=D("19.90"))
        MovimentacaoEstoque.registrar(produto=self.produto, tipo=MovimentacaoEstoque.Tipo.ENTRADA,
                                      quantidade=50, usuario=self.admin)
        ProdutoFiscal.objects.create(produto=self.produto, ncm="23099090")
        self.cliente = Cliente.objects.create(**DADOS_CLIENTE)
        sessao = pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("0"))
        self.venda, _ = pdv_services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor,
            itens=[{"produto": self.produto, "quantidade": 2, "preco": self.produto.preco_venda}],
            pagamentos={"PIX": D("39.80")},
        )

    def emitir(self):
        documento, aviso = services.emitir_nfe(venda=self.venda, cliente=self.cliente, usuario=self.admin)
        return documento, aviso


class EmitirNfeTests(NfeBase):
    def test_emite_autoriza_e_guarda_destinatario(self):
        documento, aviso = self.emitir()
        self.assertEqual(aviso, "")
        self.assertEqual((documento.modelo, documento.status, documento.cliente_id),
                         ("55", "AUTORIZADA", self.cliente.pk))
        self.assertTrue(assinatura.verificar(documento.xml_assinado))
        self.assertIn("<mod>55</mod>", documento.xml_assinado)
        self.assertIn("<CPF>52998224725</CPF>", documento.xml_assinado)
        self.assertNotIn("infNFeSupl", documento.xml_assinado)  # NF-e não tem QR-Code
        self.assertEqual(documento.numero, 1)

    def test_numeracao_da_nfe_e_separada_da_nfce(self):
        documento, _ = self.emitir()
        self.assertEqual(documento.serie, 1)
        nfce = services.gerar_nfce(venda=self.venda, usuario=self.admin)
        self.assertEqual(nfce.numero, 1)  # sequências independentes por modelo

    def test_sefaz_fora_do_ar_nao_grava_nada(self):
        self.sefaz.fora_do_ar = True
        with self.assertRaises(ValidationError):
            self.emitir()
        self.assertEqual(DocumentoFiscal.objects.count(), 0)

    def test_cliente_de_outro_estado_e_bloqueado(self):
        self.cliente.uf = "SP"
        self.cliente.save()
        with self.assertRaises(ValidationError):
            self.emitir()
        self.assertEqual(DocumentoFiscal.objects.count(), 0)

    def test_rejeicao_fica_registrada(self):
        self.sefaz.rejeitar = True
        documento, aviso = self.emitir()
        self.assertEqual(documento.status, "REJEITADA")
        self.assertIn("rejeitada", aviso.lower())


class CartaCorrecaoTests(NfeBase):
    def test_carta_aceita_numera_sequencia(self):
        documento, _ = self.emitir()
        c1 = services.corrigir(documento=documento, texto="Corrigir o endereço de entrega informado.",
                               usuario=self.admin)
        c2 = services.corrigir(documento=documento, texto="Complemento: sala 2 do endereço do cliente.",
                               usuario=self.admin)
        self.assertEqual((c1.sequencia, c1.aceita, c2.sequencia), (1, True, 2))
        self.assertTrue(EventoFiscal.objects.filter(documento=documento, tipo="CCE").exists())

    def test_texto_curto_e_bloqueado(self):
        documento, _ = self.emitir()
        with self.assertRaises(ValidationError):
            services.corrigir(documento=documento, texto="curto", usuario=self.admin)

    def test_nfce_nao_tem_carta(self):
        nfce = services.gerar_nfce(venda=self.venda, usuario=self.admin)
        with self.assertRaises(ValidationError):
            services.corrigir(documento=nfce, texto="x" * 30, usuario=self.admin)

    def test_carta_recusada_nao_consome_sequencia(self):
        documento, _ = self.emitir()
        self.sefaz.cancelamento_ok = False  # o simulador recusa eventos
        recusada = services.corrigir(documento=documento, texto="y" * 30, usuario=self.admin)
        self.assertFalse(recusada.aceita)
        self.sefaz.cancelamento_ok = True
        aceita = services.corrigir(documento=documento, texto="z" * 30, usuario=self.admin)
        self.assertEqual(aceita.sequencia, recusada.sequencia)
        self.assertEqual(CartaCorrecao.objects.filter(aceita=True).count(), 1)


class TelasNfeTests(NfeBase):
    def test_cadastro_de_cliente_pela_tela(self):
        self.client.force_login(self.admin)
        dados = dict(DADOS_CLIENTE, nome="João", documento="111.444.777-35", ativo="on",
                     cep="24800-000")
        resposta = self.client.post(reverse("fiscal:cliente_create"), dados)
        self.assertRedirects(resposta, reverse("fiscal:cliente_list"))
        self.assertTrue(Cliente.objects.filter(documento="11144477735").exists())

    def test_documento_invalido_e_contribuinte_sem_ie(self):
        self.client.force_login(self.admin)
        r = self.client.post(reverse("fiscal:cliente_create"),
                             dict(DADOS_CLIENTE, documento="123", ativo="on"))
        self.assertEqual(r.status_code, 200)
        r = self.client.post(reverse("fiscal:cliente_create"),
                             dict(DADOS_CLIENTE, documento="11222333000181", ind_ie="1", ativo="on"))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Cliente.objects.count(), 1)

    def test_vendedor_nao_acessa(self):
        self.client.force_login(self.vendedor)
        self.assertEqual(self.client.get(reverse("fiscal:cliente_list")).status_code, 403)
        r = self.client.post(reverse("fiscal:nfe_gerar", args=[self.venda.pk]), {"cliente": self.cliente.pk})
        self.assertEqual(r.status_code, 403)

    def test_emitir_carta_e_baixar_pdf_pela_tela(self):
        self.client.force_login(self.admin)
        r = self.client.post(reverse("fiscal:nfe_gerar", args=[self.venda.pk]), {"cliente": self.cliente.pk})
        documento = DocumentoFiscal.objects.get(modelo="55")
        self.assertRedirects(r, reverse("fiscal:documento_detail", args=[documento.pk]))
        detalhe = self.client.get(reverse("fiscal:documento_detail", args=[documento.pk]))
        self.assertContains(detalhe, "Carta de correção")
        self.assertNotContains(detalhe, "Imprimir DANFE")
        self.client.post(reverse("fiscal:documento_carta", args=[documento.pk]),
                         {"texto": "Corrigir o complemento do endereço do cliente."})
        self.assertEqual(documento.cartas.filter(aceita=True).count(), 1)
        pdf = self.client.get(reverse("fiscal:documento_danfe_pdf", args=[documento.pk]))
        self.assertEqual(pdf["Content-Type"], "application/pdf")
        self.assertTrue(pdf.content.startswith(b"%PDF"))

    def test_pdf_so_para_nfe(self):
        nfce = services.gerar_nfce(venda=self.venda, usuario=self.admin)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse("fiscal:documento_danfe_pdf", args=[nfce.pk])).status_code, 404)

    def test_venda_mostra_bloco_de_nfe(self):
        self.client.force_login(self.admin)
        pagina = self.client.get(reverse("vendas:detail", args=[self.venda.pk]))
        self.assertContains(pagina, "Emitir NF-e")
        self.assertContains(pagina, "Maria Cliente")


class DanfePdfTests(NfeBase):
    def test_gera_pdf_valido(self):
        documento, _ = self.emitir()
        pdf = gerar_danfe_pdf(documento.xml_autorizado, autorizada=True)
        self.assertTrue(pdf.startswith(b"%PDF"))
        self.assertTrue(re.search(rb"%%EOF\s*$", pdf))
