from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.core.exceptions import ValidationError
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.views import View
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from core.mixins import AdministradorRequiredMixin
from logs.models import LogAcao
from logs.utils import LogFormValidMixin, registrar_acao
from produtos.models import Produto
from vendas.models import Venda

from . import services
from .danfe_pdf import gerar_danfe_pdf
from .forms import CartaCorrecaoForm, ClienteForm, EmpresaForm, InutilizacaoForm, NfeEmitirForm, ProdutoFiscalForm
from .models import Cliente, DocumentoFiscal, Empresa, Inutilizacao, ProdutoFiscal


class EmpresaListView(AdministradorRequiredMixin, ListView):
    model = Empresa
    template_name = "fiscal/empresa_list.html"
    context_object_name = "empresas"


class EmpresaDetailView(AdministradorRequiredMixin, DetailView):
    model = Empresa
    template_name = "fiscal/empresa_detail.html"
    context_object_name = "empresa"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        pendencias = services.diagnostico(self.object)
        contexto["pendencias"] = pendencias
        contexto["pronta"] = not any(p.nivel == "erro" for p in pendencias)
        return contexto


class EmpresaCreateView(
    AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, CreateView
):
    model = Empresa
    form_class = EmpresaForm
    template_name = "fiscal/empresa_form.html"
    success_message = "Empresa cadastrada com sucesso."
    acao_log = LogAcao.Acao.CRIACAO
    prefixo_log = "Empresa criada: "
    extra_context = {"titulo": "Nova empresa emitente"}

    def get_success_url(self):
        return reverse("fiscal:empresa_detail", kwargs={"pk": self.object.pk})


class EmpresaUpdateView(
    AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, UpdateView
):
    model = Empresa
    form_class = EmpresaForm
    template_name = "fiscal/empresa_form.html"
    success_message = "Empresa atualizada com sucesso."
    acao_log = LogAcao.Acao.EDICAO
    prefixo_log = "Empresa editada: "
    extra_context = {"titulo": "Editar empresa emitente"}

    def descricao_log(self):
        return (
            f"{self.prefixo_log}{self.object} (#{self.object.pk}), "
            f"ambiente {self.object.ambiente}, provedor {self.object.provedor}"
        )

    def get_success_url(self):
        return reverse("fiscal:empresa_detail", kwargs={"pk": self.object.pk})


class ProdutoFiscalUpdateView(
    AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, UpdateView
):
    """Cria ou edita os dados fiscais de um produto."""

    model = ProdutoFiscal
    form_class = ProdutoFiscalForm
    template_name = "fiscal/produtofiscal_form.html"
    success_message = "Dados fiscais salvos."
    acao_log = LogAcao.Acao.EDICAO
    prefixo_log = "Dados fiscais: "

    def get_object(self, queryset=None):
        self.produto = get_object_or_404(Produto, pk=self.kwargs["produto_pk"])
        existente = ProdutoFiscal.objects.filter(produto=self.produto).first()
        return existente or ProdutoFiscal(produto=self.produto)

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["produto"] = self.produto
        return contexto

    def get_success_url(self):
        return reverse("fiscal:produtos_pendentes")


class ProdutosPendentesView(AdministradorRequiredMixin, ListView):
    """Produtos ativos que ainda não têm dados fiscais (impedem a NFC-e)."""

    template_name = "fiscal/produtos_pendentes.html"
    context_object_name = "produtos"
    paginate_by = 50

    def get_queryset(self):
        return Produto.objects.filter(ativo=True, fiscal__isnull=True).order_by("nome")


class DocumentoListView(AdministradorRequiredMixin, ListView):
    template_name = "fiscal/documento_list.html"
    context_object_name = "documentos"
    paginate_by = 25

    def get_queryset(self):
        return DocumentoFiscal.objects.select_related("empresa", "venda")


class DocumentoDetailView(AdministradorRequiredMixin, DetailView):
    model = DocumentoFiscal
    template_name = "fiscal/documento_detail.html"
    context_object_name = "documento"

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["eventos"] = self.object.eventos.select_related("usuario")
        contexto["cartas"] = self.object.cartas.select_related("usuario")
        contexto["form_carta"] = CartaCorrecaoForm()
        return contexto


class DocumentoXmlView(AdministradorRequiredMixin, View):
    def get(self, request, pk):
        documento = get_object_or_404(DocumentoFiscal, pk=pk)
        xml = documento.xml_autorizado or documento.xml_assinado
        resposta = HttpResponse(xml, content_type="application/xml; charset=utf-8")
        resposta["Content-Disposition"] = f'attachment; filename="{documento.chave}.xml"'
        resposta["Cache-Control"] = "no-store"
        return resposta


class NfceGerarView(AdministradorRequiredMixin, View):
    """Emite a NFC-e da venda: transmite à SEFAZ ou, sem comunicação, emite em contingência."""

    def post(self, request, pk):
        venda = get_object_or_404(Venda, pk=pk)
        try:
            documento, aviso = services.emitir_nfce(venda=venda, usuario=request.user)
            registrar_acao(
                request, LogAcao.Acao.CRIACAO,
                f"NFC-e {documento.serie}/{documento.numero} (venda #{venda.pk}), "
                f"situação {documento.get_status_display()}, chave {documento.chave}",
            )
        except ValidationError as erro:
            for mensagem in erro.messages:
                messages.error(request, mensagem)
            return redirect("vendas:detail", pk=venda.pk)
        if aviso:
            messages.warning(request, aviso)
        else:
            messages.success(request, f"NFC-e {documento.get_status_display().lower()}.")
        return redirect("fiscal:documento_detail", pk=documento.pk)


class _AcaoDocumentoView(AdministradorRequiredMixin, View):
    """Base das ações POST sobre um documento: executa, audita e volta ao detalhe."""

    http_method_names = ["post"]
    descricao = ""

    def executar(self, request, documento):  # pragma: no cover
        raise NotImplementedError

    def post(self, request, pk):
        documento = get_object_or_404(DocumentoFiscal, pk=pk)
        try:
            documento = self.executar(request, documento)
            registrar_acao(
                request, LogAcao.Acao.EDICAO,
                f"{self.descricao} da NFC-e {documento.serie}/{documento.numero} "
                f"(chave {documento.chave}): {documento.get_status_display()}",
            )
        except ValidationError as erro:
            for mensagem in erro.messages:
                messages.error(request, mensagem)
        else:
            messages.success(request, f"{self.descricao}: nota {documento.get_status_display().lower()}.")
        return redirect("fiscal:documento_detail", pk=pk)


class DocumentoTransmitirView(_AcaoDocumentoView):
    descricao = "Envio"

    def executar(self, request, documento):
        return services.transmitir(documento=documento, usuario=request.user)


class DocumentoConsultarView(_AcaoDocumentoView):
    descricao = "Consulta"

    def executar(self, request, documento):
        return services.consultar(documento=documento, usuario=request.user)


class DocumentoRegerarView(_AcaoDocumentoView):
    descricao = "Regeração do XML"

    def executar(self, request, documento):
        return services.regerar_nfce(documento=documento, usuario=request.user)


class DocumentoCancelarView(_AcaoDocumentoView):
    descricao = "Cancelamento"

    def executar(self, request, documento):
        return services.cancelar(
            documento=documento, justificativa=request.POST.get("justificativa", ""),
            usuario=request.user,
        )


class StatusServicoView(AdministradorRequiredMixin, View):
    """Mostra se a SEFAZ está respondendo (não grava nada)."""

    def get(self, request):
        empresa = services.empresa_padrao()
        contexto = {"empresa": empresa}
        if empresa is not None:
            try:
                contexto["retorno"] = services.status_servico(empresa)
            except Exception as exc:  # rede, certificado, retorno ilegível: só mostrar
                contexto["erro"] = str(exc)
        return render(request, "fiscal/status_servico.html", contexto)


class InutilizacaoView(AdministradorRequiredMixin, View):
    template_name = "fiscal/inutilizacao.html"

    def contexto(self, form=None):
        return {"form": form or InutilizacaoForm(), "historico": Inutilizacao.objects.select_related("empresa")[:20]}

    def get(self, request):
        return render(request, self.template_name, self.contexto())

    def post(self, request):
        form = InutilizacaoForm(request.POST)
        empresa = services.empresa_padrao()
        if empresa is None:
            messages.error(request, "Cadastre a empresa padrão antes.")
        elif form.is_valid():
            try:
                registro = services.inutilizar(empresa=empresa, usuario=request.user,
                                               **form.cleaned_data)
                registrar_acao(request, LogAcao.Acao.EDICAO,
                               f"{registro} - {'aceita' if registro.aceita else 'NÃO aceita'}: {registro.motivo}")
            except ValidationError as erro:
                for mensagem in erro.messages:
                    messages.error(request, mensagem)
            else:
                (messages.success if registro.aceita else messages.error)(
                    request, f"{registro}: {registro.cstat} - {registro.motivo}")
                return redirect("fiscal:inutilizacao")
        return render(request, self.template_name, self.contexto(form))


# --- NF-e (modelo 55): clientes, emissão, carta de correção, DANFE em PDF --------

class ClienteListView(AdministradorRequiredMixin, ListView):
    model = Cliente
    template_name = "fiscal/cliente_list.html"
    context_object_name = "clientes"
    paginate_by = 25


class ClienteCreateView(AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, CreateView):
    model = Cliente
    form_class = ClienteForm
    template_name = "fiscal/cliente_form.html"
    success_url = reverse_lazy("fiscal:cliente_list")
    success_message = "Cliente cadastrado."
    acao_log = LogAcao.Acao.CRIACAO
    prefixo_log = "Cliente (destinatário) criado: "
    extra_context = {"titulo": "Novo cliente"}


class ClienteUpdateView(AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, UpdateView):
    model = Cliente
    form_class = ClienteForm
    template_name = "fiscal/cliente_form.html"
    success_url = reverse_lazy("fiscal:cliente_list")
    success_message = "Cliente atualizado."
    acao_log = LogAcao.Acao.EDICAO
    prefixo_log = "Cliente (destinatário) editado: "
    extra_context = {"titulo": "Editar cliente"}


class NfeGerarView(AdministradorRequiredMixin, View):
    """Emite a NF-e (modelo 55) da venda para o cliente escolhido."""

    def post(self, request, pk):
        venda = get_object_or_404(Venda, pk=pk)
        form = NfeEmitirForm(request.POST)
        if not form.is_valid():
            messages.error(request, "Escolha o destinatário da NF-e.")
            return redirect("vendas:detail", pk=venda.pk)
        try:
            documento, aviso = services.emitir_nfe(
                venda=venda, cliente=form.cleaned_data["cliente"], usuario=request.user)
            registrar_acao(
                request, LogAcao.Acao.CRIACAO,
                f"NF-e {documento.serie}/{documento.numero} (venda #{venda.pk}) para "
                f"{documento.cliente}, situação {documento.get_status_display()}, chave {documento.chave}",
            )
        except ValidationError as erro:
            for mensagem in erro.messages:
                messages.error(request, mensagem)
            return redirect("vendas:detail", pk=venda.pk)
        if aviso:
            messages.warning(request, aviso)
        else:
            messages.success(request, f"NF-e {documento.get_status_display().lower()}.")
        return redirect("fiscal:documento_detail", pk=documento.pk)


class DocumentoCartaView(AdministradorRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request, pk):
        documento = get_object_or_404(DocumentoFiscal, pk=pk)
        form = CartaCorrecaoForm(request.POST)
        if not form.is_valid():
            messages.error(request, "O texto da correção precisa ter de 15 a 1000 caracteres.")
        else:
            try:
                carta = services.corrigir(documento=documento, texto=form.cleaned_data["texto"],
                                          usuario=request.user)
            except ValidationError as erro:
                for mensagem in erro.messages:
                    messages.error(request, mensagem)
            else:
                registrar_acao(request, LogAcao.Acao.EDICAO,
                               f"Carta de correção {carta.sequencia} da NF-e {documento.serie}/{documento.numero}: "
                               f"{carta.cstat} - {carta.motivo}")
                if carta.aceita:
                    messages.success(request, "Carta de correção registrada na SEFAZ.")
                else:
                    messages.error(request, f"A SEFAZ não aceitou a carta: {carta.cstat} - {carta.motivo}")
        return redirect("fiscal:documento_detail", pk=pk)


class DocumentoDanfePdfView(AdministradorRequiredMixin, View):
    def get(self, request, pk):
        documento = get_object_or_404(DocumentoFiscal, pk=pk)
        if documento.modelo != "55":
            raise Http404("DANFE em PDF existe só para NF-e. A NFC-e usa o DANFE da impressora térmica.")
        xml = documento.xml_autorizado or documento.xml_assinado
        pdf = gerar_danfe_pdf(xml, autorizada=bool(documento.xml_autorizado))
        resposta = HttpResponse(pdf, content_type="application/pdf")
        resposta["Content-Disposition"] = f'inline; filename="DANFE-{documento.chave}.pdf"'
        resposta["Cache-Control"] = "no-store"
        return resposta
