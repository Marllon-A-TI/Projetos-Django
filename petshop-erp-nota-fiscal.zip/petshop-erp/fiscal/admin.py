from django.contrib import admin

from core.admin import ImutavelAdminMixin, SomenteLeituraAdminMixin

from .models import CartaCorrecao, Cliente, DocumentoFiscal, Empresa, EventoFiscal, Inutilizacao


@admin.register(Empresa)
class EmpresaAdmin(ImutavelAdminMixin, admin.ModelAdmin):
    list_display = ("razao_social", "cnpj", "uf", "ambiente", "provedor", "ativo", "padrao")
    list_filter = ("ambiente", "provedor", "ativo")
    search_fields = ("razao_social", "nome_fantasia", "cnpj")
    list_per_page = 50


@admin.register(DocumentoFiscal)
class DocumentoFiscalAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("__str__", "venda", "ambiente", "status", "emitido_em")
    list_filter = ("status", "ambiente")
    search_fields = ("chave",)
    list_select_related = ("venda",)
    list_per_page = 50


@admin.register(EventoFiscal)
class EventoFiscalAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("documento", "tipo", "usuario", "criado_em")
    list_filter = ("tipo",)
    list_select_related = ("documento", "usuario")
    list_per_page = 50


@admin.register(Inutilizacao)
class InutilizacaoAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("__str__", "aceita", "cstat", "criado_em")
    list_filter = ("aceita",)
    list_per_page = 50


@admin.register(Cliente)
class ClienteAdmin(ImutavelAdminMixin, admin.ModelAdmin):
    list_display = ("nome", "documento", "uf", "ativo")
    list_filter = ("ativo", "uf")
    search_fields = ("nome", "documento")
    list_per_page = 50


@admin.register(CartaCorrecao)
class CartaCorrecaoAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("__str__", "aceita", "cstat", "usuario", "criado_em")
    list_filter = ("aceita",)
    exclude = ("xml_evento",)
    list_per_page = 50
