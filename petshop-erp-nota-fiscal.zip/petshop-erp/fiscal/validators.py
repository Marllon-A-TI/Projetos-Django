import re

from django.core.exceptions import ValidationError

_PESO_12 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
_PESO_13 = [6] + _PESO_12


def limpar_cnpj(valor):
    """Remove . / - e espaços e põe em maiúsculas."""
    return re.sub(r"[.\-/\s]", "", valor or "").upper()


def _digito(base, pesos):
    soma = sum((ord(c) - 48) * p for c, p in zip(base, pesos))
    resto = soma % 11
    return "0" if resto < 2 else str(11 - resto)


def cnpj_valido(valor):
    """
    Valida CNPJ numérico e o alfanumérico (a partir de jul/2026, IN RFB
    2.229/2024): 12 posições [0-9A-Z] + 2 dígitos verificadores numéricos,
    módulo 11 com o valor ASCII do caractere menos 48.
    """
    cnpj = limpar_cnpj(valor)
    if not re.fullmatch(r"[0-9A-Z]{12}[0-9]{2}", cnpj):
        return False
    if len(set(cnpj)) == 1:  # 00000000000000, 11111111111111...
        return False
    d1 = _digito(cnpj[:12], _PESO_12)
    d2 = _digito(cnpj[:12] + d1, _PESO_13)
    return cnpj[12:] == d1 + d2


def validar_documento(valor):
    if not documento_valido(valor):
        raise ValidationError("CPF ou CNPJ inválido.")


def validar_cnpj(valor):
    if not cnpj_valido(valor):
        raise ValidationError("CNPJ inválido.")


def limpar_cpf(valor):
    return re.sub(r"[.\-\s]", "", valor or "")


def cpf_valido(valor):
    cpf = limpar_cpf(valor)
    if not re.fullmatch(r"\d{11}", cpf) or len(set(cpf)) == 1:
        return False
    for n in (9, 10):
        soma = sum(int(cpf[i]) * (n + 1 - i) for i in range(n))
        digito = (soma * 10) % 11 % 10
        if digito != int(cpf[n]):
            return False
    return True


def documento_valido(valor):
    """CPF (11 dígitos) ou CNPJ (14 caracteres)."""
    limpo = limpar_cnpj(valor)
    return cpf_valido(limpo) if len(limpo) == 11 else cnpj_valido(limpo)
