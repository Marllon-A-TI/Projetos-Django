"""
DANFE da NF-e (modelo 55) em PDF A4, gerado do XML com reportlab (gratuito).

ATENÇÃO: é uma versão SIMPLIFICADA do leiaute oficial do DANFE (mesmos dados
essenciais e código de barras da chave, mas não confere campo a campo com o
Manual de Orientação do Contribuinte). Para a validade fiscal vale o XML; se o
destinatário exigir o DANFE oficial, use o visualizador gratuito da SEFAZ com o
XML autorizado. Sem Django: recebe o texto do XML.
"""

from decimal import Decimal
from io import BytesIO

from lxml import etree
from reportlab.graphics.barcode import code128
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

NS = {"n": "http://www.portalfiscal.inf.br/nfe"}


def _t(el, caminho, padrao=""):
    if el is None:
        return padrao
    achado = el.find(caminho, NS)
    return (achado.text or "").strip() if achado is not None and achado.text else padrao


def _moeda(valor):
    try:
        v = Decimal(valor)
    except Exception:
        return valor
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _qtd(valor):
    try:
        v = Decimal(valor).normalize()
    except Exception:
        return valor
    texto = f"{v:f}"
    return texto.replace(".", ",")


def _doc(numero):
    d = numero or ""
    if len(d) == 11:
        return f"{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}"
    if len(d) == 14:
        return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"
    return d


def _chave_formatada(chave):
    return " ".join(chave[i:i + 4] for i in range(0, len(chave), 4))


def _data(iso):
    try:
        return f"{iso[8:10]}/{iso[5:7]}/{iso[:4]} {iso[11:19]}"
    except Exception:
        return iso


def gerar_danfe_pdf(xml_texto, autorizada=False):
    raiz = etree.fromstring(xml_texto.encode("utf-8"))
    nfe = raiz if raiz.tag.endswith("}NFe") else raiz.find(".//n:NFe", NS)
    inf = nfe.find("n:infNFe", NS)
    chave = inf.get("Id", "")[3:]
    ide, emit, dest = inf.find("n:ide", NS), inf.find("n:emit", NS), inf.find("n:dest", NS)
    total = inf.find("n:total/n:ICMSTot", NS)
    prot = raiz.find(".//n:protNFe/n:infProt", NS)
    homologacao = _t(ide, "n:tpAmb") == "2"

    estilos = getSampleStyleSheet()
    normal = ParagraphStyle("n", parent=estilos["Normal"], fontSize=8, leading=10)
    pequeno = ParagraphStyle("p", parent=normal, fontSize=7, leading=8.5, textColor=colors.HexColor("#444"))
    titulo = ParagraphStyle("t", parent=normal, fontSize=11, leading=13, fontName="Helvetica-Bold")
    aviso = ParagraphStyle("a", parent=normal, fontSize=10, leading=12, textColor=colors.HexColor("#b00020"),
                           fontName="Helvetica-Bold", alignment=1)

    def caixa(linhas, larguras=None):
        tabela = Table(linhas, colWidths=larguras)
        tabela.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.6, colors.black), ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        return tabela

    historia = []
    if homologacao:
        historia.append(Paragraph("EMITIDA EM AMBIENTE DE HOMOLOGAÇÃO - SEM VALOR FISCAL", aviso))
    if not autorizada:
        historia.append(Paragraph("NF-e SEM AUTORIZAÇÃO DE USO - NÃO UTILIZAR COMO DOCUMENTO FISCAL", aviso))

    barras = code128.Code128(chave, barHeight=12 * mm, barWidth=0.33 * mm, humanReadable=False)
    protocolo = (f"{_t(prot, 'n:nProt')} - {_data(_t(prot, 'n:dhRecbto'))}" if prot is not None
                 else "Sem protocolo de autorização")
    cabecalho = [
        [Paragraph("<b>DANFE</b><br/>Documento Auxiliar da Nota Fiscal Eletrônica", normal),
         Paragraph(f"<b>NF-e Nº {int(_t(ide, 'n:nNF', '0')):,}".replace(",", ".")
                   + f"<br/>Série {_t(ide, 'n:serie')}</b><br/>Entrada/Saída: 1 - Saída<br/>"
                   f"Emissão: {_data(_t(ide, 'n:dhEmi'))}", normal),
         barras],
        [Paragraph(f"<b>CHAVE DE ACESSO</b><br/>{_chave_formatada(chave)}", normal),
         Paragraph(f"<b>PROTOCOLO DE AUTORIZAÇÃO</b><br/>{protocolo}", normal), ""],
    ]
    tabela_cab = caixa(cabecalho, [70 * mm, 60 * mm, 55 * mm])
    tabela_cab.setStyle(TableStyle([("SPAN", (2, 0), (2, 1)), ("INNERGRID", (0, 0), (-1, -1), 0.3, colors.grey)]))
    historia += [tabela_cab, Spacer(1, 2 * mm)]

    historia.append(caixa([[Paragraph("<b>NATUREZA DA OPERAÇÃO</b><br/>" + _t(ide, "n:natOp"), normal)]], [185 * mm]))
    historia.append(Spacer(1, 2 * mm))

    end_emit = emit.find("n:enderEmit", NS)
    historia.append(Paragraph("EMITENTE", titulo))
    historia.append(caixa([[Paragraph(
        f"<b>{_t(emit, 'n:xNome')}</b><br/>CNPJ {_doc(_t(emit, 'n:CNPJ'))} · IE {_t(emit, 'n:IE')}<br/>"
        f"{_t(end_emit, 'n:xLgr')}, {_t(end_emit, 'n:nro')} - {_t(end_emit, 'n:xBairro')} - "
        f"{_t(end_emit, 'n:xMun')}/{_t(end_emit, 'n:UF')} - CEP {_t(end_emit, 'n:CEP')}", normal)]], [185 * mm]))
    historia.append(Spacer(1, 2 * mm))

    if dest is not None:
        end_dest = dest.find("n:enderDest", NS)
        doc_dest = _t(dest, "n:CNPJ") or _t(dest, "n:CPF")
        historia.append(Paragraph("DESTINATÁRIO / REMETENTE", titulo))
        historia.append(caixa([[Paragraph(
            f"<b>{_t(dest, 'n:xNome')}</b><br/>CPF/CNPJ {_doc(doc_dest)}"
            + (f" · IE {_t(dest, 'n:IE')}" if _t(dest, "n:IE") else "") + "<br/>"
            f"{_t(end_dest, 'n:xLgr')}, {_t(end_dest, 'n:nro')} - {_t(end_dest, 'n:xBairro')} - "
            f"{_t(end_dest, 'n:xMun')}/{_t(end_dest, 'n:UF')} - CEP {_t(end_dest, 'n:CEP')}", normal)]],
            [185 * mm]))
        historia.append(Spacer(1, 2 * mm))

    historia.append(Paragraph("CÁLCULO DO IMPOSTO", titulo))
    historia.append(caixa([[
        Paragraph(f"<b>Produtos</b><br/>R$ {_moeda(_t(total, 'n:vProd', '0'))}", normal),
        Paragraph(f"<b>Desconto</b><br/>R$ {_moeda(_t(total, 'n:vDesc', '0'))}", normal),
        Paragraph(f"<b>Frete</b><br/>R$ {_moeda(_t(total, 'n:vFrete', '0'))}", normal),
        Paragraph(f"<b>VALOR TOTAL DA NOTA</b><br/>R$ {_moeda(_t(total, 'n:vNF', '0'))}", normal),
    ]], [40 * mm, 40 * mm, 40 * mm, 65 * mm]))
    historia.append(Spacer(1, 2 * mm))

    historia.append(Paragraph("DADOS DOS PRODUTOS", titulo))
    linhas = [["Cód.", "Descrição", "NCM", "CFOP", "Un.", "Qtd.", "V. Unit.", "V. Total"]]
    for det in inf.findall("n:det", NS):
        p = det.find("n:prod", NS)
        linhas.append([
            Paragraph(_t(p, "n:cProd"), pequeno), Paragraph(_t(p, "n:xProd"), pequeno), _t(p, "n:NCM"),
            _t(p, "n:CFOP"), _t(p, "n:uCom"), _qtd(_t(p, "n:qCom")),
            _moeda(_t(p, "n:vUnCom")), _moeda(_t(p, "n:vProd")),
        ])
    itens = Table(linhas, colWidths=[18 * mm, 60 * mm, 18 * mm, 12 * mm, 10 * mm, 17 * mm, 25 * mm, 25 * mm],
                  repeatRows=1)
    itens.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 7), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8e8e8")),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (5, 1), (-1, -1), "RIGHT"),
    ]))
    historia += [itens, Spacer(1, 2 * mm)]

    adicional = _t(inf, "n:infAdic/n:infCpl")
    historia.append(Paragraph("DADOS ADICIONAIS", titulo))
    historia.append(caixa([[Paragraph(adicional or "Documento emitido por ME ou EPP optante pelo Simples Nacional. "
                                      "Não gera direito a crédito fiscal de IPI.", normal)]], [185 * mm]))
    historia.append(Spacer(1, 3 * mm))
    historia.append(Paragraph(
        "Visualização simplificada do DANFE gerada pelo sistema. Vale o XML autorizado; confira a nota em "
        "www.nfe.fazenda.gov.br com a chave de acesso.", pequeno))

    buffer = BytesIO()
    SimpleDocTemplate(buffer, pagesize=A4, leftMargin=12 * mm, rightMargin=12 * mm, topMargin=10 * mm,
                      bottomMargin=10 * mm, title=f"DANFE {chave}").build(historia)
    return buffer.getvalue()
