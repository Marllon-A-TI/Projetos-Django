"""
Testes fiscais (Etapas 2 e 3). Rodar:  python manage.py test fiscal
A parte pura (chave, XML, assinatura, QR-Code) roda sem banco.
"""

import datetime as dt
import os
import re
import tempfile
from datetime import date, timedelta
from decimal import Decimal as D
from unittest import mock

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID
from django.contrib.auth.models import Group, User
from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from accounts.models import GRUPO_ADMINISTRADOR, GRUPO_VENDEDOR
from estoque.models import MovimentacaoEstoque
from logs.models import LogAcao
from pdv import services as pdv_services
from produtos.models import Produto
from vendas.models import Venda

from . import services
from .models import DocumentoFiscal, Empresa, EventoFiscal, ProdutoFiscal
from .nfce import assinatura, certificado, qrcode, sefaz
from .nfce.canal import CanalErro
from .nfce import xml as nx
from .nfce.chave import digito_verificador, gerar_chave
from .validators import cnpj_valido

CNPJ = "11222333000181"
CSC = "CSC-DE-TESTE"


def criar_pfx(cnpj=CNPJ, dias=365, senha=b"segredo"):
    """Gera um certificado de teste (autoassinado) em arquivo .pfx temporário."""
    chave = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    nome = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, f"PET SHOP TESTE ME:{cnpj}")])
    agora = dt.datetime.now(dt.timezone.utc)
    cert = (
        x509.CertificateBuilder().subject_name(nome).issuer_name(nome)
        .public_key(chave.public_key()).serial_number(1)
        .not_valid_before(agora - dt.timedelta(days=2))
        .not_valid_after(agora + dt.timedelta(days=dias))
        .sign(chave, hashes.SHA256())
    )
    dados = pkcs12.serialize_key_and_certificates(
        b"t", chave, cert, None, serialization.BestAvailableEncryption(senha)
    )
    arquivo = tempfile.NamedTemporaryFile(suffix=".pfx", delete=False)
    arquivo.write(dados)
    arquivo.close()
    return arquivo.name


def nfce_exemplo(ambiente="2"):
    emit = nx.Emitente(CNPJ, "PET SHOP TESTE ME", "Pet Teste", "12345678", "1", "Rua A", "10",
                       "", "Manilha", "3301900", "Itaboraí", "RJ", "24800000", "(21) 99999-9999")
    itens = [
        nx.Item("1", "7891000100103", "Ração 1kg", "23099090", "", "5102", "UN", D("2"), D("19.90"), "0", "102"),
        nx.Item("2", "", "Brinquedo & <bola>", "95030099", "", "5102", "UN", D("1"), D("10.00"), "0", "102"),
    ]
    emissao = dt.datetime(2026, 11, 13, 16, 19, tzinfo=dt.timezone(dt.timedelta(hours=-3)))
    chave = gerar_chave(uf="RJ", emissao=emissao, cnpj=CNPJ, modelo=65, serie=1, numero=1,
                        tp_emis=1, codigo_numerico=12345678)
    qr = qrcode.url_qrcode(url_base="http://x/qr", chave=chave, ambiente=ambiente, id_csc="000001", csc=CSC)
    return nx.Nfce(emit, itens, [nx.Pagamento("01", D("60.00"))], D("10.20"), 1, 1, 12345678,
                   chave, ambiente, emissao, 33, url_qrcode=qr, url_chave="x/consulta")


NS = 'xmlns="http://www.portalfiscal.inf.br/nfe"'
SOAP = ('<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope"><soap:Body>'
        '<nfeResultMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/X">%s</nfeResultMsg>'
        "</soap:Body></soap:Envelope>")


class FalsaSefaz:
    """Canal simulado: responde como a SEFAZ, sem rede."""

    def __init__(self, fora_do_ar=False, rejeitar=False, cancelamento_ok=True):
        self.fora_do_ar, self.rejeitar, self.cancelamento_ok = fora_do_ar, rejeitar, cancelamento_ok
        self.chamadas = []

    def enviar(self, url, servico, xml_pedido):
        self.chamadas.append(servico)
        if self.fora_do_ar:
            raise CanalErro("Sem comunicação com a SEFAZ: simulado")
        if servico == "status":
            return (SOAP % f'<retConsStatServ {NS} versao="4.00"><cStat>107</cStat>'
                    "<xMotivo>Servico em Operacao</xMotivo></retConsStatServ>").encode()
        chave = re.search(r'Id="NFe(\d{44})"|<chNFe>(\d{44})</chNFe>', xml_pedido)
        chave = (chave.group(1) or chave.group(2)) if chave else "0" * 44
        prot = (f'<protNFe {NS} versao="4.00"><infProt><tpAmb>2</tpAmb><chNFe>{chave}</chNFe>'
                "<dhRecbto>2026-11-13T16:20:00-03:00</dhRecbto><nProt>133260000000001</nProt>"
                "<cStat>100</cStat><xMotivo>Autorizado o uso da NF-e</xMotivo></infProt></protNFe>")
        if servico == "autorizacao":
            if self.rejeitar:
                return (SOAP % f'<retEnviNFe {NS} versao="4.00"><cStat>225</cStat>'
                        "<xMotivo>Rejeicao: Falha no Schema XML</xMotivo></retEnviNFe>").encode()
            return (SOAP % f'<retEnviNFe {NS} versao="4.00"><cStat>104</cStat>'
                    f"<xMotivo>Lote processado</xMotivo>{prot}</retEnviNFe>").encode()
        if servico == "consulta":
            return (SOAP % f'<retConsSitNFe {NS} versao="4.00"><cStat>100</cStat>'
                    f"<xMotivo>Autorizado</xMotivo><chNFe>{chave}</chNFe>{prot}</retConsSitNFe>").encode()
        if servico == "evento":
            tipo = re.search(r"<tpEvento>(\d{6})</tpEvento>", xml_pedido)
            tipo = tipo.group(1) if tipo else "110111"
            cstat, motivo = ("135", "Evento registrado") if self.cancelamento_ok else ("501", "Rejeicao: prazo")
            return (SOAP % f'<retEnvEvento {NS} versao="1.00"><cStat>128</cStat><retEvento versao="1.00">'
                    f"<infEvento><cStat>{cstat}</cStat><xMotivo>{motivo}</xMotivo><chNFe>{chave}</chNFe>"
                    f"<tpEvento>{tipo}</tpEvento><nProt>133260000000009</nProt>"
                    "<dhRegEvento>2026-11-13T16:30:00-03:00</dhRegEvento></infEvento></retEvento>"
                    "</retEnvEvento>").encode()
        if servico == "inutilizacao":
            return (SOAP % f'<retInutNFe {NS} versao="4.00"><infInut><cStat>102</cStat>'
                    "<xMotivo>Inutilizacao homologada</xMotivo><nProt>133260000000002</nProt>"
                    "</infInut></retInutNFe>").encode()
        raise AssertionError(servico)


class NucleoNfceTests(SimpleTestCase):
    """Sem banco: chave, QR-Code, XML e assinatura."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.pfx = criar_pfx()
        cls.cert = certificado.carregar_certificado(cls.pfx, "segredo")

    @classmethod
    def tearDownClass(cls):
        os.unlink(cls.pfx)
        super().tearDownClass()

    def test_digito_verificador_do_exemplo_do_manual(self):
        self.assertEqual(digito_verificador("3508059999909091027055001000000001518005127"), "3")

    def test_chave_tem_44_posicoes_e_aceita_cnpj_alfanumerico(self):
        chave = gerar_chave(uf="RJ", emissao=date(2026, 11, 13), cnpj="12ABC34501DE35",
                            modelo=65, serie=1, numero=7, tp_emis=1, codigo_numerico=12345678)
        self.assertEqual(len(chave), 44)
        self.assertTrue(chave.startswith("332611"))

    def test_qrcode_v2_hash_sha1_maiusculo_e_id_sem_zeros(self):
        url = qrcode.url_qrcode(url_base="http://x/qr", chave="1" * 44, ambiente=2,
                                id_csc="000001", csc="ABC")
        parametros, codigo = url.split("?p=")[1].rsplit("|", 1)
        self.assertEqual(parametros, "1" * 44 + "|2|2|1")
        self.assertEqual(len(codigo), 40)
        self.assertEqual(codigo, codigo.upper())

    def test_certificado_le_validade_e_cnpj_e_recusa_senha_errada(self):
        self.assertEqual(self.cert.cnpj, CNPJ)
        self.assertGreater(self.cert.validade, date.today())
        with self.assertRaises(certificado.CertificadoErro):
            certificado.carregar_certificado(self.pfx, "errada")
        with self.assertRaises(certificado.CertificadoErro):
            certificado.carregar_certificado("/nao/existe.pfx", "x")

    def test_xml_assinado_confere_e_adulteracao_e_detectada(self):
        texto = nx.serializar(assinatura.assinar(nx.montar_nfce(nfce_exemplo()), self.cert))
        self.assertTrue(assinatura.verificar(texto))
        self.assertFalse(assinatura.verificar(texto.replace("49.80", "9.80")))

    def test_conteudo_do_xml(self):
        texto = nx.serializar(nx.montar_nfce(nfce_exemplo("2")))
        self.assertIn(nx.TEXTO_HOMOLOGACAO, texto)  # 1º item em homologação
        self.assertEqual(texto.count("SEM GTIN"), 2)  # item 2: cEAN e cEANTrib
        self.assertIn("&lt;bola&gt;", texto)  # caracteres especiais escapados
        self.assertIn("<vTroco>10.20</vTroco>", texto)
        self.assertIn("<vNF>49.80</vNF>", texto)
        producao = nx.serializar(nx.montar_nfce(nfce_exemplo("1")))
        self.assertNotIn(nx.TEXTO_HOMOLOGACAO, producao)

    def test_pagamento_divergente_do_total_e_recusado(self):
        nota = nfce_exemplo()
        nota.troco = D("0")
        with self.assertRaises(ValueError):
            nx.montar_nfce(nota)

    def test_gtin(self):
        self.assertTrue(nx.gtin_valido("7891000100103"))
        self.assertFalse(nx.gtin_valido("7891000100104"))
        self.assertFalse(nx.gtin_valido(""))


class CnpjTests(SimpleTestCase):
    def test_validacao(self):
        self.assertTrue(cnpj_valido("11.222.333/0001-81"))
        self.assertTrue(cnpj_valido("12.ABC.345/01DE-35"))  # exemplo oficial alfanumérico
        for ruim in ("11222333000182", "00000000000000", "123", "", "1122233300018A"):
            self.assertFalse(cnpj_valido(ruim), ruim)


DADOS = {
    "razao_social": "Pet Shop Exemplo ME", "nome_fantasia": "Pet Exemplo",
    "cnpj": "11.222.333/0001-81", "inscricao_estadual": "12345678",
    "inscricao_municipal": "", "regime": "1",
    "logradouro": "Rua A", "numero": "10", "complemento": "", "bairro": "Manilha",
    "municipio": "Itaboraí", "codigo_municipio_ibge": "3301900", "uf": "RJ",
    "cep": "24800-000", "telefone": "", "email": "",
    "ambiente": "HOMOLOGACAO", "provedor": "SEFAZ", "serie_nfce": "1",
    "csc_id": "000001", "certificado_validade": "", "ativo": "on",
}


def criar_empresa(**extra):
    dados = dict(
        razao_social="X", cnpj=CNPJ, inscricao_estadual="1",
        logradouro="R", numero="1", bairro="B", municipio="M",
        codigo_municipio_ibge="3301900", uf="RJ", cep="24800000",
        provedor="SEFAZ", csc_id="000001", padrao=True,
    )
    dados.update(extra)
    return Empresa.objects.create(**dados)


@override_settings(
    SECURE_SSL_REDIRECT=False, SESSION_COOKIE_SECURE=False, CSRF_COOKIE_SECURE=False
)
class BaseFiscal(TestCase):
    pfx = None

    @classmethod
    def setUpTestData(cls):
        cls.admin = User.objects.create_user("admin", password="x-12345678")
        cls.admin.groups.add(Group.objects.create(name=GRUPO_ADMINISTRADOR))
        cls.vendedor = User.objects.create_user("vend", password="x-12345678")
        cls.vendedor.groups.add(Group.objects.create(name=GRUPO_VENDEDOR))

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.pfx = criar_pfx()

    @classmethod
    def tearDownClass(cls):
        os.unlink(cls.pfx)
        super().tearDownClass()

    def setUp(self):
        env = {"FISCAL_CERT_PFX": self.pfx, "FISCAL_CERT_SENHA": "segredo",
               "FISCAL_CSC_HOMOLOGACAO": CSC}
        patcher = mock.patch.object(services, "_env", lambda nome: env.get(nome, ""))
        patcher.start()
        self.addCleanup(patcher.stop)
        self.sefaz = FalsaSefaz()
        canal = mock.patch.object(services, "_criar_canal", lambda empresa: self.sefaz)
        canal.start()
        self.addCleanup(canal.stop)


class EmpresaTests(BaseFiscal):
    def test_diagnostico_pronta(self):
        self.assertTrue(services.pronta_para_emitir(criar_empresa()))

    def test_pendencias_csc_certificado_e_cnpj_diferente(self):
        empresa = criar_empresa(ambiente="PRODUCAO")  # sem CSC de produção
        textos = " ".join(p.texto for p in services.diagnostico(empresa))
        self.assertIn("FISCAL_CSC_PRODUCAO", textos)
        outra = criar_empresa(cnpj="12ABC34501DE35", padrao=False)
        textos = " ".join(p.texto for p in services.diagnostico(outra))
        self.assertIn("diferente do da empresa", textos)

    def test_certificado_vencendo_e_vencido(self):
        empresa = criar_empresa()
        daqui_a_10 = date.today() + timedelta(days=10)
        with mock.patch.object(services, "carregar_certificado_da_empresa") as m:
            m.return_value = mock.Mock(validade=daqui_a_10, cnpj=CNPJ, titular="T")
            niveis = [p.nivel for p in services.diagnostico(empresa) if "vence" in p.texto]
            self.assertEqual(niveis, ["aviso"])
            m.return_value = mock.Mock(validade=date.today() - timedelta(days=1), cnpj=CNPJ, titular="T")
            self.assertFalse(services.pronta_para_emitir(empresa))

    def test_cadastro_pela_tela(self):
        self.client.force_login(self.admin)
        resposta = self.client.post(reverse("fiscal:empresa_create"), DADOS)
        empresa = Empresa.objects.get()
        self.assertRedirects(resposta, reverse("fiscal:empresa_detail", args=[empresa.pk]))
        self.assertEqual((empresa.cnpj, empresa.cep), (CNPJ, "24800000"))
        self.assertTrue(empresa.padrao)
        self.assertTrue(LogAcao.objects.filter(acao=LogAcao.Acao.CRIACAO).exists())

    def test_cnpj_invalido_e_duplicado_recusados(self):
        self.client.force_login(self.admin)
        self.client.post(reverse("fiscal:empresa_create"), {**DADOS, "cnpj": "11222333000182"})
        self.assertEqual(Empresa.objects.count(), 0)
        criar_empresa()
        self.client.post(reverse("fiscal:empresa_create"), DADOS)
        self.assertEqual(Empresa.objects.count(), 1)

    def test_so_uma_empresa_padrao(self):
        self.client.force_login(self.admin)
        primeira = criar_empresa()
        self.client.post(reverse("fiscal:empresa_create"),
                         {**DADOS, "cnpj": "12ABC34501DE35", "padrao": "on"})
        primeira.refresh_from_db()
        self.assertFalse(primeira.padrao)
        self.assertEqual(services.empresa_padrao().cnpj, "12ABC34501DE35")

    def test_empresa_nao_pode_ser_excluida(self):
        with self.assertRaises(Exception):
            criar_empresa().delete()

    def test_somente_administrador(self):
        empresa = criar_empresa()
        self.client.force_login(self.vendedor)
        for nome, args in (("empresa_list", []), ("empresa_detail", [empresa.pk]),
                           ("documento_list", []), ("produtos_pendentes", [])):
            self.assertEqual(self.client.get(reverse(f"fiscal:{nome}", args=args)).status_code, 403)
        self.assertEqual(self.client.post(reverse("fiscal:nfce_gerar", args=[1])).status_code, 403)


class GerarNfceTests(BaseFiscal):
    def setUp(self):
        super().setUp()
        self.empresa = criar_empresa()
        self.produto = Produto.objects.create(nome="Ração Premium", codigo_barras="7891000100103",
                                              preco_venda=D("19.90"))
        MovimentacaoEstoque.registrar(produto=self.produto, tipo=MovimentacaoEstoque.Tipo.ENTRADA,
                                      quantidade=50, usuario=self.admin)
        self.produto.refresh_from_db()

    def vender(self, quantidade=2, dinheiro="50.00"):
        sessao = pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("0"))
        venda, _ = pdv_services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor,
            itens=[{"produto": self.produto, "quantidade": quantidade, "preco": self.produto.preco_venda}],
            pagamentos={"DINHEIRO": D(dinheiro)},
        )
        return venda

    def dados_fiscais(self, ncm="23099090"):
        return ProdutoFiscal.objects.create(produto=self.produto, ncm=ncm)

    def test_gera_assina_numera_e_registra_eventos(self):
        self.dados_fiscais()
        venda = self.vender(2, "50.00")  # total 39,80, troco 10,20
        doc = services.gerar_nfce(venda=venda, usuario=self.admin)
        self.assertEqual((doc.numero, doc.status, doc.ambiente), (1, "ASSINADA", "2"))
        self.assertTrue(assinatura.verificar(doc.xml_assinado))
        self.assertIn("<vTroco>10.20</vTroco>", doc.xml_assinado)
        self.assertIn("<vPag>50.00</vPag>", doc.xml_assinado)  # dinheiro recebido
        self.assertEqual(
            list(doc.eventos.values_list("tipo", flat=True)), ["GERACAO", "ASSINATURA"]
        )
        # segunda venda recebe o número seguinte
        outra = self.vender_segunda()
        self.assertEqual(services.gerar_nfce(venda=outra, usuario=self.admin).numero, 2)

    def vender_segunda(self):
        sessao = pdv_services.sessao_aberta_do(self.vendedor)
        venda, _ = pdv_services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor,
            itens=[{"produto": self.produto, "quantidade": 1, "preco": self.produto.preco_venda}],
            pagamentos={"PIX": D("19.90")},
        )
        return venda

    def test_sem_ncm_nao_gera_e_nao_consome_numero(self):
        venda = self.vender()
        with self.assertRaises(ValidationError):
            services.gerar_nfce(venda=venda, usuario=self.admin)
        self.assertEqual(DocumentoFiscal.objects.count(), 0)
        self.dados_fiscais()
        self.assertEqual(services.gerar_nfce(venda=venda, usuario=self.admin).numero, 1)

    def test_nao_gera_duas_vezes_nem_sem_pagamento(self):
        self.dados_fiscais()
        venda = self.vender()
        services.gerar_nfce(venda=venda, usuario=self.admin)
        with self.assertRaises(ValidationError):
            services.gerar_nfce(venda=venda, usuario=self.admin)
        comum = Venda.registrar_venda(
            vendedor=self.vendedor,
            itens=[{"produto": self.produto, "quantidade": 1, "preco": self.produto.preco_venda}],
        )
        with self.assertRaises(ValidationError):
            services.gerar_nfce(venda=comum, usuario=self.admin)

    def test_documento_e_evento_sao_imutaveis_e_nao_se_excluem(self):
        self.dados_fiscais()
        doc = services.gerar_nfce(venda=self.vender(), usuario=self.admin)
        with self.assertRaises(Exception):
            doc.delete()
        with self.assertRaises(Exception):
            EventoFiscal.objects.filter(documento=doc).update(descricao="x")

    def test_fluxo_pela_tela_e_download_do_xml(self):
        self.dados_fiscais()
        venda = self.vender()
        self.client.force_login(self.admin)
        resposta = self.client.post(reverse("fiscal:nfce_gerar", args=[venda.pk]))
        doc = DocumentoFiscal.objects.get()
        self.assertRedirects(resposta, reverse("fiscal:documento_detail", args=[doc.pk]))
        self.assertEqual(doc.status, "AUTORIZADA")  # SEFAZ simulada no ar
        self.assertContains(self.client.get(reverse("fiscal:documento_detail", args=[doc.pk])),
                            "Rastreabilidade")
        xml = self.client.get(reverse("fiscal:documento_xml", args=[doc.pk]))
        self.assertIn("attachment", xml["Content-Disposition"])
        self.assertTrue(assinatura.verificar(xml.content.decode()))
        self.assertTrue(LogAcao.objects.filter(descricao__contains=doc.chave).exists())

    def test_dados_fiscais_do_produto_pela_tela(self):
        self.client.force_login(self.admin)
        url = reverse("fiscal:produto_fiscal", args=[self.produto.pk])
        ruim = self.client.post(url, {"ncm": "123", "cfop": "5102", "unidade": "un",
                                      "origem": "0", "csosn": "102"})
        self.assertEqual(ruim.status_code, 200)
        self.client.post(url, {"ncm": "2309.90.90", "cfop": "5102", "unidade": "un",
                               "origem": "0", "csosn": "102"})
        fiscal = ProdutoFiscal.objects.get(produto=self.produto)
        self.assertEqual((fiscal.ncm, fiscal.unidade), ("23099090", "UN"))


class TransmissaoTests(GerarNfceTests):
    """Herda os dados de GerarNfceTests (empresa, produto, venda) e usa a SEFAZ simulada."""

    def emitir(self, **kw):
        self.dados_fiscais()
        return services.emitir_nfce(venda=self.vender(), usuario=self.admin)

    def test_emitir_com_sefaz_no_ar_autoriza_e_monta_nfe_proc(self):
        doc, aviso = self.emitir()
        self.assertEqual((doc.status, aviso), ("AUTORIZADA", ""))
        self.assertEqual(doc.protocolo, "133260000000001")
        self.assertTrue(doc.xml_autorizado.startswith("<nfeProc"))
        tipos = list(doc.eventos.values_list("tipo", flat=True))
        self.assertEqual(tipos, ["GERACAO", "ASSINATURA", "ENVIO", "AUTORIZACAO"])
        self.assertEqual(self.sefaz.chamadas, ["status", "autorizacao"])

    def test_sefaz_fora_do_ar_emite_em_contingencia_e_depois_envia(self):
        self.sefaz.fora_do_ar = True
        doc, aviso = self.emitir()
        self.assertEqual((doc.status, doc.tp_emis), ("ASSINADA", 9))
        self.assertIn("CONTINGÊNCIA", aviso)
        self.assertIn("<dhCont>", doc.xml_assinado)
        self.assertIn("<tpEmis>9</tpEmis>", doc.xml_assinado)
        self.assertTrue(assinatura.verificar(doc.xml_assinado))
        self.assertEqual(services.transmitir_pendentes(), (0, 1))  # ainda fora do ar
        self.sefaz.fora_do_ar = False
        self.assertEqual(services.transmitir_pendentes(), (1, 0))
        doc.refresh_from_db()
        self.assertEqual(doc.status, "AUTORIZADA")

    def test_falha_de_rede_na_transmissao_mantem_assinada_para_nova_tentativa(self):
        self.dados_fiscais()
        doc = services.gerar_nfce(venda=self.vender(), usuario=self.admin)
        self.sefaz.fora_do_ar = True
        with self.assertRaises(ValidationError):
            services.transmitir(documento=doc, usuario=self.admin)
        doc.refresh_from_db()
        self.assertEqual(doc.status, "ASSINADA")
        self.assertIn("ERRO", list(doc.eventos.values_list("tipo", flat=True)))
        self.sefaz.fora_do_ar = False
        self.assertEqual(services.transmitir(documento=doc).status, "AUTORIZADA")

    def test_rejeicao_marca_rejeitada_e_regerar_mantem_o_numero(self):
        self.sefaz.rejeitar = True
        doc, aviso = self.emitir()
        self.assertEqual(doc.status, "REJEITADA")
        self.assertIn("225", aviso)
        numero, chave_antiga = doc.numero, doc.chave
        self.sefaz.rejeitar = False
        novo = services.regerar_nfce(documento=doc, usuario=self.admin)
        self.assertEqual((novo.numero, novo.status), (numero, "ASSINADA"))
        self.assertEqual(novo.chave[35:43], chave_antiga[35:43])  # mesmo cNF
        self.assertEqual(services.transmitir(documento=novo).status, "AUTORIZADA")

    def test_nota_assinada_velha_e_regerada_antes_de_enviar(self):
        self.dados_fiscais()
        doc = services.gerar_nfce(venda=self.vender(), usuario=self.admin)
        DocumentoFiscal.objects.filter(pk=doc.pk).update(
            emitido_em=doc.emitido_em - timedelta(minutes=30))
        doc.refresh_from_db()
        doc = services.transmitir(documento=doc)
        self.assertEqual(doc.status, "AUTORIZADA")
        self.assertIn("REGERACAO", list(doc.eventos.values_list("tipo", flat=True)))

    def test_cancelamento(self):
        doc, _ = self.emitir()
        with self.assertRaises(ValidationError):
            services.cancelar(documento=doc, justificativa="curta", usuario=self.admin)
        doc = services.cancelar(documento=doc, justificativa="Cliente desistiu da compra", usuario=self.admin)
        self.assertEqual((doc.status, doc.protocolo_cancelamento), ("CANCELADA", "133260000000009"))
        self.assertTrue(assinatura.verificar(doc.xml_cancelamento, tag="infEvento"))
        with self.assertRaises(ValidationError):  # já cancelada
            services.cancelar(documento=doc, justificativa="Cliente desistiu da compra", usuario=self.admin)

    def test_cancelamento_recusado_pela_sefaz_mantem_autorizada(self):
        doc, _ = self.emitir()
        self.sefaz.cancelamento_ok = False
        with self.assertRaises(ValidationError):
            services.cancelar(documento=doc, justificativa="Cliente desistiu da compra", usuario=self.admin)
        doc.refresh_from_db()
        self.assertEqual(doc.status, "AUTORIZADA")

    def test_inutilizacao(self):
        registro = services.inutilizar(empresa=self.empresa, serie=1, inicio=10, fim=12,
                                      justificativa="Falha de energia durante a emissao",
                                      usuario=self.admin)
        self.assertTrue(registro.aceita)
        with self.assertRaises(ValidationError):
            services.inutilizar(empresa=self.empresa, serie=1, inicio=12, fim=10,
                                justificativa="Falha de energia durante a emissao", usuario=self.admin)
        doc, _ = self.emitir()  # número 1 existe: não pode inutilizar
        with self.assertRaises(ValidationError):
            services.inutilizar(empresa=self.empresa, serie=1, inicio=doc.numero, fim=doc.numero,
                                justificativa="Falha de energia durante a emissao", usuario=self.admin)

    def test_telas_de_acao(self):
        doc, _ = self.emitir()
        self.client.force_login(self.admin)
        self.client.post(reverse("fiscal:documento_consultar", args=[doc.pk]))
        self.client.post(reverse("fiscal:documento_cancelar", args=[doc.pk]),
                         {"justificativa": "Cliente desistiu da compra"})
        doc.refresh_from_db()
        self.assertEqual(doc.status, "CANCELADA")
        self.assertContains(self.client.get(reverse("fiscal:status_servico")), "107")
        self.assertEqual(self.client.get(reverse("fiscal:inutilizacao")).status_code, 200)
        self.client.force_login(self.vendedor)
        self.assertEqual(self.client.post(reverse("fiscal:documento_cancelar", args=[doc.pk])).status_code, 403)


class ProtocoloSefazTests(SimpleTestCase):
    """Sem banco: pedidos e retornos XML."""

    def test_envelope_e_acao_soap(self):
        self.assertIn("NFeAutorizacao4", sefaz.envelope_soap("autorizacao", "<x/>"))
        self.assertEqual(sefaz.soap_action("evento"),
                         "http://www.portalfiscal.inf.br/nfe/wsdl/RecepcaoEvento4/nfeRecepcaoEvento")

    def test_endereco_rj_svrs_e_sobrescrita(self):
        from .nfce import enderecos
        self.assertEqual(
            enderecos.url_servico("RJ", "2", "autorizacao"),
            "https://nfce-homologacao.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx")
        self.assertEqual(enderecos.url_servico("RJ", "1", "status", {"status": "http://x"}), "http://x")
        with self.assertRaises(LookupError):
            enderecos.url_servico("SP", "1", "status")
