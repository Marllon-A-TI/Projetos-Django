import fiscal.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Empresa',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('razao_social', models.CharField(max_length=150, verbose_name='razão social')),
                ('nome_fantasia', models.CharField(blank=True, max_length=100, verbose_name='nome fantasia')),
                ('cnpj', models.CharField(help_text='Só os 14 caracteres, sem pontuação.', max_length=14, unique=True, validators=[fiscal.validators.validar_cnpj], verbose_name='CNPJ')),
                ('inscricao_estadual', models.CharField(blank=True, help_text='Obrigatória para NFC-e/NF-e de mercadorias.', max_length=20, verbose_name='inscrição estadual')),
                ('inscricao_municipal', models.CharField(blank=True, max_length=20, verbose_name='inscrição municipal')),
                ('regime', models.CharField(choices=[('1', 'Simples Nacional'), ('2', 'Simples Nacional (excesso de sublimite)'), ('3', 'Regime normal (Lucro Presumido/Real)'), ('4', 'MEI')], default='1', max_length=1, verbose_name='regime tributário')),
                ('logradouro', models.CharField(max_length=100, verbose_name='logradouro')),
                ('numero', models.CharField(max_length=10, verbose_name='número')),
                ('complemento', models.CharField(blank=True, max_length=60, verbose_name='complemento')),
                ('bairro', models.CharField(max_length=60, verbose_name='bairro')),
                ('municipio', models.CharField(max_length=60, verbose_name='município')),
                ('codigo_municipio_ibge', models.CharField(help_text='7 dígitos, ex.: Itaboraí-RJ = 3301900.', max_length=7, verbose_name='código do município (IBGE)')),
                ('uf', models.CharField(choices=[('AC', 'AC'), ('AL', 'AL'), ('AP', 'AP'), ('AM', 'AM'), ('BA', 'BA'), ('CE', 'CE'), ('DF', 'DF'), ('ES', 'ES'), ('GO', 'GO'), ('MA', 'MA'), ('MT', 'MT'), ('MS', 'MS'), ('MG', 'MG'), ('PA', 'PA'), ('PB', 'PB'), ('PR', 'PR'), ('PE', 'PE'), ('PI', 'PI'), ('RJ', 'RJ'), ('RN', 'RN'), ('RS', 'RS'), ('RO', 'RO'), ('RR', 'RR'), ('SC', 'SC'), ('SP', 'SP'), ('SE', 'SE'), ('TO', 'TO')], max_length=2, verbose_name='UF')),
                ('cep', models.CharField(max_length=8, verbose_name='CEP')),
                ('telefone', models.CharField(blank=True, max_length=20, verbose_name='telefone')),
                ('email', models.EmailField(blank=True, max_length=254, verbose_name='e-mail')),
                ('ambiente', models.CharField(choices=[('HOMOLOGACAO', 'Homologação (testes, sem valor fiscal)'), ('PRODUCAO', 'Produção (valor fiscal)')], default='HOMOLOGACAO', max_length=12, verbose_name='ambiente')),
                ('provedor', models.CharField(choices=[('NENHUM', 'Nenhum (ainda não configurado)'), ('FOCUSNFE', 'Focus NFe')], default='NENHUM', max_length=10, verbose_name='provedor fiscal')),
                ('serie_nfce', models.PositiveSmallIntegerField(default=1, verbose_name='série da NFC-e')),
                ('csc_id', models.CharField(blank=True, help_text='Só o identificador (ex.: 000001). O código CSC fica no provedor.', max_length=6, verbose_name='ID do CSC (NFC-e)')),
                ('certificado_validade', models.DateField(blank=True, help_text='O certificado em si é enviado no painel do provedor.', null=True, verbose_name='validade do certificado A1')),
                ('ativo', models.BooleanField(default=True, verbose_name='ativa')),
                ('padrao', models.BooleanField(default=False, verbose_name='empresa padrão')),
            ],
            options={
                'verbose_name': 'empresa',
                'verbose_name_plural': 'empresas',
                'ordering': ['razao_social'],
            },
        ),
        migrations.AddConstraint(
            model_name='empresa',
            constraint=models.UniqueConstraint(condition=models.Q(('padrao', True)), fields=('padrao',), name='empresa_uma_padrao'),
        ),
    ]
