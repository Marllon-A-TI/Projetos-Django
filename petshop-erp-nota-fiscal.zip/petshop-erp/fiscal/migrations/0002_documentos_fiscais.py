import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('fiscal', '0001_initial'),
        ('produtos', '0002_alter_produto_categoria_alter_produto_options_and_more'),
        ('vendas', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AlterField(
            model_name='empresa',
            name='provedor',
            field=models.CharField(choices=[('NENHUM', 'Nenhum (ainda não configurado)'), ('SEFAZ', 'Direto na SEFAZ (gratuito)')], default='SEFAZ', max_length=10, verbose_name='forma de emissão'),
        ),
        migrations.AlterField(
            model_name='empresa',
            name='csc_id',
            field=models.CharField(blank=True, help_text='Só o identificador (ex.: 000001). O código CSC vai no .env.', max_length=6, verbose_name='ID do CSC (NFC-e)'),
        ),
        migrations.AlterField(
            model_name='empresa',
            name='certificado_validade',
            field=models.DateField(blank=True, help_text='Opcional: a validade real é lida do arquivo do certificado.', null=True, verbose_name='validade do certificado A1'),
        ),
        migrations.CreateModel(
            name='ProdutoFiscal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('ncm', models.CharField(help_text='8 dígitos. Pergunte ao seu contador.', max_length=8, verbose_name='NCM')),
                ('cest', models.CharField(blank=True, help_text='Só se o produto tiver.', max_length=7, verbose_name='CEST')),
                ('cfop', models.CharField(default='5102', help_text='5102 = venda de mercadoria adquirida de terceiros; 5405 = com ST.', max_length=4, verbose_name='CFOP')),
                ('unidade', models.CharField(default='UN', max_length=6, verbose_name='unidade')),
                ('origem', models.CharField(choices=[('0', '0 - Nacional'), ('1', '1 - Estrangeira (importação direta)'), ('2', '2 - Estrangeira (mercado interno)')], default='0', max_length=1, verbose_name='origem')),
                ('csosn', models.CharField(choices=[('102', '102 - Tributada sem permissão de crédito'), ('103', '103 - Isenta de ICMS (faixa de receita bruta)'), ('300', '300 - Imune'), ('400', '400 - Não tributada pelo Simples Nacional'), ('500', '500 - ICMS cobrado antes por ST ou antecipação'), ('900', '900 - Outros')], default='102', max_length=3, verbose_name='CSOSN')),
                ('produto', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='fiscal', to='produtos.produto', verbose_name='produto')),
            ],
            options={
                'verbose_name': 'dados fiscais do produto',
                'verbose_name_plural': 'dados fiscais dos produtos',
            },
        ),
        migrations.CreateModel(
            name='SequenciaNumeracao',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('modelo', models.CharField(max_length=2)),
                ('serie', models.PositiveSmallIntegerField()),
                ('ambiente', models.CharField(max_length=1)),
                ('ultimo_numero', models.PositiveIntegerField(default=0)),
                ('empresa', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='sequencias', to='fiscal.empresa')),
            ],
            options={
                'verbose_name': 'sequência de numeração',
                'verbose_name_plural': 'sequências de numeração',
            },
        ),
        migrations.CreateModel(
            name='DocumentoFiscal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('modelo', models.CharField(choices=[('65', 'NFC-e')], default='65', max_length=2, verbose_name='modelo')),
                ('serie', models.PositiveSmallIntegerField(verbose_name='série')),
                ('numero', models.PositiveIntegerField(verbose_name='número')),
                ('ambiente', models.CharField(max_length=1, verbose_name='ambiente')),
                ('tp_emis', models.PositiveSmallIntegerField(default=1, verbose_name='tipo de emissão')),
                ('chave', models.CharField(max_length=44, unique=True, verbose_name='chave de acesso')),
                ('status', models.CharField(choices=[('ASSINADA', 'Assinada (aguardando envio)'), ('AUTORIZADA', 'Autorizada'), ('REJEITADA', 'Rejeitada'), ('CANCELADA', 'Cancelada'), ('DENEGADA', 'Denegada')], default='ASSINADA', max_length=12, verbose_name='situação')),
                ('valor_total', models.DecimalField(decimal_places=2, max_digits=12, verbose_name='valor total')),
                ('emitido_em', models.DateTimeField(verbose_name='emitido em')),
                ('xml_assinado', models.TextField(verbose_name='XML assinado')),
                ('xml_autorizado', models.TextField(blank=True, default='', verbose_name='XML autorizado (com protocolo)')),
                ('protocolo', models.CharField(blank=True, default='', max_length=20, verbose_name='protocolo')),
                ('motivo', models.TextField(blank=True, default='', verbose_name='motivo/retorno da SEFAZ')),
                ('qrcode_url', models.TextField(blank=True, default='', verbose_name='URL do QR-Code')),
                ('empresa', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='documentos', to='fiscal.empresa')),
                ('venda', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='documentos_fiscais', to='vendas.venda')),
            ],
            options={
                'verbose_name': 'documento fiscal',
                'verbose_name_plural': 'documentos fiscais',
                'ordering': ['-emitido_em', '-id'],
            },
        ),
        migrations.CreateModel(
            name='EventoFiscal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('tipo', models.CharField(choices=[('GERACAO', 'XML gerado'), ('ASSINATURA', 'XML assinado'), ('ENVIO', 'Enviado à SEFAZ'), ('AUTORIZACAO', 'Autorizado'), ('REJEICAO', 'Rejeitado'), ('CANCELAMENTO', 'Cancelado'), ('CONSULTA', 'Consulta'), ('ERRO', 'Erro')], max_length=14, verbose_name='tipo')),
                ('descricao', models.TextField(blank=True, default='', verbose_name='descrição')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='data')),
                ('documento', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='eventos', to='fiscal.documentofiscal')),
                ('usuario', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='eventos_fiscais', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'evento fiscal',
                'verbose_name_plural': 'eventos fiscais',
                'ordering': ['criado_em', 'id'],
            },
        ),
        migrations.AddConstraint(
            model_name='sequencianumeracao',
            constraint=models.UniqueConstraint(fields=('empresa', 'modelo', 'serie', 'ambiente'), name='sequencia_unica'),
        ),
        migrations.AddIndex(
            model_name='documentofiscal',
            index=models.Index(fields=['status'], name='docfiscal_status_idx'),
        ),
        migrations.AddConstraint(
            model_name='documentofiscal',
            constraint=models.UniqueConstraint(fields=('venda', 'modelo'), name='docfiscal_venda_modelo_unico'),
        ),
        migrations.AddConstraint(
            model_name='documentofiscal',
            constraint=models.UniqueConstraint(fields=('empresa', 'modelo', 'serie', 'numero', 'ambiente'), name='docfiscal_numero_unico'),
        ),
        migrations.AddConstraint(
            model_name='documentofiscal',
            constraint=models.CheckConstraint(condition=models.Q(('valor_total__gte', 0)), name='docfiscal_valor_nao_negativo'),
        ),
    ]
