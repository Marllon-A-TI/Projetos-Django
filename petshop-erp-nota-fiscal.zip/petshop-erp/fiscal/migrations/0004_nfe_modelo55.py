import django.db.models.deletion
import fiscal.validators
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('fiscal', '0003_transmissao_sefaz'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name='empresa',
            name='serie_nfe',
            field=models.PositiveSmallIntegerField(default=1, verbose_name='série da NF-e (modelo 55)'),
        ),
        migrations.CreateModel(
            name='Cliente',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('nome', models.CharField(max_length=60, verbose_name='nome / razão social')),
                ('documento', models.CharField(help_text='Só os números (CPF 11, CNPJ 14).', max_length=14, unique=True, validators=[fiscal.validators.validar_documento], verbose_name='CPF ou CNPJ')),
                ('ind_ie', models.CharField(choices=[('9', 'Não contribuinte (sem inscrição estadual)'), ('1', 'Contribuinte do ICMS (tem inscrição estadual)'), ('2', 'Contribuinte isento de inscrição')], default='9', max_length=1, verbose_name='indicador de IE')),
                ('inscricao_estadual', models.CharField(blank=True, max_length=14, verbose_name='inscrição estadual')),
                ('email', models.EmailField(blank=True, max_length=254, verbose_name='e-mail')),
                ('telefone', models.CharField(blank=True, max_length=20, verbose_name='telefone')),
                ('logradouro', models.CharField(max_length=60, verbose_name='logradouro')),
                ('numero', models.CharField(max_length=10, verbose_name='número')),
                ('complemento', models.CharField(blank=True, max_length=60, verbose_name='complemento')),
                ('bairro', models.CharField(max_length=60, verbose_name='bairro')),
                ('municipio', models.CharField(max_length=60, verbose_name='município')),
                ('codigo_municipio_ibge', models.CharField(max_length=7, verbose_name='código do município (IBGE)')),
                ('uf', models.CharField(choices=[('AC', 'AC'), ('AL', 'AL'), ('AP', 'AP'), ('AM', 'AM'), ('BA', 'BA'), ('CE', 'CE'), ('DF', 'DF'), ('ES', 'ES'), ('GO', 'GO'), ('MA', 'MA'), ('MT', 'MT'), ('MS', 'MS'), ('MG', 'MG'), ('PA', 'PA'), ('PB', 'PB'), ('PR', 'PR'), ('PE', 'PE'), ('PI', 'PI'), ('RJ', 'RJ'), ('RN', 'RN'), ('RS', 'RS'), ('RO', 'RO'), ('RR', 'RR'), ('SC', 'SC'), ('SP', 'SP'), ('SE', 'SE'), ('TO', 'TO')], max_length=2, verbose_name='UF')),
                ('cep', models.CharField(max_length=8, verbose_name='CEP')),
                ('ativo', models.BooleanField(default=True, verbose_name='ativo')),
            ],
            options={
                'verbose_name': 'cliente (destinatário)',
                'verbose_name_plural': 'clientes (destinatários)',
                'ordering': ['nome', 'id'],
            },
        ),
        migrations.AlterField(
            model_name='documentofiscal',
            name='modelo',
            field=models.CharField(choices=[('65', 'NFC-e'), ('55', 'NF-e')], default='65', max_length=2, verbose_name='modelo'),
        ),
        migrations.AddField(
            model_name='documentofiscal',
            name='cliente',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='documentos', to='fiscal.cliente', verbose_name='destinatário (NF-e)'),
        ),
        migrations.AlterField(
            model_name='eventofiscal',
            name='tipo',
            field=models.CharField(choices=[('GERACAO', 'XML gerado'), ('ASSINATURA', 'XML assinado'), ('ENVIO', 'Enviado à SEFAZ'), ('AUTORIZACAO', 'Autorizado'), ('REJEICAO', 'Rejeitado'), ('CANCELAMENTO', 'Cancelado'), ('CONSULTA', 'Consulta'), ('CONTINGENCIA', 'Contingência'), ('REGERACAO', 'XML regerado'), ('ERRO', 'Erro'), ('CCE', 'Carta de correção')], max_length=14, verbose_name='tipo'),
        ),
        migrations.CreateModel(
            name='CartaCorrecao',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('sequencia', models.PositiveSmallIntegerField(help_text='1 a 20 por nota.', verbose_name='sequência')),
                ('texto', models.TextField(verbose_name='texto da correção')),
                ('aceita', models.BooleanField(default=False, verbose_name='aceita pela SEFAZ')),
                ('cstat', models.CharField(blank=True, default='', max_length=4, verbose_name='código de retorno')),
                ('motivo', models.TextField(blank=True, default='', verbose_name='retorno')),
                ('protocolo', models.CharField(blank=True, default='', max_length=20, verbose_name='protocolo')),
                ('xml_evento', models.TextField(blank=True, default='', verbose_name='XML do evento')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='data')),
                ('documento', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='cartas', to='fiscal.documentofiscal')),
                ('usuario', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='cartas_correcao', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'carta de correção',
                'verbose_name_plural': 'cartas de correção',
                'ordering': ['documento_id', 'sequencia', 'id'],
            },
        ),
        migrations.AddConstraint(
            model_name='cartacorrecao',
            constraint=models.UniqueConstraint(condition=models.Q(('aceita', True)), fields=('documento', 'sequencia'), name='cce_sequencia_aceita_unica'),
        ),
    ]
