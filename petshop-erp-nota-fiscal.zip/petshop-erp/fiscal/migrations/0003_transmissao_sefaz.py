import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('fiscal', '0002_documentos_fiscais'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.AddField(
            model_name='documentofiscal',
            name='xml_cancelamento',
            field=models.TextField(blank=True, default='', verbose_name='XML do evento de cancelamento'),
        ),
        migrations.AddField(
            model_name='documentofiscal',
            name='protocolo_cancelamento',
            field=models.CharField(blank=True, default='', max_length=20, verbose_name='protocolo do cancelamento'),
        ),
        migrations.AddField(
            model_name='documentofiscal',
            name='justificativa',
            field=models.TextField(blank=True, default='', verbose_name='justificativa (cancelamento/contingência)'),
        ),
        migrations.AlterField(
            model_name='eventofiscal',
            name='tipo',
            field=models.CharField(choices=[('GERACAO', 'XML gerado'), ('ASSINATURA', 'XML assinado'), ('ENVIO', 'Enviado à SEFAZ'), ('AUTORIZACAO', 'Autorizado'), ('REJEICAO', 'Rejeitado'), ('CANCELAMENTO', 'Cancelado'), ('CONSULTA', 'Consulta'), ('CONTINGENCIA', 'Contingência'), ('REGERACAO', 'XML regerado'), ('ERRO', 'Erro')], max_length=14, verbose_name='tipo'),
        ),
        migrations.CreateModel(
            name='Inutilizacao',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('modelo', models.CharField(default='65', max_length=2)),
                ('serie', models.PositiveSmallIntegerField(verbose_name='série')),
                ('ambiente', models.CharField(max_length=1, verbose_name='ambiente')),
                ('numero_inicial', models.PositiveIntegerField(verbose_name='número inicial')),
                ('numero_final', models.PositiveIntegerField(verbose_name='número final')),
                ('justificativa', models.TextField(verbose_name='justificativa')),
                ('aceita', models.BooleanField(default=False, verbose_name='aceita pela SEFAZ')),
                ('cstat', models.CharField(blank=True, default='', max_length=4, verbose_name='código de retorno')),
                ('motivo', models.TextField(blank=True, default='', verbose_name='retorno')),
                ('protocolo', models.CharField(blank=True, default='', max_length=20, verbose_name='protocolo')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='data')),
                ('empresa', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='inutilizacoes', to='fiscal.empresa')),
                ('usuario', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='inutilizacoes', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'inutilização',
                'verbose_name_plural': 'inutilizações',
                'ordering': ['-criado_em', '-id'],
            },
        ),
        migrations.AddConstraint(
            model_name='inutilizacao',
            constraint=models.CheckConstraint(condition=models.Q(('numero_final__gte', models.F('numero_inicial'))), name='inutilizacao_faixa_valida'),
        ),
    ]
