"""Transporte HTTPS com certificado de cliente (mTLS) para a SEFAZ. Sem Django."""

import os
import tempfile

import requests
from cryptography.hazmat.primitives import serialization

from .enderecos import OPERACOES
from .sefaz import envelope_soap, soap_action


class CanalErro(Exception):
    """Falha de rede/HTTP ao falar com a SEFAZ (mensagem em português)."""


class CanalSefaz:
    def __init__(self, certificado, ca_bundle="", timeout=30):
        self.certificado = certificado
        self.ca_bundle = ca_bundle or True  # True = repositório padrão do Python
        self.timeout = timeout

    def enviar(self, url, servico, xml_pedido):
        """POST SOAP 1.2. Devolve o corpo da resposta (bytes)."""
        assert servico in OPERACOES
        corpo = envelope_soap(servico, xml_pedido).encode("utf-8")
        cabecalhos = {
            "Content-Type": f'application/soap+xml; charset=utf-8; action="{soap_action(servico)}"'
        }
        pasta = tempfile.mkdtemp(prefix="petshop-mtls-")
        caminho_cert = os.path.join(pasta, "c.pem")
        caminho_chave = os.path.join(pasta, "k.pem")
        try:
            # o requests só aceita arquivos; ficam em pasta temporária e são apagados em seguida
            with open(caminho_chave, "wb") as arq:
                os.chmod(caminho_chave, 0o600)
                arq.write(self.certificado.chave_privada.private_bytes(
                    serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                    serialization.NoEncryption()))
            with open(caminho_cert, "wb") as arq:
                arq.write(self.certificado.certificado.public_bytes(serialization.Encoding.PEM))
            try:
                resposta = requests.post(
                    url, data=corpo, headers=cabecalhos, timeout=self.timeout,
                    cert=(caminho_cert, caminho_chave), verify=self.ca_bundle,
                )
            except requests.exceptions.SSLError as exc:
                raise CanalErro(
                    "Falha de segurança (SSL) ao falar com a SEFAZ. Se for erro de cadeia de "
                    "certificados, defina FISCAL_CA_BUNDLE no .env com o arquivo da cadeia "
                    f"ICP-Brasil/SEFAZ. Detalhe: {exc}"
                )
            except requests.exceptions.RequestException as exc:
                raise CanalErro(f"Sem comunicação com a SEFAZ: {exc}")
        finally:
            for arquivo in (caminho_cert, caminho_chave):
                try:
                    os.remove(arquivo)
                except OSError:
                    pass
            try:
                os.rmdir(pasta)
            except OSError:
                pass
        if resposta.status_code != 200:
            raise CanalErro(f"A SEFAZ respondeu HTTP {resposta.status_code}.")
        return resposta.content
