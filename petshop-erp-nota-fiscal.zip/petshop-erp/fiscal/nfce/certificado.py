"""Leitura do certificado A1 (.pfx/.p12) no computador da loja. Sem Django."""

import re
from dataclasses import dataclass
from datetime import date

from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID


class CertificadoErro(Exception):
    """Problema ao ler o certificado (mensagem já em português, para a tela)."""


@dataclass
class CertificadoA1:
    chave_privada: object
    certificado: object
    validade: date
    titular: str
    cnpj: str  # CNPJ achado no nome do titular, ou ""


def carregar_certificado(caminho, senha):
    if not caminho:
        raise CertificadoErro("Caminho do certificado A1 não informado no .env.")
    try:
        with open(caminho, "rb") as arquivo:
            conteudo = arquivo.read()
    except OSError:
        raise CertificadoErro(f"Não consegui abrir o arquivo do certificado: {caminho}")
    try:
        chave, certificado, _ = pkcs12.load_key_and_certificates(
            conteudo, (senha or "").encode()
        )
    except ValueError:
        raise CertificadoErro("Senha do certificado incorreta ou arquivo inválido.")
    if chave is None or certificado is None:
        raise CertificadoErro("O arquivo não contém chave privada e certificado.")

    nomes = certificado.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    titular = nomes[0].value if nomes else ""
    achado = re.search(r":([0-9A-Z]{14})\b", titular)
    return CertificadoA1(
        chave_privada=chave,
        certificado=certificado,
        validade=certificado.not_valid_after_utc.date(),
        titular=titular,
        cnpj=achado.group(1) if achado else "",
    )
