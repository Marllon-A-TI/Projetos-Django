"""
Monta o XML da NFC-e (modelo 65) e da NF-e (modelo 55), layout 4.00, Simples
Nacional. NFC-e: consumidor não identificado. NF-e: com destinatário, operação
interna, sem contingência. Sem Django: recebe dataclasses.

Não inclui o grupo IBS/CBS (NT 2025.002): em produção a SEFAZ não rejeita sua
ausência enquanto a data estiver como "implementação futura" — confirme na
versão vigente da NT antes de entrar em produção.
"""

from dataclasses import dataclass, field
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal

from lxml import etree

NS_NFE = "http://www.portalfiscal.inf.br/nfe"
VERSAO = "4.00"
TEXTO_HOMOLOGACAO = "NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL"

CENTAVOS = Decimal("0.01")


@dataclass
class Emitente:
    cnpj: str
    razao_social: str
    nome_fantasia: str
    inscricao_estadual: str
    regime: str  # CRT
    logradouro: str
    numero: str
    complemento: str
    bairro: str
    codigo_municipio: str
    municipio: str
    uf: str
    cep: str
    telefone: str = ""


@dataclass
class Item:
    codigo: str
    gtin: str  # "" se não houver
    descricao: str
    ncm: str
    cest: str
    cfop: str
    unidade: str
    quantidade: Decimal
    valor_unitario: Decimal
    origem: str
    csosn: str


@dataclass
class Destinatario:
    """Destinatário da NF-e (modelo 55)."""

    documento: str  # CPF (11) ou CNPJ (14, alfanumérico)
    nome: str
    logradouro: str
    numero: str
    complemento: str
    bairro: str
    codigo_municipio: str
    municipio: str
    uf: str
    cep: str
    ind_ie: str = "9"  # 1 contribuinte, 2 isento, 9 não contribuinte
    inscricao_estadual: str = ""
    email: str = ""
    telefone: str = ""


@dataclass
class Pagamento:
    t_pag: str  # "01", "03", "04", "17", "99"
    valor: Decimal


@dataclass
class Nfce:
    emitente: Emitente
    itens: list
    pagamentos: list
    troco: Decimal
    serie: int
    numero: int
    codigo_numerico: int
    chave: str
    ambiente: str  # "1" produção, "2" homologação
    emissao: datetime  # com fuso
    codigo_uf: int
    tp_emis: int = 1  # 1 normal, 9 contingência offline
    dh_contingencia: datetime = None  # obrigatório quando tp_emis == 9
    just_contingencia: str = ""
    ver_proc: str = "PetShopERP 1.0"
    url_qrcode: str = ""
    url_chave: str = ""
    modelo: str = "65"  # "65" NFC-e, "55" NF-e
    destinatario: Destinatario = None  # obrigatório na NF-e
    nat_op: str = ""
    _extras: dict = field(default_factory=dict)


def _dec(valor, casas):
    return str(Decimal(valor).quantize(Decimal(1).scaleb(-casas), rounding=ROUND_HALF_UP))


def _txt(texto, limite):
    """Texto de uma linha, sem espaços duplicados, no limite do layout."""
    return " ".join(str(texto or "").split())[:limite]


def gtin_valido(codigo):
    """GTIN-8/12/13/14 com dígito verificador correto."""
    if not codigo or not codigo.isdigit() or len(codigo) not in (8, 12, 13, 14):
        return False
    corpo, dv = codigo[:-1], int(codigo[-1])
    soma = sum(int(d) * (3 if i % 2 == 0 else 1) for i, d in enumerate(reversed(corpo)))
    return (10 - soma % 10) % 10 == dv


def valor_item(item):
    return (item.quantidade * item.valor_unitario).quantize(CENTAVOS, rounding=ROUND_HALF_UP)


def _el(pai, nome, texto=None):
    elemento = etree.SubElement(pai, f"{{{NS_NFE}}}{nome}")
    if texto is not None:
        elemento.text = str(texto)
    return elemento


def montar_nfce(n: Nfce):
    """Devolve o elemento <NFe> (sem assinatura)."""
    if n.modelo not in ("65", "55"):
        raise ValueError("Modelo inválido: use 65 (NFC-e) ou 55 (NF-e).")
    nfe55 = n.modelo == "55"
    if nfe55 and n.destinatario is None:
        raise ValueError("A NF-e precisa de destinatário.")
    if nfe55 and n.tp_emis != 1:
        raise ValueError("A NF-e só é emitida em modo normal (sem contingência offline).")
    total = sum((valor_item(i) for i in n.itens), Decimal("0.00"))
    pago = sum((p.valor for p in n.pagamentos), Decimal("0.00"))
    sem_pagamento = nfe55 and all(p.t_pag == "90" for p in n.pagamentos)  # tPag 90: sem pagamento
    if not sem_pagamento and pago - n.troco != total:
        raise ValueError(
            f"Pagamentos ({pago}) menos troco ({n.troco}) diferem do total ({total})."
        )

    nfe = etree.Element(f"{{{NS_NFE}}}NFe", nsmap={None: NS_NFE})
    inf = _el(nfe, "infNFe")
    inf.set("Id", f"NFe{n.chave}")
    inf.set("versao", VERSAO)

    e = n.emitente
    ide = _el(inf, "ide")
    _el(ide, "cUF", n.codigo_uf)
    _el(ide, "cNF", f"{n.codigo_numerico:08d}")
    _el(ide, "natOp", _txt(n.nat_op or ("VENDA DE MERCADORIA" if nfe55 else "VENDA AO CONSUMIDOR"), 60))
    _el(ide, "mod", n.modelo)
    _el(ide, "serie", int(n.serie))
    _el(ide, "nNF", int(n.numero))
    _el(ide, "dhEmi", n.emissao.isoformat(timespec="seconds"))
    _el(ide, "tpNF", "1")
    _el(ide, "idDest", "1")
    _el(ide, "cMunFG", e.codigo_municipio)
    _el(ide, "tpImp", "1" if nfe55 else "4")
    _el(ide, "tpEmis", n.tp_emis)
    _el(ide, "cDV", n.chave[-1])
    _el(ide, "tpAmb", n.ambiente)
    _el(ide, "finNFe", "1")
    _el(ide, "indFinal", "1" if (not nfe55 or n.destinatario.ind_ie != "1") else "0")
    _el(ide, "indPres", "1")
    _el(ide, "procEmi", "0")
    _el(ide, "verProc", n.ver_proc)
    if n.tp_emis == 9:
        if n.dh_contingencia is None or len(_txt(n.just_contingencia, 256)) < 15:
            raise ValueError("Contingência exige data/hora e justificativa de 15+ caracteres.")
        _el(ide, "dhCont", n.dh_contingencia.isoformat(timespec="seconds"))
        _el(ide, "xJust", _txt(n.just_contingencia, 256))

    emit = _el(inf, "emit")
    _el(emit, "CNPJ", e.cnpj)
    _el(emit, "xNome", _txt(e.razao_social, 60))
    if e.nome_fantasia:
        _el(emit, "xFant", _txt(e.nome_fantasia, 60))
    ender = _el(emit, "enderEmit")
    _el(ender, "xLgr", _txt(e.logradouro, 60))
    _el(ender, "nro", _txt(e.numero, 60))
    if e.complemento:
        _el(ender, "xCpl", _txt(e.complemento, 60))
    _el(ender, "xBairro", _txt(e.bairro, 60))
    _el(ender, "cMun", e.codigo_municipio)
    _el(ender, "xMun", _txt(e.municipio, 60))
    _el(ender, "UF", e.uf)
    _el(ender, "CEP", e.cep)
    _el(ender, "cPais", "1058")
    _el(ender, "xPais", "Brasil")
    fone = "".join(c for c in e.telefone if c.isdigit())
    if 6 <= len(fone) <= 14:
        _el(ender, "fone", fone)
    _el(emit, "IE", e.inscricao_estadual)
    _el(emit, "CRT", e.regime)

    if nfe55:
        _montar_destinatario(inf, n.destinatario, homologacao=n.ambiente == "2")

    for numero_item, item in enumerate(n.itens, start=1):
        det = _el(inf, "det")
        det.set("nItem", str(numero_item))
        prod = _el(det, "prod")
        gtin = item.gtin if gtin_valido(item.gtin) else "SEM GTIN"
        descricao = item.descricao
        if n.ambiente == "2" and numero_item == 1:
            descricao = TEXTO_HOMOLOGACAO
        _el(prod, "cProd", _txt(item.codigo, 60))
        _el(prod, "cEAN", gtin)
        _el(prod, "xProd", _txt(descricao, 120))
        _el(prod, "NCM", item.ncm)
        if item.cest:
            _el(prod, "CEST", item.cest)
        _el(prod, "CFOP", item.cfop)
        _el(prod, "uCom", _txt(item.unidade, 6))
        _el(prod, "qCom", _dec(item.quantidade, 4))
        _el(prod, "vUnCom", _dec(item.valor_unitario, 4))
        _el(prod, "vProd", _dec(valor_item(item), 2))
        _el(prod, "cEANTrib", gtin)
        _el(prod, "uTrib", _txt(item.unidade, 6))
        _el(prod, "qTrib", _dec(item.quantidade, 4))
        _el(prod, "vUnTrib", _dec(item.valor_unitario, 4))
        _el(prod, "indTot", "1")

        imposto = _el(det, "imposto")
        icms = _el(_el(imposto, "ICMS"), f"ICMSSN{item.csosn}")
        _el(icms, "orig", item.origem)
        _el(icms, "CSOSN", item.csosn)
        pis = _el(_el(imposto, "PIS"), "PISOutr")
        _el(pis, "CST", "49")
        _el(pis, "vBC", "0.00")
        _el(pis, "pPIS", "0.0000")
        _el(pis, "vPIS", "0.00")
        cofins = _el(_el(imposto, "COFINS"), "COFINSOutr")
        _el(cofins, "CST", "49")
        _el(cofins, "vBC", "0.00")
        _el(cofins, "pCOFINS", "0.0000")
        _el(cofins, "vCOFINS", "0.00")

    tot = _el(_el(inf, "total"), "ICMSTot")
    for nome in ("vBC", "vICMS", "vICMSDeson", "vFCP", "vBCST", "vST", "vFCPST", "vFCPSTRet"):
        _el(tot, nome, "0.00")
    _el(tot, "vProd", _dec(total, 2))
    for nome in ("vFrete", "vSeg", "vDesc", "vII", "vIPI", "vIPIDevol", "vPIS", "vCOFINS", "vOutro"):
        _el(tot, nome, "0.00")
    _el(tot, "vNF", _dec(total, 2))

    _el(_el(inf, "transp"), "modFrete", "9")

    pag = _el(inf, "pag")
    for pagamento in n.pagamentos:
        det_pag = _el(pag, "detPag")
        _el(det_pag, "tPag", pagamento.t_pag)
        if pagamento.t_pag == "99":
            _el(det_pag, "xPag", "Outros")
        _el(det_pag, "vPag", _dec(pagamento.valor, 2))
        if pagamento.t_pag in ("03", "04"):
            _el(_el(det_pag, "card"), "tpIntegra", "2")  # não integrado à automação
    if n.troco > 0:
        _el(pag, "vTroco", _dec(n.troco, 2))

    if n.url_qrcode and not nfe55:
        inserir_suplemento(nfe, n.url_qrcode, n.url_chave)
    return nfe


def _montar_destinatario(inf, d: Destinatario, homologacao):
    doc = d.documento.upper()
    dest = _el(inf, "dest")
    _el(dest, "CPF" if len(doc) == 11 else "CNPJ", doc)
    _el(dest, "xNome", TEXTO_HOMOLOGACAO if homologacao else _txt(d.nome, 60))
    ender = _el(dest, "enderDest")
    _el(ender, "xLgr", _txt(d.logradouro, 60))
    _el(ender, "nro", _txt(d.numero, 60))
    if d.complemento:
        _el(ender, "xCpl", _txt(d.complemento, 60))
    _el(ender, "xBairro", _txt(d.bairro, 60))
    _el(ender, "cMun", d.codigo_municipio)
    _el(ender, "xMun", _txt(d.municipio, 60))
    _el(ender, "UF", d.uf)
    _el(ender, "CEP", d.cep)
    _el(ender, "cPais", "1058")
    _el(ender, "xPais", "Brasil")
    fone = "".join(c for c in d.telefone if c.isdigit())
    if 6 <= len(fone) <= 14:
        _el(ender, "fone", fone)
    _el(dest, "indIEDest", d.ind_ie)
    if d.ind_ie == "1" and d.inscricao_estadual:
        _el(dest, "IE", d.inscricao_estadual)
    if d.email:
        _el(dest, "email", _txt(d.email, 60))


def inserir_suplemento(nfe, url_qrcode, url_chave):
    """
    infNFeSupl (QR-Code e URL de consulta) fica depois de infNFe e ANTES da
    assinatura; não faz parte do trecho assinado, por isso pode ser inserido
    depois de assinar (necessário no QR-Code de contingência, que usa o digest).
    """
    supl = etree.Element(f"{{{NS_NFE}}}infNFeSupl")
    qr = _el(supl, "qrCode")
    qr.text = etree.CDATA(url_qrcode)
    _el(supl, "urlChave", url_chave)
    inf = nfe.find(f"{{{NS_NFE}}}infNFe")
    inf.addnext(supl)
    return nfe


def serializar(nfe):
    return etree.tostring(nfe, encoding="UTF-8", xml_declaration=False).decode("utf-8")
