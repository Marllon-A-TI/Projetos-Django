"""Chave de acesso de 44 posições (NF-e/NFC-e) e dígito verificador (módulo 11)."""

CODIGO_UF = {
    "RO": 11, "AC": 12, "AM": 13, "RR": 14, "PA": 15, "AP": 16, "TO": 17,
    "MA": 21, "PI": 22, "CE": 23, "RN": 24, "PB": 25, "PE": 26, "AL": 27,
    "SE": 28, "BA": 29, "MG": 31, "ES": 32, "RJ": 33, "SP": 35, "PR": 41,
    "SC": 42, "RS": 43, "MS": 50, "MT": 51, "GO": 52, "DF": 53,
}


def digito_verificador(base43):
    """Módulo 11, pesos 2..9 da direita para a esquerda; letras valem ASCII-48."""
    soma, peso = 0, 2
    for caractere in reversed(base43):
        soma += (ord(caractere) - 48) * peso
        peso = 2 if peso == 9 else peso + 1
    resto = soma % 11
    return "0" if resto in (0, 1) else str(11 - resto)


def gerar_chave(*, uf, emissao, cnpj, modelo, serie, numero, tp_emis, codigo_numerico):
    """
    cUF(2) AAMM(4) CNPJ(14) mod(2) serie(3) nNF(9) tpEmis(1) cNF(8) cDV(1).
    `emissao` é date/datetime; `codigo_numerico` é inteiro de até 8 dígitos.
    """
    base = (
        f"{CODIGO_UF[uf]:02d}"
        f"{emissao:%y%m}"
        f"{cnpj.upper()}"
        f"{int(modelo):02d}"
        f"{int(serie):03d}"
        f"{int(numero):09d}"
        f"{int(tp_emis):d}"
        f"{int(codigo_numerico):08d}"
    )
    if len(base) != 43:
        raise ValueError(f"Chave com tamanho inválido ({len(base)} em vez de 43).")
    return base + digito_verificador(base)
