"""
Protocolo com a SEFAZ (NFC-e 4.00): pedidos XML, envelope SOAP 1.2 e leitura
dos retornos. Sem Django e sem rede: o transporte (`canal`) é injetado, então
tudo aqui é testável com respostas simuladas.
"""

from dataclasses import dataclass, field
from datetime import datetime

from lxml import etree

from . import assinatura
from .enderecos import OPERACOES
from .xml import NS_NFE

NS_SOAP = "http://www.w3.org/2003/05/soap-envelope"
VERSAO = "4.00"

CSTAT_AUTORIZADA = {"100", "150"}
CSTAT_DENEGADA = {"110", "301", "302", "303"}
CSTAT_CANCELADO = {"135", "155"}  # evento registrado (155 = fora de prazo, mas registrado)
CSTAT_INUTILIZADO = {"102"}
CSTAT_SERVICO_OK = {"107"}
CSTAT_JA_AUTORIZADA = {"204"}  # duplicidade: consultar para recuperar o protocolo

CSTAT_CCE_REGISTRADA = {"135", "136"}  # 136 = registrado, sem vinculação à NF-e
CCE_COND_USO = (
    "A Carta de Correcao e disciplinada pelo paragrafo 1o-A do art. 7o do Convenio S/N, de 15 de "
    "dezembro de 1970 e pode ser utilizada para regularizacao de erro ocorrido na emissao de documento "
    "fiscal, desde que o erro nao esteja relacionado com: I - as variaveis que determinam o valor do "
    "imposto tais como: base de calculo, aliquota, diferenca de preco, quantidade, valor da operacao ou "
    "da prestacao; II - a correcao de dados cadastrais que implique mudanca do remetente ou do "
    "destinatario; III - a data de emissao ou de saida."
)


class RetornoInvalido(Exception):
    """Resposta da SEFAZ ilegível ou sem os campos esperados."""


@dataclass
class Retorno:
    cstat: str = ""
    motivo: str = ""
    protocolo: str = ""
    chave: str = ""
    recebido_em: str = ""
    prot_xml: str = ""  # <protNFe> completo, para montar o nfeProc
    extra: dict = field(default_factory=dict)

    @property
    def autorizada(self):
        return self.cstat in CSTAT_AUTORIZADA


# --- envelope SOAP ---------------------------------------------------------

def envelope_soap(servico, xml_pedido):
    wsdl, _ = OPERACOES[servico]
    ns = f"http://www.portalfiscal.inf.br/nfe/wsdl/{wsdl}"
    return (
        '<?xml version="1.0" encoding="utf-8"?>'
        f'<soap12:Envelope xmlns:soap12="{NS_SOAP}"><soap12:Body>'
        f'<nfeDadosMsg xmlns="{ns}">{xml_pedido}</nfeDadosMsg>'
        "</soap12:Body></soap12:Envelope>"
    )


def soap_action(servico):
    wsdl, operacao = OPERACOES[servico]
    return f"http://www.portalfiscal.inf.br/nfe/wsdl/{wsdl}/{operacao}"


def extrair_corpo(resposta_http):
    """Tira o envelope SOAP e devolve o elemento XML da resposta da SEFAZ."""
    try:
        raiz = etree.fromstring(resposta_http if isinstance(resposta_http, bytes)
                                else resposta_http.encode("utf-8"))
    except etree.XMLSyntaxError:
        raise RetornoInvalido("A SEFAZ devolveu uma resposta que não é XML.")
    corpo = next(iter(raiz.iter(f"{{{NS_SOAP}}}Body")), None)
    if corpo is None or len(corpo) == 0:
        raise RetornoInvalido("Resposta SOAP sem corpo.")
    resultado = corpo[0]  # <nfeResultMsg>
    return resultado[0] if len(resultado) else resultado


def _filho(el, nome):
    return el.find(f".//{{{NS_NFE}}}{nome}")


def _texto(el, nome):
    achado = _filho(el, nome) if el is not None else None
    return (achado.text or "").strip() if achado is not None else ""


# --- pedidos ---------------------------------------------------------------

def pedido_envio(nfe_xml, id_lote, sincrono=True):
    return (
        f'<enviNFe xmlns="{NS_NFE}" versao="{VERSAO}"><idLote>{int(id_lote)}</idLote>'
        f'<indSinc>{1 if sincrono else 0}</indSinc>{nfe_xml}</enviNFe>'
    )


def pedido_consulta(chave, ambiente):
    return (f'<consSitNFe xmlns="{NS_NFE}" versao="{VERSAO}"><tpAmb>{ambiente}</tpAmb>'
            f'<xServ>CONSULTAR</xServ><chNFe>{chave}</chNFe></consSitNFe>')


def pedido_status(codigo_uf, ambiente):
    return (f'<consStatServ xmlns="{NS_NFE}" versao="{VERSAO}"><tpAmb>{ambiente}</tpAmb>'
            f'<cUF>{codigo_uf}</cUF><xServ>STATUS</xServ></consStatServ>')


def _dh(momento):
    return momento.isoformat(timespec="seconds")


def pedido_cancelamento(*, chave, protocolo, justificativa, cnpj, codigo_uf, ambiente,
                        momento: datetime, certificado, id_lote=1, sequencia=1):
    """Evento 110111 (cancelamento), assinado. `justificativa` com 15+ caracteres."""
    justificativa = " ".join(justificativa.split())
    if len(justificativa) < 15:
        raise ValueError("A justificativa do cancelamento precisa de pelo menos 15 caracteres.")
    id_evento = f"ID110111{chave}{sequencia:02d}"
    evento = etree.fromstring(
        f'<evento xmlns="{NS_NFE}" versao="1.00"><infEvento Id="{id_evento}">'
        f"<cOrgao>{codigo_uf}</cOrgao><tpAmb>{ambiente}</tpAmb><CNPJ>{cnpj}</CNPJ>"
        f"<chNFe>{chave}</chNFe><dhEvento>{_dh(momento)}</dhEvento><tpEvento>110111</tpEvento>"
        f"<nSeqEvento>{sequencia}</nSeqEvento><verEvento>1.00</verEvento>"
        '<detEvento versao="1.00"><descEvento>Cancelamento</descEvento>'
        f"<nProt>{protocolo}</nProt><xJust>{_escapar(justificativa)}</xJust></detEvento>"
        "</infEvento></evento>"
    )
    assinatura.assinar(evento, certificado, tag="infEvento")
    corpo = etree.tostring(evento, encoding="UTF-8").decode("utf-8")
    return (f'<envEvento xmlns="{NS_NFE}" versao="1.00"><idLote>{int(id_lote)}</idLote>'
            f"{corpo}</envEvento>"), corpo


def pedido_cce(*, chave, texto, sequencia, cnpj, codigo_uf, ambiente, momento: datetime,
               certificado, id_lote=1):
    """Evento 110110 (Carta de Correção, só NF-e), assinado. Texto de 15 a 1000 caracteres."""
    texto = " ".join(texto.split())
    if not 15 <= len(texto) <= 1000:
        raise ValueError("O texto da correção deve ter entre 15 e 1000 caracteres.")
    if not 1 <= sequencia <= 20:
        raise ValueError("A SEFAZ aceita no máximo 20 cartas de correção por nota.")
    id_evento = f"ID110110{chave}{sequencia:02d}"
    evento = etree.fromstring(
        f'<evento xmlns="{NS_NFE}" versao="1.00"><infEvento Id="{id_evento}">'
        f"<cOrgao>{codigo_uf}</cOrgao><tpAmb>{ambiente}</tpAmb><CNPJ>{cnpj}</CNPJ>"
        f"<chNFe>{chave}</chNFe><dhEvento>{_dh(momento)}</dhEvento><tpEvento>110110</tpEvento>"
        f"<nSeqEvento>{sequencia}</nSeqEvento><verEvento>1.00</verEvento>"
        '<detEvento versao="1.00"><descEvento>Carta de Correcao</descEvento>'
        f"<xCorrecao>{_escapar(texto)}</xCorrecao><xCondUso>{CCE_COND_USO}</xCondUso></detEvento>"
        "</infEvento></evento>"
    )
    assinatura.assinar(evento, certificado, tag="infEvento")
    corpo = etree.tostring(evento, encoding="UTF-8").decode("utf-8")
    return (f'<envEvento xmlns="{NS_NFE}" versao="1.00"><idLote>{int(id_lote)}</idLote>'
            f"{corpo}</envEvento>"), corpo


def pedido_inutilizacao(*, cnpj, codigo_uf, ano2, serie, inicio, fim, justificativa,
                        ambiente, certificado):
    """inutNFe (modelo 65), assinado. Devolve (XML do pedido)."""
    justificativa = " ".join(justificativa.split())
    if len(justificativa) < 15:
        raise ValueError("A justificativa da inutilização precisa de pelo menos 15 caracteres.")
    if inicio > fim:
        raise ValueError("O número inicial não pode ser maior que o final.")
    id_inut = f"ID{codigo_uf}{ano2:02d}{cnpj}65{int(serie):03d}{int(inicio):09d}{int(fim):09d}"
    inut = etree.fromstring(
        f'<inutNFe xmlns="{NS_NFE}" versao="{VERSAO}"><infInut Id="{id_inut}">'
        f"<tpAmb>{ambiente}</tpAmb><xServ>INUTILIZAR</xServ><cUF>{codigo_uf}</cUF>"
        f"<ano>{ano2:02d}</ano><CNPJ>{cnpj}</CNPJ><mod>65</mod><serie>{int(serie)}</serie>"
        f"<nNFIni>{int(inicio)}</nNFIni><nNFFin>{int(fim)}</nNFFin>"
        f"<xJust>{_escapar(justificativa)}</xJust></infInut></inutNFe>"
    )
    assinatura.assinar(inut, certificado, tag="infInut")
    return etree.tostring(inut, encoding="UTF-8").decode("utf-8")


def _escapar(texto):
    return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# --- retornos --------------------------------------------------------------

def ler_retorno_envio(resposta_http):
    """retEnviNFe. Com envio síncrono traz o protNFe da nota."""
    ret = extrair_corpo(resposta_http)
    if ret.tag != f"{{{NS_NFE}}}retEnviNFe":
        raise RetornoInvalido("Resposta inesperada ao enviar a nota.")
    prot = _filho(ret, "protNFe")
    if prot is None:  # lote ainda em processamento (103/105) ou rejeitado no lote
        return Retorno(cstat=_texto(ret, "cStat"), motivo=_texto(ret, "xMotivo"),
                       extra={"recibo": _texto(ret, "nRec")})
    return _ler_prot(prot)


def ler_retorno_consulta(resposta_http):
    ret = extrair_corpo(resposta_http)
    if ret.tag != f"{{{NS_NFE}}}retConsSitNFe":
        raise RetornoInvalido("Resposta inesperada à consulta.")
    prot = _filho(ret, "protNFe")
    if prot is not None:
        retorno = _ler_prot(prot)
    else:
        retorno = Retorno(cstat=_texto(ret, "cStat"), motivo=_texto(ret, "xMotivo"),
                          chave=_texto(ret, "chNFe"))
    retorno.extra["situacao_consulta"] = _texto(ret, "cStat")
    # evento de cancelamento já registrado na consulta
    ev = ret.find(f".//{{{NS_NFE}}}retEvento")
    if ev is not None and _texto(ev, "tpEvento") == "110111":
        retorno.extra["cancelada"] = _texto(ev, "cStat") in CSTAT_CANCELADO
    return retorno


def ler_retorno_status(resposta_http):
    ret = extrair_corpo(resposta_http)
    if ret.tag != f"{{{NS_NFE}}}retConsStatServ":
        raise RetornoInvalido("Resposta inesperada ao consultar o serviço.")
    return Retorno(cstat=_texto(ret, "cStat"), motivo=_texto(ret, "xMotivo"),
                   recebido_em=_texto(ret, "dhRecbto"))


def ler_retorno_evento(resposta_http):
    ret = extrair_corpo(resposta_http)
    if ret.tag != f"{{{NS_NFE}}}retEnvEvento":
        raise RetornoInvalido("Resposta inesperada ao enviar o evento.")
    evento = ret.find(f".//{{{NS_NFE}}}retEvento")
    if evento is None:
        return Retorno(cstat=_texto(ret, "cStat"), motivo=_texto(ret, "xMotivo"))
    return Retorno(cstat=_texto(evento, "cStat"), motivo=_texto(evento, "xMotivo"),
                   protocolo=_texto(evento, "nProt"), chave=_texto(evento, "chNFe"),
                   recebido_em=_texto(evento, "dhRegEvento"),
                   prot_xml=etree.tostring(evento, encoding="unicode"))


def ler_retorno_inutilizacao(resposta_http):
    ret = extrair_corpo(resposta_http)
    if ret.tag != f"{{{NS_NFE}}}retInutNFe":
        raise RetornoInvalido("Resposta inesperada à inutilização.")
    return Retorno(cstat=_texto(ret, "cStat"), motivo=_texto(ret, "xMotivo"),
                   protocolo=_texto(ret, "nProt"), recebido_em=_texto(ret, "dhRecbto"),
                   prot_xml=etree.tostring(ret, encoding="unicode"))


def _ler_prot(prot):
    return Retorno(
        cstat=_texto(prot, "cStat"), motivo=_texto(prot, "xMotivo"),
        protocolo=_texto(prot, "nProt"), chave=_texto(prot, "chNFe"),
        recebido_em=_texto(prot, "dhRecbto"),
        prot_xml=etree.tostring(prot, encoding="unicode"),
    )


def montar_nfe_proc(nfe_xml, prot_xml):
    """XML de distribuição (nfeProc): a NFe assinada + o protocolo de autorização."""
    nfe = etree.fromstring(nfe_xml.encode("utf-8"))
    prot = etree.fromstring(prot_xml.encode("utf-8"))
    proc = etree.Element(f"{{{NS_NFE}}}nfeProc", nsmap={None: NS_NFE})
    proc.set("versao", VERSAO)
    proc.append(nfe)
    proc.append(prot)
    return etree.tostring(proc, encoding="UTF-8").decode("utf-8")
