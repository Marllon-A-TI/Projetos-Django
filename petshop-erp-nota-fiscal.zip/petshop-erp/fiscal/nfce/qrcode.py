"""QR-Code versão 2.00 da NFC-e emitida ONLINE (manual do DANFE NFC-e)."""

import hashlib


def url_qrcode(*, url_base, chave, ambiente, id_csc, csc):
    """
    p = chave|2|tpAmb|idCSC|hash, hash = SHA-1(chave|2|tpAmb|idCSC + CSC) em
    hexadecimal maiúsculo. O idCSC vai SEM zeros à esquerda.
    """
    id_csc = str(int(id_csc))
    parametros = f"{chave}|2|{ambiente}|{id_csc}"
    codigo = hashlib.sha1((parametros + csc).encode("utf-8")).hexdigest().upper()
    return f"{url_base}?p={parametros}|{codigo}"


def url_qrcode_offline(*, url_base, chave, ambiente, dia, valor, digest_base64, id_csc, csc):
    """
    QR-Code v2.00 de contingência OFFLINE: chave|2|tpAmb|dia|vNF|digVal|idCSC|hash.
    digVal = hexadecimal do DigestValue (texto base64) da assinatura.
    CONFIRMAR com um autorizador em homologação: o manual da SEFAZ não detalha
    a caixa (minúscula/maiúscula) do digVal; usa-se minúscula.
    """
    digval = digest_base64.encode("ascii").hex()
    parametros = f"{chave}|2|{ambiente}|{int(dia):02d}|{valor}|{digval}|{int(id_csc)}"
    codigo = hashlib.sha1((parametros + csc).encode("utf-8")).hexdigest().upper()
    return f"{url_base}?p={parametros}|{codigo}"
