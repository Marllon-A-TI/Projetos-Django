"""
Endereços do QR-Code e da consulta por chave, por UF e ambiente.

ATENÇÃO: confirme em <https://nfce.encat.org/desenvolvedor/qrcode/> antes de
produção. Podem ser trocados no .env (FISCAL_QRCODE_URL / FISCAL_URL_CHAVE)
sem alterar o código.
"""

QRCODE = {
    "RJ": {
        "1": "http://www4.fazenda.rj.gov.br/consultaNFCe/QRCode",
        "2": "http://www4.fazenda.rj.gov.br/consultaNFCe/QRCode",
    },
}
URL_CHAVE = {
    "RJ": {
        "1": "www.fazenda.rj.gov.br/nfce/consulta",
        "2": "www.fazenda.rj.gov.br/nfce/consulta",
    },
}


def obter(tabela, uf, ambiente, sobrescrita=""):
    if sobrescrita:
        return sobrescrita
    try:
        return tabela[uf][ambiente]
    except KeyError:
        raise LookupError(
            f"Endereço da NFC-e para {uf} não cadastrado. Defina no .env "
            "(FISCAL_QRCODE_URL e FISCAL_URL_CHAVE)."
        )


# --- Web services (NFC-e, layout 4.00) ---------------------------------------
# SVRS conferido no portal <https://dfe-portal.svrs.rs.gov.br/Nfce/Servicos>.
# RJ: autorização pela SVRS confirmada em HOMOLOGAÇÃO por fonte de terceiros;
# produção assumida igual. Confirme com o contador/SEFAZ-RJ. Qualquer endereço
# pode ser trocado no .env com FISCAL_URL_<SERVICO> (ex.: FISCAL_URL_AUTORIZACAO).

_SVRS_PROD = "https://nfce.svrs.rs.gov.br/ws"
_SVRS_HOMO = "https://nfce-homologacao.svrs.rs.gov.br/ws"
_CAMINHOS = {
    "autorizacao": "/NfeAutorizacao/NFeAutorizacao4.asmx",
    "retautorizacao": "/NfeRetAutorizacao/NFeRetAutorizacao4.asmx",
    "consulta": "/NfeConsulta/NfeConsulta4.asmx",
    "status": "/NfeStatusServico/NfeStatusServico4.asmx",
    "inutilizacao": "/nfeinutilizacao/nfeinutilizacao4.asmx",
    "evento": "/recepcaoevento/recepcaoevento4.asmx",
}
WEBSERVICES = {
    "SVRS": {
        "1": {nome: _SVRS_PROD + caminho for nome, caminho in _CAMINHOS.items()},
        "2": {nome: _SVRS_HOMO + caminho for nome, caminho in _CAMINHOS.items()},
    },
}
AUTORIZADOR = {"RJ": "SVRS"}

# Serviço -> (nome do WSDL, operação) para o cabeçalho SOAPAction
OPERACOES = {
    "autorizacao": ("NFeAutorizacao4", "nfeAutorizacaoLote"),
    "retautorizacao": ("NFeRetAutorizacao4", "nfeRetAutorizacaoLote"),
    "consulta": ("NFeConsultaProtocolo4", "nfeConsultaNF"),
    "status": ("NFeStatusServico4", "nfeStatusServicoNF"),
    "inutilizacao": ("NFeInutilizacao4", "nfeInutilizacaoNF"),
    "evento": ("RecepcaoEvento4", "nfeRecepcaoEvento"),
}


# NF-e (modelo 55): mesmo conjunto de serviços, hosts nfe.svrs / nfe-homologacao.svrs.
# RJ na SVRS para NF-e: confirmado apenas por fonte de terceiros (não oficial);
# confirme no portal da SEFAZ. Troque no .env com FISCAL_URL_NFE_<SERVICO>.
_SVRS_NFE_PROD = "https://nfe.svrs.rs.gov.br/ws"
_SVRS_NFE_HOMO = "https://nfe-homologacao.svrs.rs.gov.br/ws"
WEBSERVICES_NFE = {
    "SVRS": {
        "1": {nome: _SVRS_NFE_PROD + caminho for nome, caminho in _CAMINHOS.items()},
        "2": {nome: _SVRS_NFE_HOMO + caminho for nome, caminho in _CAMINHOS.items()},
    },
}


def url_servico(uf, ambiente, servico, sobrescritas=None, modelo="65"):
    """URL do web service; `sobrescritas` = {servico: url} vindas do .env."""
    if sobrescritas and sobrescritas.get(servico):
        return sobrescritas[servico]
    tabela = WEBSERVICES_NFE if modelo == "55" else WEBSERVICES
    try:
        return tabela[AUTORIZADOR[uf]][ambiente][servico]
    except KeyError:
        nome = "NF-e" if modelo == "55" else "NFC-e"
        var = f"FISCAL_URL_{'NFE_' if modelo == '55' else ''}{servico.upper()}"
        raise LookupError(f"Autorizador da {nome} para {uf} não cadastrado. Defina {var} no .env.")
