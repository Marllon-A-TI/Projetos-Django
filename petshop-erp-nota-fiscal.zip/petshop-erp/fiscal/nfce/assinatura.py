"""
Assinatura digital XMLDSig da NF-e/NFC-e: enveloped, C14N 1.0, RSA-SHA1 e
digest SHA-1 (é o que o leiaute exige). Sem Django.
"""

import base64
import hashlib

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from lxml import etree

from .xml import NS_NFE

NS_DS = "http://www.w3.org/2000/09/xmldsig#"
C14N = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315"
ALG_ASSINATURA = "http://www.w3.org/2000/09/xmldsig#rsa-sha1"
ALG_DIGEST = "http://www.w3.org/2000/09/xmldsig#sha1"
ALG_ENVELOPED = "http://www.w3.org/2000/09/xmldsig#enveloped-signature"


def _c14n(elemento):
    return etree.tostring(elemento, method="c14n", exclusive=False, with_comments=False)


def _ds(pai, nome, **atributos):
    elemento = etree.SubElement(pai, f"{{{NS_DS}}}{nome}")
    for chave, valor in atributos.items():
        elemento.set(chave, valor)
    return elemento


def assinar(nfe, certificado, tag="infNFe"):
    """
    Insere <Signature> na raiz (NFe, evento ou inutNFe) referenciando o filho
    `tag` (infNFe, infEvento, infInut). Modifica e devolve a própria raiz.
    """
    inf = nfe.find(f"{{{NS_NFE}}}{tag}")
    identificador = inf.get("Id")
    digest = base64.b64encode(hashlib.sha1(_c14n(inf)).digest()).decode()

    assinatura = etree.SubElement(nfe, f"{{{NS_DS}}}Signature", nsmap={None: NS_DS})
    info = _ds(assinatura, "SignedInfo")
    _ds(info, "CanonicalizationMethod", Algorithm=C14N)
    _ds(info, "SignatureMethod", Algorithm=ALG_ASSINATURA)
    referencia = _ds(info, "Reference", URI=f"#{identificador}")
    transformacoes = _ds(referencia, "Transforms")
    _ds(transformacoes, "Transform", Algorithm=ALG_ENVELOPED)
    _ds(transformacoes, "Transform", Algorithm=C14N)
    _ds(referencia, "DigestMethod", Algorithm=ALG_DIGEST)
    _ds(referencia, "DigestValue").text = digest

    valor = certificado.chave_privada.sign(
        _c14n(info), padding.PKCS1v15(), hashes.SHA1()
    )
    _ds(assinatura, "SignatureValue").text = base64.b64encode(valor).decode()
    x509 = _ds(_ds(assinatura, "KeyInfo"), "X509Data")
    der = certificado.certificado.public_bytes(serialization.Encoding.DER)
    _ds(x509, "X509Certificate").text = base64.b64encode(der).decode()
    return nfe


def digest_value(xml_texto):
    """DigestValue (base64) da assinatura de um XML já assinado."""
    raiz = etree.fromstring(xml_texto.encode("utf-8"))
    return raiz.find(f".//{{{NS_DS}}}DigestValue").text


def verificar(xml_texto, tag="infNFe"):
    """
    Confere digest e assinatura de um XML já serializado. Devolve True/False.
    Independente da função de assinar (reparseia o texto).
    """
    from cryptography import x509

    raiz = etree.fromstring(xml_texto.encode("utf-8"))
    inf = next(iter(raiz.iter(f"{{{NS_NFE}}}{tag}")), None)  # também dentro de nfeProc
    if inf is None:
        return False
    assinatura = inf.getparent().find(f"{{{NS_DS}}}Signature")
    if assinatura is None:
        return False
    info = assinatura.find(f"{{{NS_DS}}}SignedInfo")
    digest_xml = info.find(f".//{{{NS_DS}}}DigestValue").text
    if base64.b64encode(hashlib.sha1(_c14n(inf)).digest()).decode() != digest_xml:
        return False
    cert_der = base64.b64decode(assinatura.find(f".//{{{NS_DS}}}X509Certificate").text)
    chave_publica = x509.load_der_x509_certificate(cert_der).public_key()
    valor = base64.b64decode(assinatura.find(f"{{{NS_DS}}}SignatureValue").text)
    try:
        chave_publica.verify(valor, _c14n(info), padding.PKCS1v15(), hashes.SHA1())
    except Exception:
        return False
    return True
