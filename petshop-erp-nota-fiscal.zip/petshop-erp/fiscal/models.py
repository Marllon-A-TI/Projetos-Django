"""
Empresa emitente (multiempresa desde o início).

Segredos NÃO ficam no banco: o arquivo do certificado A1 (.pfx), a senha
dele e o código CSC ficam só no computador da loja, referenciados no .env.
"""

from django.db import models
from django.db.models import Q

from django.conf import settings

from core.models import ModeloBase, ModeloImutavel, ModeloProtegido

from .validators import validar_cnpj, validar_documento

UFS = [
    (uf, uf)
    for uf in (
        "AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO"
    ).split()
]


class Empresa(ModeloBase, ModeloProtegido):
    class Regime(models.TextChoices):  # CRT da NF-e
        SIMPLES = "1", "Simples Nacional"
        SIMPLES_EXCESSO = "2", "Simples Nacional (excesso de sublimite)"
        NORMAL = "3", "Regime normal (Lucro Presumido/Real)"
        MEI = "4", "MEI"

    class Ambiente(models.TextChoices):
        HOMOLOGACAO = "HOMOLOGACAO", "Homologação (testes, sem valor fiscal)"
        PRODUCAO = "PRODUCAO", "Produção (valor fiscal)"

    class Provedor(models.TextChoices):
        NENHUM = "NENHUM", "Nenhum (ainda não configurado)"
        SEFAZ = "SEFAZ", "Direto na SEFAZ (gratuito)"

    razao_social = models.CharField("razão social", max_length=150)
    nome_fantasia = models.CharField("nome fantasia", max_length=100, blank=True)
    cnpj = models.CharField(
        "CNPJ", max_length=14, unique=True, validators=[validar_cnpj],
        help_text="Só os 14 caracteres, sem pontuação.",
    )
    inscricao_estadual = models.CharField(
        "inscrição estadual", max_length=20, blank=True,
        help_text="Obrigatória para NFC-e/NF-e de mercadorias.",
    )
    inscricao_municipal = models.CharField("inscrição municipal", max_length=20, blank=True)
    regime = models.CharField("regime tributário", max_length=1, choices=Regime.choices,
                              default=Regime.SIMPLES)

    logradouro = models.CharField("logradouro", max_length=100)
    numero = models.CharField("número", max_length=10)
    complemento = models.CharField("complemento", max_length=60, blank=True)
    bairro = models.CharField("bairro", max_length=60)
    municipio = models.CharField("município", max_length=60)
    codigo_municipio_ibge = models.CharField(
        "código do município (IBGE)", max_length=7,
        help_text="7 dígitos, ex.: Itaboraí-RJ = 3301900.",
    )
    uf = models.CharField("UF", max_length=2, choices=UFS)
    cep = models.CharField("CEP", max_length=8)
    telefone = models.CharField("telefone", max_length=20, blank=True)
    email = models.EmailField("e-mail", blank=True)

    ambiente = models.CharField("ambiente", max_length=12, choices=Ambiente.choices,
                                default=Ambiente.HOMOLOGACAO)
    provedor = models.CharField("forma de emissão", max_length=10, choices=Provedor.choices,
                                default=Provedor.SEFAZ)
    serie_nfce = models.PositiveSmallIntegerField("série da NFC-e", default=1)
    serie_nfe = models.PositiveSmallIntegerField("série da NF-e (modelo 55)", default=1)
    csc_id = models.CharField(
        "ID do CSC (NFC-e)", max_length=6, blank=True,
        help_text="Só o identificador (ex.: 000001). O código CSC vai no .env.",
    )
    certificado_validade = models.DateField(
        "validade do certificado A1", null=True, blank=True,
        help_text="Opcional: a validade real é lida do arquivo do certificado.",
    )

    ativo = models.BooleanField("ativa", default=True)
    padrao = models.BooleanField("empresa padrão", default=False)

    class Meta:
        verbose_name = "empresa"
        verbose_name_plural = "empresas"
        ordering = ["razao_social"]
        constraints = [
            models.UniqueConstraint(
                fields=["padrao"], condition=Q(padrao=True), name="empresa_uma_padrao"
            ),
        ]

    def __str__(self):
        return self.nome_fantasia or self.razao_social

    @property
    def cnpj_formatado(self):
        c = self.cnpj
        if len(c) != 14:
            return c
        return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"


class ProdutoFiscal(ModeloBase):
    """Dados fiscais do produto (o cadastro de produtos não é alterado)."""

    class Csosn(models.TextChoices):
        C102 = "102", "102 - Tributada sem permissão de crédito"
        C103 = "103", "103 - Isenta de ICMS (faixa de receita bruta)"
        C300 = "300", "300 - Imune"
        C400 = "400", "400 - Não tributada pelo Simples Nacional"
        C500 = "500", "500 - ICMS cobrado antes por ST ou antecipação"
        C900 = "900", "900 - Outros"

    produto = models.OneToOneField(
        "produtos.Produto", on_delete=models.CASCADE, related_name="fiscal",
        verbose_name="produto",
    )
    ncm = models.CharField("NCM", max_length=8, help_text="8 dígitos. Pergunte ao seu contador.")
    cest = models.CharField("CEST", max_length=7, blank=True, help_text="Só se o produto tiver.")
    cfop = models.CharField("CFOP", max_length=4, default="5102",
                            help_text="5102 = venda de mercadoria adquirida de terceiros; 5405 = com ST.")
    unidade = models.CharField("unidade", max_length=6, default="UN")
    origem = models.CharField(
        "origem", max_length=1, default="0",
        choices=[("0", "0 - Nacional"), ("1", "1 - Estrangeira (importação direta)"),
                 ("2", "2 - Estrangeira (mercado interno)")],
    )
    csosn = models.CharField("CSOSN", max_length=3, choices=Csosn.choices, default=Csosn.C102)

    class Meta:
        verbose_name = "dados fiscais do produto"
        verbose_name_plural = "dados fiscais dos produtos"

    def __str__(self):
        return f"Dados fiscais de {self.produto}"


class SequenciaNumeracao(ModeloBase):
    """Último número usado por empresa, modelo, série e ambiente (sem repetir)."""

    empresa = models.ForeignKey(Empresa, on_delete=models.PROTECT, related_name="sequencias")
    modelo = models.CharField(max_length=2)
    serie = models.PositiveSmallIntegerField()
    ambiente = models.CharField(max_length=1)
    ultimo_numero = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "sequência de numeração"
        verbose_name_plural = "sequências de numeração"
        constraints = [
            models.UniqueConstraint(
                fields=["empresa", "modelo", "serie", "ambiente"], name="sequencia_unica"
            ),
        ]


class Cliente(ModeloBase, ModeloProtegido):
    """Destinatário de NF-e (modelo 55). Não é usado na NFC-e nem nas vendas comuns."""

    class IndIE(models.TextChoices):
        NAO_CONTRIBUINTE = "9", "Não contribuinte (sem inscrição estadual)"
        CONTRIBUINTE = "1", "Contribuinte do ICMS (tem inscrição estadual)"
        ISENTO = "2", "Contribuinte isento de inscrição"

    nome = models.CharField("nome / razão social", max_length=60)
    documento = models.CharField(
        "CPF ou CNPJ", max_length=14, unique=True, validators=[validar_documento],
        help_text="Só os números (CPF 11, CNPJ 14).",
    )
    ind_ie = models.CharField("indicador de IE", max_length=1, choices=IndIE.choices,
                              default=IndIE.NAO_CONTRIBUINTE)
    inscricao_estadual = models.CharField("inscrição estadual", max_length=14, blank=True)
    email = models.EmailField("e-mail", blank=True)
    telefone = models.CharField("telefone", max_length=20, blank=True)
    logradouro = models.CharField("logradouro", max_length=60)
    numero = models.CharField("número", max_length=10)
    complemento = models.CharField("complemento", max_length=60, blank=True)
    bairro = models.CharField("bairro", max_length=60)
    municipio = models.CharField("município", max_length=60)
    codigo_municipio_ibge = models.CharField("código do município (IBGE)", max_length=7)
    uf = models.CharField("UF", max_length=2, choices=UFS)
    cep = models.CharField("CEP", max_length=8)
    ativo = models.BooleanField("ativo", default=True)

    class Meta:
        verbose_name = "cliente (destinatário)"
        verbose_name_plural = "clientes (destinatários)"
        ordering = ["nome", "id"]

    def __str__(self):
        return f"{self.nome} ({self.documento_formatado})"

    @property
    def documento_formatado(self):
        d = self.documento
        if len(d) == 11:
            return f"{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}"
        return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"


class DocumentoFiscal(ModeloBase, ModeloProtegido):
    class Modelo(models.TextChoices):
        NFCE = "65", "NFC-e"
        NFE = "55", "NF-e"

    class Status(models.TextChoices):
        ASSINADA = "ASSINADA", "Assinada (aguardando envio)"
        AUTORIZADA = "AUTORIZADA", "Autorizada"
        REJEITADA = "REJEITADA", "Rejeitada"
        CANCELADA = "CANCELADA", "Cancelada"
        DENEGADA = "DENEGADA", "Denegada"

    empresa = models.ForeignKey(Empresa, on_delete=models.PROTECT, related_name="documentos")
    venda = models.ForeignKey("vendas.Venda", on_delete=models.PROTECT,
                              related_name="documentos_fiscais")
    cliente = models.ForeignKey("fiscal.Cliente", on_delete=models.PROTECT, null=True, blank=True,
                                related_name="documentos", verbose_name="destinatário (NF-e)")
    modelo = models.CharField("modelo", max_length=2, choices=Modelo.choices, default=Modelo.NFCE)
    serie = models.PositiveSmallIntegerField("série")
    numero = models.PositiveIntegerField("número")
    ambiente = models.CharField("ambiente", max_length=1)  # 1 produção, 2 homologação
    tp_emis = models.PositiveSmallIntegerField("tipo de emissão", default=1)
    chave = models.CharField("chave de acesso", max_length=44, unique=True)
    status = models.CharField("situação", max_length=12, choices=Status.choices,
                              default=Status.ASSINADA)
    valor_total = models.DecimalField("valor total", max_digits=12, decimal_places=2)
    emitido_em = models.DateTimeField("emitido em")
    xml_assinado = models.TextField("XML assinado")
    xml_autorizado = models.TextField("XML autorizado (com protocolo)", blank=True, default="")
    protocolo = models.CharField("protocolo", max_length=20, blank=True, default="")
    motivo = models.TextField("motivo/retorno da SEFAZ", blank=True, default="")
    qrcode_url = models.TextField("URL do QR-Code", blank=True, default="")
    xml_cancelamento = models.TextField("XML do evento de cancelamento", blank=True, default="")
    protocolo_cancelamento = models.CharField("protocolo do cancelamento", max_length=20,
                                              blank=True, default="")
    justificativa = models.TextField("justificativa (cancelamento/contingência)", blank=True, default="")

    class Meta:
        verbose_name = "documento fiscal"
        verbose_name_plural = "documentos fiscais"
        ordering = ["-emitido_em", "-id"]
        indexes = [models.Index(fields=["status"], name="docfiscal_status_idx")]
        constraints = [
            models.UniqueConstraint(fields=["venda", "modelo"], name="docfiscal_venda_modelo_unico"),
            models.UniqueConstraint(
                fields=["empresa", "modelo", "serie", "numero", "ambiente"],
                name="docfiscal_numero_unico",
            ),
            models.CheckConstraint(condition=Q(valor_total__gte=0), name="docfiscal_valor_nao_negativo"),
        ]

    def __str__(self):
        return f"{self.get_modelo_display()} {self.serie}/{self.numero}"

    @property
    def homologacao(self):
        return self.ambiente == "2"


class EventoFiscal(ModeloImutavel):
    """Trilha de rastreabilidade do documento (nunca alterada nem excluída)."""

    class Tipo(models.TextChoices):
        GERACAO = "GERACAO", "XML gerado"
        ASSINATURA = "ASSINATURA", "XML assinado"
        ENVIO = "ENVIO", "Enviado à SEFAZ"
        AUTORIZACAO = "AUTORIZACAO", "Autorizado"
        REJEICAO = "REJEICAO", "Rejeitado"
        CANCELAMENTO = "CANCELAMENTO", "Cancelado"
        CONSULTA = "CONSULTA", "Consulta"
        CONTINGENCIA = "CONTINGENCIA", "Contingência"
        REGERACAO = "REGERACAO", "XML regerado"
        ERRO = "ERRO", "Erro"
        CCE = "CCE", "Carta de correção"

    documento = models.ForeignKey(DocumentoFiscal, on_delete=models.PROTECT, related_name="eventos")
    tipo = models.CharField("tipo", max_length=14, choices=Tipo.choices)
    descricao = models.TextField("descrição", blank=True, default="")
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True,
                                blank=True, related_name="eventos_fiscais")
    criado_em = models.DateTimeField("data", auto_now_add=True)

    class Meta:
        verbose_name = "evento fiscal"
        verbose_name_plural = "eventos fiscais"
        ordering = ["criado_em", "id"]


class Inutilizacao(ModeloImutavel):
    """Pedido de inutilização de numeração (NFC-e). Guarda cada tentativa e o retorno."""

    empresa = models.ForeignKey(Empresa, on_delete=models.PROTECT, related_name="inutilizacoes")
    modelo = models.CharField(max_length=2, default="65")
    serie = models.PositiveSmallIntegerField("série")
    ambiente = models.CharField("ambiente", max_length=1)
    numero_inicial = models.PositiveIntegerField("número inicial")
    numero_final = models.PositiveIntegerField("número final")
    justificativa = models.TextField("justificativa")
    aceita = models.BooleanField("aceita pela SEFAZ", default=False)
    cstat = models.CharField("código de retorno", max_length=4, blank=True, default="")
    motivo = models.TextField("retorno", blank=True, default="")
    protocolo = models.CharField("protocolo", max_length=20, blank=True, default="")
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
                                related_name="inutilizacoes")
    criado_em = models.DateTimeField("data", auto_now_add=True)

    class Meta:
        verbose_name = "inutilização"
        verbose_name_plural = "inutilizações"
        ordering = ["-criado_em", "-id"]
        constraints = [
            models.CheckConstraint(
                condition=Q(numero_final__gte=models.F("numero_inicial")),
                name="inutilizacao_faixa_valida",
            ),
        ]

    def __str__(self):
        return f"Inutilização {self.serie}/{self.numero_inicial}-{self.numero_final}"


class CartaCorrecao(ModeloImutavel):
    """Carta de Correção Eletrônica (CC-e) de uma NF-e autorizada. Guarda cada tentativa."""

    documento = models.ForeignKey(DocumentoFiscal, on_delete=models.PROTECT, related_name="cartas")
    sequencia = models.PositiveSmallIntegerField("sequência", help_text="1 a 20 por nota.")
    texto = models.TextField("texto da correção")
    aceita = models.BooleanField("aceita pela SEFAZ", default=False)
    cstat = models.CharField("código de retorno", max_length=4, blank=True, default="")
    motivo = models.TextField("retorno", blank=True, default="")
    protocolo = models.CharField("protocolo", max_length=20, blank=True, default="")
    xml_evento = models.TextField("XML do evento", blank=True, default="")
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
                                related_name="cartas_correcao")
    criado_em = models.DateTimeField("data", auto_now_add=True)

    class Meta:
        verbose_name = "carta de correção"
        verbose_name_plural = "cartas de correção"
        ordering = ["documento_id", "sequencia", "id"]
        constraints = [
            models.UniqueConstraint(fields=["documento", "sequencia"], condition=Q(aceita=True),
                                    name="cce_sequencia_aceita_unica"),
        ]

    def __str__(self):
        return f"CC-e {self.sequencia} de {self.documento}"
