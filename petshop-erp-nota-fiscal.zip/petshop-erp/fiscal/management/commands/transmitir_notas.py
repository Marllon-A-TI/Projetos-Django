"""
Reenvia à SEFAZ as notas pendentes (contingência ou falha de rede).

Uso:  python manage.py transmitir_notas             (uma vez)
      python manage.py transmitir_notas --continuo  (repete a cada 60 s, para o Agendador de Tarefas)
"""

import time

from django.core.management.base import BaseCommand

from fiscal import services


class Command(BaseCommand):
    help = "Transmite à SEFAZ as NFC-e assinadas que ainda não foram enviadas."

    def add_arguments(self, parser):
        parser.add_argument("--continuo", action="store_true", help="repete a cada --intervalo segundos")
        parser.add_argument("--intervalo", type=int, default=60)

    def handle(self, *args, **opcoes):
        while True:
            enviadas, falhas = services.transmitir_pendentes()
            if enviadas or falhas:
                self.stdout.write(f"Enviadas: {enviadas} | com falha: {falhas}")
            if not opcoes["continuo"]:
                break
            time.sleep(max(10, opcoes["intervalo"]))
