"""
Serviços fiscais sem dependência de tela.

Emissão 100% gratuita: o XML é montado, assinado e (na próxima etapa)
transmitido direto à SEFAZ, com o certificado A1 que fica no computador da
loja. Nada secreto vai para o banco: caminho/senha do .pfx e o CSC vêm do .env.
"""

import secrets
from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal

from decouple import config
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import (
    CartaCorrecao, Cliente, DocumentoFiscal, Empresa, EventoFiscal, Inutilizacao, SequenciaNumeracao,
)
from .nfce import assinatura, enderecos, qrcode, sefaz
from .nfce import xml as nfce_xml
from .nfce.canal import CanalErro, CanalSefaz
from .nfce.certificado import CertificadoErro, carregar_certificado
from .nfce.chave import CODIGO_UF, gerar_chave

DIAS_ALERTA_CERTIFICADO = 30
MODELO_NFCE = "65"
MODELO_NFE = "55"
IDADE_MAXIMA_NORMAL = timedelta(minutes=4)  # NFC-e normal vencida é rejeitada; regera antes de enviar
JUSTIFICATIVA_CONTINGENCIA = "Sem comunicacao com a SEFAZ no momento da emissao"


def _env(nome):
    """Lê do .env/ambiente. Isolado numa função para os testes poderem trocar."""
    return config(nome, default="") or ""


def _ambiente_codigo(empresa):
    return "1" if empresa.ambiente == Empresa.Ambiente.PRODUCAO else "2"


def configuracao_certificado(empresa):
    """(caminho do .pfx, senha): variável da empresa primeiro, depois a geral."""
    cnpj = empresa.cnpj
    caminho = _env(f"FISCAL_CERT_{cnpj}_PFX") or _env("FISCAL_CERT_PFX")
    senha = _env(f"FISCAL_CERT_{cnpj}_SENHA") or _env("FISCAL_CERT_SENHA")
    return caminho, senha


def csc_da_empresa(empresa):
    """Código CSC do ambiente da empresa (só no .env)."""
    amb = empresa.ambiente
    return _env(f"FISCAL_CSC_{empresa.cnpj}_{amb}") or _env(f"FISCAL_CSC_{amb}")


def carregar_certificado_da_empresa(empresa):
    caminho, senha = configuracao_certificado(empresa)
    return carregar_certificado(caminho, senha)


def empresa_padrao():
    """Empresa emitente padrão (ativa), ou None."""
    return Empresa.objects.filter(ativo=True, padrao=True).first()


@dataclass
class Pendencia:
    nivel: str  # "erro" bloqueia a emissão; "aviso" não bloqueia
    texto: str


def diagnostico(empresa, hoje=None, modelo=MODELO_NFCE):
    """Lista de pendências para emitir NFC-e (ou NF-e, modelo 55) com esta empresa."""
    hoje = hoje or timezone.localdate()
    itens = []

    def erro(texto):
        itens.append(Pendencia("erro", texto))

    def aviso(texto):
        itens.append(Pendencia("aviso", texto))

    if not empresa.ativo:
        erro("A empresa está inativa.")
    if empresa.provedor == Empresa.Provedor.NENHUM:
        erro("Escolha a forma de emissão (Direto na SEFAZ).")
    if not empresa.inscricao_estadual.strip():
        erro("Informe a inscrição estadual (use ISENTO se a empresa for isenta).")
    if len(empresa.codigo_municipio_ibge) != 7 or not empresa.codigo_municipio_ibge.isdigit():
        erro("Código IBGE do município deve ter 7 dígitos.")
    if len(empresa.cep) != 8 or not empresa.cep.isdigit():
        erro("CEP deve ter 8 dígitos.")
    if empresa.regime != Empresa.Regime.SIMPLES:
        aviso(
            "Este emissor foi montado para Simples Nacional (CSOSN). Para outro regime, "
            "confirme com seu contador antes de emitir."
        )
    if modelo == MODELO_NFCE:
        if not empresa.csc_id.strip():
            erro("Informe o ID do CSC da NFC-e (gerado no portal da SEFAZ).")
        if not csc_da_empresa(empresa):
            erro(f"Código CSC ausente: defina FISCAL_CSC_{empresa.ambiente} no arquivo .env.")
        try:
            enderecos.obter(
                enderecos.QRCODE, empresa.uf, _ambiente_codigo(empresa),
                getattr(settings, "FISCAL_QRCODE_URL", ""),
            )
        except LookupError as exc:
            erro(str(exc))
        else:
            aviso("Confirme os endereços do QR-Code em nfce.encat.org/desenvolvedor/qrcode antes de produção.")

    try:
        certificado = carregar_certificado_da_empresa(empresa)
    except CertificadoErro as exc:
        erro(f"Certificado A1: {exc}")
    else:
        if certificado.validade < hoje:
            erro(f"Certificado A1 vencido em {certificado.validade:%d/%m/%Y}.")
        elif certificado.validade <= hoje + timedelta(days=DIAS_ALERTA_CERTIFICADO):
            aviso(f"Certificado A1 vence em {certificado.validade:%d/%m/%Y}: renove com antecedência.")
        if certificado.cnpj and certificado.cnpj != empresa.cnpj:
            erro(f"O certificado é do CNPJ {certificado.cnpj}, diferente do da empresa.")
        elif not certificado.cnpj:
            aviso("Não encontrei o CNPJ no nome do certificado; confira se é o da empresa.")

    if empresa.ambiente == Empresa.Ambiente.PRODUCAO:
        aviso("Ambiente de PRODUÇÃO: as notas emitidas têm valor fiscal.")
    return itens


def pronta_para_emitir(empresa, hoje=None):
    return not any(p.nivel == "erro" for p in diagnostico(empresa, hoje))


def proximo_numero(empresa, modelo, serie, ambiente):
    """Próximo número da sequência, sem repetir (trava a linha). Use dentro de atomic."""
    with transaction.atomic():
        sequencia, _ = SequenciaNumeracao.objects.get_or_create(
            empresa=empresa, modelo=modelo, serie=serie, ambiente=ambiente
        )
        sequencia = SequenciaNumeracao.objects.select_for_update().get(pk=sequencia.pk)
        sequencia.ultimo_numero += 1
        sequencia.save()
        return sequencia.ultimo_numero


def _registrar_evento(documento, tipo, descricao="", usuario=None):
    return EventoFiscal.objects.create(
        documento=documento, tipo=tipo, descricao=descricao, usuario=usuario
    )


def _emitente(empresa):
    return nfce_xml.Emitente(
        cnpj=empresa.cnpj, razao_social=empresa.razao_social,
        nome_fantasia=empresa.nome_fantasia, inscricao_estadual=empresa.inscricao_estadual,
        regime=empresa.regime, logradouro=empresa.logradouro, numero=empresa.numero,
        complemento=empresa.complemento, bairro=empresa.bairro,
        codigo_municipio=empresa.codigo_municipio_ibge, municipio=empresa.municipio,
        uf=empresa.uf, cep=empresa.cep, telefone=empresa.telefone,
    )


def _itens_da_venda(venda):
    """Itens no formato do XML; recusa se algum produto não tem dados fiscais."""
    itens, faltando = [], []
    for item in venda.itens.select_related("produto").order_by("id"):
        fiscal = getattr(item.produto, "fiscal", None)
        if fiscal is None or len(fiscal.ncm) != 8:
            faltando.append(item.produto.nome)
            continue
        itens.append(
            nfce_xml.Item(
                codigo=str(item.produto_id), gtin=item.produto.codigo_barras or "",
                descricao=item.produto.nome, ncm=fiscal.ncm, cest=fiscal.cest,
                cfop=fiscal.cfop,
                unidade="KG" if item.produto.pesavel and fiscal.unidade == "UN" else fiscal.unidade,
                quantidade=Decimal(item.quantidade), valor_unitario=item.preco,
                origem=fiscal.origem, csosn=fiscal.csosn,
            )
        )
    if faltando:
        raise ValidationError(
            "Faltam dados fiscais (NCM) em: " + ", ".join(sorted(set(faltando))) + "."
        )
    return itens


def _pagamentos_da_venda(venda, permitir_sem_pagamento=False):
    """(pagamentos do XML, troco). Dinheiro vai com o troco somado (vPag)."""
    from pdv.models import CODIGO_FISCAL_PAGAMENTO

    pagamentos = list(venda.pagamentos.all())
    if not pagamentos:
        if permitir_sem_pagamento:  # NF-e: tPag 90 (sem pagamento), vPag 0,00
            return [nfce_xml.Pagamento("90", Decimal("0.00"))], Decimal("0.00")
        raise ValidationError("A venda não tem pagamento registrado (venda feita fora do PDV).")
    info = getattr(venda, "caixa_info", None)
    troco = info.troco if info else Decimal("0.00")
    saida = []
    for p in pagamentos:
        valor = p.valor + (troco if p.forma == "DINHEIRO" else Decimal("0.00"))
        saida.append(nfce_xml.Pagamento(CODIGO_FISCAL_PAGAMENTO[p.forma], valor))
    return saida, troco


def _montar_e_assinar(*, empresa, itens, pagamentos, troco, numero, codigo_numerico,
                     emissao, tp_emis, justificativa, certificado):
    """Chave + XML assinado + URL do QR-Code (online ou de contingência)."""
    ambiente = _ambiente_codigo(empresa)
    qr_base = enderecos.obter(
        enderecos.QRCODE, empresa.uf, ambiente, getattr(settings, "FISCAL_QRCODE_URL", "")
    )
    url_chave = enderecos.obter(
        enderecos.URL_CHAVE, empresa.uf, ambiente, getattr(settings, "FISCAL_URL_CHAVE", "")
    )
    chave = gerar_chave(
        uf=empresa.uf, emissao=emissao, cnpj=empresa.cnpj, modelo=MODELO_NFCE,
        serie=empresa.serie_nfce, numero=numero, tp_emis=tp_emis, codigo_numerico=codigo_numerico,
    )
    csc = csc_da_empresa(empresa)
    online = tp_emis == 1
    url_qr = (
        qrcode.url_qrcode(url_base=qr_base, chave=chave, ambiente=ambiente,
                          id_csc=empresa.csc_id, csc=csc)
        if online else ""
    )
    nota = nfce_xml.Nfce(
        emitente=_emitente(empresa), itens=itens, pagamentos=pagamentos, troco=troco,
        serie=empresa.serie_nfce, numero=numero, codigo_numerico=codigo_numerico, chave=chave,
        ambiente=ambiente, emissao=emissao, codigo_uf=CODIGO_UF[empresa.uf], tp_emis=tp_emis,
        dh_contingencia=emissao if not online else None, just_contingencia=justificativa,
        url_qrcode=url_qr, url_chave=url_chave,
    )
    try:
        elemento = nfce_xml.montar_nfce(nota)
    except ValueError as exc:
        raise ValidationError(str(exc))
    assinatura.assinar(elemento, certificado)
    if not online:  # o QR-Code de contingência usa o digest da assinatura
        total = sum((nfce_xml.valor_item(i) for i in itens), Decimal("0.00"))
        url_qr = qrcode.url_qrcode_offline(
            url_base=qr_base, chave=chave, ambiente=ambiente, dia=emissao.day,
            valor=f"{total:.2f}", digest_base64=assinatura.digest_value(nfce_xml.serializar(elemento)),
            id_csc=empresa.csc_id, csc=csc,
        )
        nfce_xml.inserir_suplemento(elemento, url_qr, url_chave)
    xml_assinado = nfce_xml.serializar(elemento)
    if not assinatura.verificar(xml_assinado):  # defesa: nunca gravar assinatura inválida
        raise ValidationError("A assinatura gerada não passou na verificação.")
    return chave, xml_assinado, url_qr


def _preparar_empresa(modelo=MODELO_NFCE):
    empresa = empresa_padrao()
    if empresa is None:
        raise ValidationError("Cadastre e defina a empresa padrão em Fiscal.")
    erros = [p.texto for p in diagnostico(empresa, modelo=modelo) if p.nivel == "erro"]
    if erros:
        raise ValidationError(erros)
    return empresa


def gerar_nfce(*, venda, usuario, contingencia=False, justificativa=""):
    """
    Gera e ASSINA a NFC-e da venda (não transmite). Com `contingencia=True` gera
    em contingência offline (tpEmis=9) para transmitir quando a SEFAZ voltar.
    Tudo ou nada: se algo falhar, nem o número da sequência é consumido.
    """
    empresa = _preparar_empresa()
    if DocumentoFiscal.objects.filter(venda=venda, modelo=MODELO_NFCE).exists():
        raise ValidationError("Esta venda já tem NFC-e gerada.")
    justificativa = " ".join((justificativa or JUSTIFICATIVA_CONTINGENCIA).split())

    itens = _itens_da_venda(venda)
    pagamentos, troco = _pagamentos_da_venda(venda)
    certificado = carregar_certificado_da_empresa(empresa)
    ambiente = _ambiente_codigo(empresa)
    tp_emis = 9 if contingencia else 1

    with transaction.atomic():
        numero = proximo_numero(empresa, MODELO_NFCE, empresa.serie_nfce, ambiente)
        emissao = timezone.localtime()
        codigo_numerico = secrets.randbelow(10**8)
        if codigo_numerico == numero:
            codigo_numerico += 1
        chave, xml_assinado, url_qr = _montar_e_assinar(
            empresa=empresa, itens=itens, pagamentos=pagamentos, troco=troco, numero=numero,
            codigo_numerico=codigo_numerico, emissao=emissao, tp_emis=tp_emis,
            justificativa=justificativa, certificado=certificado,
        )
        documento = DocumentoFiscal.objects.create(
            empresa=empresa, venda=venda, modelo=MODELO_NFCE, serie=empresa.serie_nfce,
            numero=numero, ambiente=ambiente, tp_emis=tp_emis, chave=chave,
            status=DocumentoFiscal.Status.ASSINADA, valor_total=venda.valor_total,
            emitido_em=emissao, xml_assinado=xml_assinado, qrcode_url=url_qr,
            justificativa=justificativa if contingencia else "",
        )
        _registrar_evento(documento, EventoFiscal.Tipo.GERACAO,
                          f"NFC-e {documento.serie}/{numero} da venda #{venda.pk}", usuario)
        if contingencia:
            _registrar_evento(documento, EventoFiscal.Tipo.CONTINGENCIA,
                              f"Emitida em contingência offline: {justificativa}", usuario)
        _registrar_evento(documento, EventoFiscal.Tipo.ASSINATURA,
                          f"Assinado com o certificado de {certificado.titular}", usuario)
    return documento


def regerar_nfce(*, documento, usuario):
    """
    Refaz o XML de uma nota REJEITADA ou vencida (sem protocolo) mantendo o MESMO
    número, com data/hora nova. Use depois de corrigir o dado que causou a rejeição.
    """
    if documento.status not in (DocumentoFiscal.Status.REJEITADA, DocumentoFiscal.Status.ASSINADA):
        raise ValidationError("Só dá para regerar nota assinada (não enviada) ou rejeitada.")
    empresa = documento.empresa
    nfe55 = documento.modelo == MODELO_NFE
    erros = [p.texto for p in diagnostico(empresa, modelo=documento.modelo) if p.nivel == "erro"]
    if erros:
        raise ValidationError(erros)
    certificado = carregar_certificado_da_empresa(empresa)
    itens = _itens_da_venda(documento.venda)
    pagamentos, troco = _pagamentos_da_venda(documento.venda, permitir_sem_pagamento=nfe55)
    with transaction.atomic():
        documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        if documento.status == DocumentoFiscal.Status.AUTORIZADA:
            raise ValidationError("A nota já foi autorizada.")
        emissao = timezone.localtime()
        contingencia = documento.tp_emis == 9
        if nfe55:
            chave, xml_assinado = _montar_nfe_e_assinar(
                empresa=empresa, cliente=documento.cliente, itens=itens, pagamentos=pagamentos,
                troco=troco, numero=documento.numero, codigo_numerico=int(documento.chave[35:43]),
                emissao=emissao, certificado=certificado,
            )
            url_qr = ""
        else:
            chave, xml_assinado, url_qr = _montar_e_assinar(
                empresa=empresa, itens=itens, pagamentos=pagamentos, troco=troco,
                numero=documento.numero, codigo_numerico=int(documento.chave[35:43]),
                emissao=emissao, tp_emis=documento.tp_emis,
                justificativa=documento.justificativa or JUSTIFICATIVA_CONTINGENCIA,
                certificado=certificado,
            )
        antiga = documento.chave
        documento.chave, documento.xml_assinado, documento.qrcode_url = chave, xml_assinado, url_qr
        documento.emitido_em, documento.status, documento.motivo = (
            emissao, DocumentoFiscal.Status.ASSINADA, "")
        documento.save()
        _registrar_evento(documento, EventoFiscal.Tipo.REGERACAO,
                          f"XML regerado (chave anterior {antiga})"
                          + (" em contingência" if contingencia else ""), usuario)
    return documento


# --- comunicação com a SEFAZ ---------------------------------------------------

def _criar_canal(empresa):
    certificado = carregar_certificado_da_empresa(empresa)
    return CanalSefaz(certificado, ca_bundle=_env("FISCAL_CA_BUNDLE"))


def _url(empresa, servico, modelo=MODELO_NFCE):
    prefixo = "FISCAL_URL_NFE_" if modelo == MODELO_NFE else "FISCAL_URL_"
    sobrescritas = {servico: _env(f"{prefixo}{servico.upper()}")}
    return enderecos.url_servico(empresa.uf, _ambiente_codigo(empresa), servico, sobrescritas, modelo)


def _chamar(empresa, servico, xml_pedido, canal=None, modelo=MODELO_NFCE):
    canal = canal or _criar_canal(empresa)
    return canal.enviar(_url(empresa, servico, modelo), servico, xml_pedido)


def status_servico(empresa=None, canal=None, modelo=MODELO_NFCE):
    """Consulta o status do serviço da SEFAZ. Levanta CanalErro se sem comunicação."""
    empresa = empresa or empresa_padrao()
    resposta = _chamar(
        empresa, "status",
        sefaz.pedido_status(CODIGO_UF[empresa.uf], _ambiente_codigo(empresa)), canal, modelo,
    )
    return sefaz.ler_retorno_status(resposta)


def _autorizar(documento, retorno, usuario):
    documento.status = DocumentoFiscal.Status.AUTORIZADA
    documento.protocolo = retorno.protocolo
    documento.motivo = f"{retorno.cstat} - {retorno.motivo}"
    documento.xml_autorizado = sefaz.montar_nfe_proc(documento.xml_assinado, retorno.prot_xml)
    documento.save()
    _registrar_evento(documento, EventoFiscal.Tipo.AUTORIZACAO,
                      f"Autorizada (protocolo {retorno.protocolo}): {retorno.motivo}", usuario)


def transmitir(*, documento, usuario=None, canal=None):
    """
    Envia a nota à SEFAZ (envio síncrono). Falha de rede deixa a nota como está
    (ASSINADA) para nova tentativa; rejeição marca REJEITADA com o motivo.
    """
    erro = None
    with transaction.atomic():
        documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        if documento.status != DocumentoFiscal.Status.ASSINADA:
            raise ValidationError(f"Nota {documento.get_status_display().lower()}: não pode ser enviada.")
        if (documento.modelo == MODELO_NFCE and documento.tp_emis == 1
                and timezone.now() - documento.emitido_em > IDADE_MAXIMA_NORMAL):
            documento = regerar_nfce(documento=documento, usuario=usuario)
            documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        empresa = documento.empresa
        _registrar_evento(documento, EventoFiscal.Tipo.ENVIO,
                          f"Enviando à SEFAZ ({_ambiente_codigo(empresa)})", usuario)
        try:
            resposta = _chamar(
                empresa, "autorizacao",
                sefaz.pedido_envio(documento.xml_assinado, id_lote=documento.pk), canal,
                documento.modelo,
            )
            retorno = sefaz.ler_retorno_envio(resposta)
        except (CanalErro, CertificadoErro, sefaz.RetornoInvalido) as exc:
            erro = str(exc)
            _registrar_evento(documento, EventoFiscal.Tipo.ERRO, erro, usuario)
        else:
            if retorno.autorizada:
                _autorizar(documento, retorno, usuario)
            elif retorno.cstat in sefaz.CSTAT_JA_AUTORIZADA | {"103", "105"}:
                # duplicidade ou lote em processamento: a consulta recupera o protocolo
                erro = _consultar_dentro(documento, usuario, canal)
            else:
                documento.status = DocumentoFiscal.Status.REJEITADA
                documento.motivo = f"{retorno.cstat} - {retorno.motivo}"
                documento.save()
                _registrar_evento(documento, EventoFiscal.Tipo.REJEICAO, documento.motivo, usuario)
    if erro:
        raise ValidationError(erro)
    return documento


def _consultar_dentro(documento, usuario, canal=None):
    """Consulta a chave e atualiza o documento. Devolve mensagem de erro ou None."""
    try:
        resposta = _chamar(
            documento.empresa, "consulta",
            sefaz.pedido_consulta(documento.chave, _ambiente_codigo(documento.empresa)), canal,
            documento.modelo,
        )
        retorno = sefaz.ler_retorno_consulta(resposta)
    except (CanalErro, CertificadoErro, sefaz.RetornoInvalido) as exc:
        _registrar_evento(documento, EventoFiscal.Tipo.ERRO, f"Consulta falhou: {exc}", usuario)
        return str(exc)
    _registrar_evento(documento, EventoFiscal.Tipo.CONSULTA,
                      f"{retorno.cstat} - {retorno.motivo}", usuario)
    if retorno.extra.get("cancelada"):
        documento.status = DocumentoFiscal.Status.CANCELADA
        documento.save()
    elif retorno.autorizada and documento.status != DocumentoFiscal.Status.AUTORIZADA:
        _autorizar(documento, retorno, usuario)
    return None


def consultar(*, documento, usuario=None, canal=None):
    with transaction.atomic():
        documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        erro = _consultar_dentro(documento, usuario, canal)
    if erro:
        raise ValidationError(erro)
    return documento


def cancelar(*, documento, justificativa, usuario, canal=None):
    """Cancela (evento 110111) uma nota AUTORIZADA. A SEFAZ decide se o prazo permite."""
    erro = None
    with transaction.atomic():
        documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        if documento.status != DocumentoFiscal.Status.AUTORIZADA:
            raise ValidationError("Só é possível cancelar nota autorizada.")
        empresa = documento.empresa
        try:
            certificado = carregar_certificado_da_empresa(empresa)
            pedido, evento_xml = sefaz.pedido_cancelamento(
                chave=documento.chave, protocolo=documento.protocolo,
                justificativa=justificativa, cnpj=empresa.cnpj, codigo_uf=CODIGO_UF[empresa.uf],
                ambiente=_ambiente_codigo(empresa), momento=timezone.localtime(),
                certificado=certificado, id_lote=documento.pk,
            )
        except ValueError as exc:
            raise ValidationError(str(exc))
        except CertificadoErro as exc:
            raise ValidationError(f"Certificado A1: {exc}")
        try:
            retorno = sefaz.ler_retorno_evento(
                _chamar(empresa, "evento", pedido, canal, documento.modelo))
        except (CanalErro, sefaz.RetornoInvalido) as exc:
            erro = str(exc)
            _registrar_evento(documento, EventoFiscal.Tipo.ERRO, f"Cancelamento: {erro}", usuario)
        else:
            if retorno.cstat in sefaz.CSTAT_CANCELADO:
                documento.status = DocumentoFiscal.Status.CANCELADA
                documento.protocolo_cancelamento = retorno.protocolo
                documento.xml_cancelamento = evento_xml
                documento.save()
                _registrar_evento(documento, EventoFiscal.Tipo.CANCELAMENTO,
                                  f"Cancelada (protocolo {retorno.protocolo}): "
                                  f"{' '.join(justificativa.split())}", usuario)
            else:
                erro = f"A SEFAZ não aceitou o cancelamento: {retorno.cstat} - {retorno.motivo}"
                _registrar_evento(documento, EventoFiscal.Tipo.REJEICAO, erro, usuario)
    if erro:
        raise ValidationError(erro)
    return documento


def inutilizar(*, empresa, serie, inicio, fim, justificativa, usuario, canal=None):
    """Inutiliza uma faixa de números não usados. Guarda o resultado (aceito ou não)."""
    certificado = carregar_certificado_da_empresa(empresa)
    ambiente = _ambiente_codigo(empresa)
    try:
        pedido = sefaz.pedido_inutilizacao(
            cnpj=empresa.cnpj, codigo_uf=CODIGO_UF[empresa.uf], ano2=timezone.localdate().year % 100,
            serie=serie, inicio=inicio, fim=fim, justificativa=justificativa,
            ambiente=ambiente, certificado=certificado,
        )
    except ValueError as exc:
        raise ValidationError(str(exc))
    if DocumentoFiscal.objects.filter(
        empresa=empresa, modelo=MODELO_NFCE, serie=serie, ambiente=ambiente,
        numero__gte=inicio, numero__lte=fim,
    ).exists():
        raise ValidationError("Há nota gerada nessa faixa: só se inutiliza número que não foi usado.")
    try:
        retorno = sefaz.ler_retorno_inutilizacao(_chamar(empresa, "inutilizacao", pedido, canal))
    except (CanalErro, sefaz.RetornoInvalido) as exc:
        raise ValidationError(str(exc))
    return Inutilizacao.objects.create(
        empresa=empresa, serie=serie, ambiente=ambiente, numero_inicial=inicio,
        numero_final=fim, justificativa=" ".join(justificativa.split()),
        aceita=retorno.cstat in sefaz.CSTAT_INUTILIZADO, cstat=retorno.cstat,
        motivo=retorno.motivo, protocolo=retorno.protocolo, usuario=usuario,
    )


def emitir_nfce(*, venda, usuario, canal=None):
    """
    Fluxo do PDV: com a SEFAZ no ar, gera e transmite; sem comunicação, emite em
    contingência offline. Devolve (documento, aviso).
    """
    empresa = _preparar_empresa()
    try:
        online = status_servico(empresa, canal).cstat in sefaz.CSTAT_SERVICO_OK
    except (CanalErro, CertificadoErro, sefaz.RetornoInvalido):
        online = False

    if not online:
        documento = gerar_nfce(venda=venda, usuario=usuario, contingencia=True)
        return documento, "SEFAZ indisponível: nota emitida em CONTINGÊNCIA; será enviada quando voltar."
    documento = gerar_nfce(venda=venda, usuario=usuario)
    try:
        documento = transmitir(documento=documento, usuario=usuario, canal=canal)
    except ValidationError as erro:
        documento.refresh_from_db()
        return documento, " ".join(erro.messages)
    if documento.status == DocumentoFiscal.Status.REJEITADA:
        return documento, f"Nota rejeitada pela SEFAZ: {documento.motivo}"
    return documento, ""


def transmitir_pendentes(*, limite=20, canal=None):
    """Reenvia notas ASSINADAS (contingência ou falha de rede). Devolve (enviadas, falhas)."""
    enviadas = falhas = 0
    pendentes = DocumentoFiscal.objects.filter(
        status=DocumentoFiscal.Status.ASSINADA
    ).order_by("id")[:limite]
    for documento in pendentes:
        try:
            transmitir(documento=documento, canal=canal)
            enviadas += 1
        except ValidationError:
            falhas += 1
    return enviadas, falhas


# --- NF-e (modelo 55) -----------------------------------------------------------

def _destinatario(cliente):
    return nfce_xml.Destinatario(
        documento=cliente.documento, nome=cliente.nome, logradouro=cliente.logradouro,
        numero=cliente.numero, complemento=cliente.complemento, bairro=cliente.bairro,
        codigo_municipio=cliente.codigo_municipio_ibge, municipio=cliente.municipio, uf=cliente.uf,
        cep=cliente.cep, ind_ie=cliente.ind_ie, inscricao_estadual=cliente.inscricao_estadual,
        email=cliente.email, telefone=cliente.telefone,
    )


def _validar_cliente_nfe(empresa, cliente):
    erros = []
    if not cliente.ativo:
        erros.append("O cliente está inativo.")
    if cliente.uf != empresa.uf:
        erros.append(
            f"Operação interestadual ({empresa.uf} → {cliente.uf}) ainda não é suportada: "
            "exige CFOP 6xxx e regras de ICMS próprias. Peça ao contador."
        )
    if len(cliente.codigo_municipio_ibge) != 7 or not cliente.codigo_municipio_ibge.isdigit():
        erros.append("Código IBGE do município do cliente deve ter 7 dígitos.")
    if len(cliente.cep) != 8 or not cliente.cep.isdigit():
        erros.append("CEP do cliente deve ter 8 dígitos.")
    if cliente.ind_ie == Cliente.IndIE.CONTRIBUINTE and not cliente.inscricao_estadual.strip():
        erros.append("Cliente contribuinte precisa da inscrição estadual.")
    if erros:
        raise ValidationError(erros)


def _montar_nfe_e_assinar(*, empresa, cliente, itens, pagamentos, troco, numero, codigo_numerico,
                          emissao, certificado):
    """Chave + XML assinado da NF-e (modelo 55, emissão normal)."""
    ambiente = _ambiente_codigo(empresa)
    chave = gerar_chave(
        uf=empresa.uf, emissao=emissao, cnpj=empresa.cnpj, modelo=MODELO_NFE,
        serie=empresa.serie_nfe, numero=numero, tp_emis=1, codigo_numerico=codigo_numerico,
    )
    nota = nfce_xml.Nfce(
        emitente=_emitente(empresa), itens=itens, pagamentos=pagamentos, troco=troco,
        serie=empresa.serie_nfe, numero=numero, codigo_numerico=codigo_numerico, chave=chave,
        ambiente=ambiente, emissao=emissao, codigo_uf=CODIGO_UF[empresa.uf], tp_emis=1,
        modelo=MODELO_NFE, destinatario=_destinatario(cliente),
    )
    try:
        elemento = nfce_xml.montar_nfce(nota)
    except ValueError as exc:
        raise ValidationError(str(exc))
    assinatura.assinar(elemento, certificado)
    xml_assinado = nfce_xml.serializar(elemento)
    if not assinatura.verificar(xml_assinado):
        raise ValidationError("A assinatura gerada não passou na verificação.")
    return chave, xml_assinado


def gerar_nfe(*, venda, cliente, usuario):
    """Gera e ASSINA a NF-e (modelo 55) da venda para o cliente; não transmite."""
    empresa = _preparar_empresa(MODELO_NFE)
    if DocumentoFiscal.objects.filter(venda=venda, modelo=MODELO_NFE).exists():
        raise ValidationError("Esta venda já tem NF-e gerada.")
    _validar_cliente_nfe(empresa, cliente)
    itens = _itens_da_venda(venda)
    pagamentos, troco = _pagamentos_da_venda(venda, permitir_sem_pagamento=True)
    certificado = carregar_certificado_da_empresa(empresa)
    ambiente = _ambiente_codigo(empresa)

    with transaction.atomic():
        numero = proximo_numero(empresa, MODELO_NFE, empresa.serie_nfe, ambiente)
        emissao = timezone.localtime()
        codigo_numerico = secrets.randbelow(10**8)
        if codigo_numerico == numero:
            codigo_numerico += 1
        chave, xml_assinado = _montar_nfe_e_assinar(
            empresa=empresa, cliente=cliente, itens=itens, pagamentos=pagamentos, troco=troco,
            numero=numero, codigo_numerico=codigo_numerico, emissao=emissao, certificado=certificado,
        )
        documento = DocumentoFiscal.objects.create(
            empresa=empresa, venda=venda, cliente=cliente, modelo=MODELO_NFE,
            serie=empresa.serie_nfe, numero=numero, ambiente=ambiente, tp_emis=1, chave=chave,
            status=DocumentoFiscal.Status.ASSINADA, valor_total=venda.valor_total,
            emitido_em=emissao, xml_assinado=xml_assinado,
        )
        _registrar_evento(documento, EventoFiscal.Tipo.GERACAO,
                          f"NF-e {documento.serie}/{numero} da venda #{venda.pk} para {cliente.nome}", usuario)
        _registrar_evento(documento, EventoFiscal.Tipo.ASSINATURA,
                          f"Assinado com o certificado de {certificado.titular}", usuario)
    return documento


def emitir_nfe(*, venda, cliente, usuario, canal=None):
    """
    Gera e transmite a NF-e. Sem a SEFAZ no ar não emite (a NF-e não tem contingência
    offline aqui): nada é gravado e o usuário tenta de novo depois. Devolve (documento, aviso).
    """
    empresa = _preparar_empresa(MODELO_NFE)
    _validar_cliente_nfe(empresa, cliente)
    try:
        online = status_servico(empresa, canal, MODELO_NFE).cstat in sefaz.CSTAT_SERVICO_OK
    except (CanalErro, CertificadoErro, sefaz.RetornoInvalido):
        online = False
    if not online:
        raise ValidationError("SEFAZ indisponível agora: a NF-e não foi gerada. Tente novamente mais tarde.")
    documento = gerar_nfe(venda=venda, cliente=cliente, usuario=usuario)
    try:
        documento = transmitir(documento=documento, usuario=usuario, canal=canal)
    except ValidationError as erro:
        documento.refresh_from_db()
        return documento, " ".join(erro.messages)
    if documento.status == DocumentoFiscal.Status.REJEITADA:
        return documento, f"NF-e rejeitada pela SEFAZ: {documento.motivo}"
    return documento, ""


def corrigir(*, documento, texto, usuario, canal=None):
    """Carta de Correção (evento 110110) de uma NF-e AUTORIZADA. Devolve a CartaCorrecao."""
    erro = None
    with transaction.atomic():
        documento = DocumentoFiscal.objects.select_for_update().get(pk=documento.pk)
        if documento.modelo != MODELO_NFE:
            raise ValidationError("Carta de correção existe só para NF-e (a NFC-e não tem).")
        if documento.status != DocumentoFiscal.Status.AUTORIZADA:
            raise ValidationError("Só é possível corrigir nota autorizada.")
        sequencia = documento.cartas.filter(aceita=True).count() + 1
        empresa = documento.empresa
        try:
            certificado = carregar_certificado_da_empresa(empresa)
            pedido, evento_xml = sefaz.pedido_cce(
                chave=documento.chave, texto=texto, sequencia=sequencia, cnpj=empresa.cnpj,
                codigo_uf=CODIGO_UF[empresa.uf], ambiente=_ambiente_codigo(empresa),
                momento=timezone.localtime(), certificado=certificado,
                id_lote=documento.pk * 100 + sequencia,
            )
        except ValueError as exc:
            raise ValidationError(str(exc))
        except CertificadoErro as exc:
            raise ValidationError(f"Certificado A1: {exc}")
        try:
            retorno = sefaz.ler_retorno_evento(
                _chamar(empresa, "evento", pedido, canal, documento.modelo))
        except (CanalErro, sefaz.RetornoInvalido) as exc:
            _registrar_evento(documento, EventoFiscal.Tipo.ERRO, f"Carta de correção: {exc}", usuario)
            raise ValidationError(str(exc))
        aceita = retorno.cstat in sefaz.CSTAT_CCE_REGISTRADA
        carta = CartaCorrecao.objects.create(
            documento=documento, sequencia=sequencia, texto=" ".join(texto.split()), aceita=aceita,
            cstat=retorno.cstat, motivo=retorno.motivo, protocolo=retorno.protocolo,
            xml_evento=evento_xml, usuario=usuario,
        )
        _registrar_evento(
            documento, EventoFiscal.Tipo.CCE if aceita else EventoFiscal.Tipo.REJEICAO,
            f"Carta de correção {sequencia}: {retorno.cstat} - {retorno.motivo}", usuario)
    return carta
