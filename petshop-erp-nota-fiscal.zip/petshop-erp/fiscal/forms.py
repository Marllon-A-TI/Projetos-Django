from django import forms
from django.db import transaction

from core.forms import BootstrapFormMixin, DateInput

from .models import Cliente, Empresa, ProdutoFiscal
from .validators import limpar_cnpj, validar_cnpj, validar_documento


def _digitos(valor):
    return "".join(c for c in (valor or "") if c.isdigit())


class EmpresaForm(BootstrapFormMixin, forms.ModelForm):
    # Aceitam pontuação na digitação; o clean_* devolve só os caracteres úteis
    # (por isso o max_length do formulário é maior que o da coluna).
    cnpj = forms.CharField(
        label="CNPJ", max_length=18, help_text="Pode digitar com pontuação."
    )
    cep = forms.CharField(label="CEP", max_length=9)

    class Meta:
        model = Empresa
        fields = [
            "razao_social", "nome_fantasia", "cnpj", "inscricao_estadual",
            "inscricao_municipal", "regime",
            "logradouro", "numero", "complemento", "bairro", "municipio",
            "codigo_municipio_ibge", "uf", "cep", "telefone", "email",
            "ambiente", "provedor", "serie_nfce", "serie_nfe", "csc_id", "certificado_validade",
            "ativo", "padrao",
        ]
        widgets = {
            "certificado_validade": DateInput(),
            "razao_social": forms.TextInput(attrs={"autofocus": True}),
        }

    def clean_cnpj(self):
        cnpj = limpar_cnpj(self.cleaned_data.get("cnpj"))
        validar_cnpj(cnpj)
        return cnpj

    def clean_cep(self):
        cep = _digitos(self.cleaned_data.get("cep"))
        if len(cep) != 8:
            raise forms.ValidationError("CEP deve ter 8 dígitos.")
        return cep

    def clean_codigo_municipio_ibge(self):
        codigo = _digitos(self.cleaned_data.get("codigo_municipio_ibge"))
        if len(codigo) != 7:
            raise forms.ValidationError("O código do município (IBGE) tem 7 dígitos.")
        return codigo

    def clean_csc_id(self):
        return (self.cleaned_data.get("csc_id") or "").strip()

    def save(self, commit=True):
        empresa = super().save(commit=False)
        if not commit:
            return empresa
        with transaction.atomic():
            outras = Empresa.objects.exclude(pk=empresa.pk)
            if empresa.padrao:
                outras.filter(padrao=True).update(padrao=False)
            elif not outras.filter(padrao=True, ativo=True).exists():
                empresa.padrao = True  # sempre existe uma empresa padrão
            empresa.save()
        return empresa


class ProdutoFiscalForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = ProdutoFiscal
        fields = ["ncm", "cest", "cfop", "unidade", "origem", "csosn"]

    def clean_ncm(self):
        ncm = _digitos(self.cleaned_data.get("ncm"))
        if len(ncm) != 8:
            raise forms.ValidationError("O NCM tem 8 dígitos.")
        return ncm

    def clean_cest(self):
        cest = _digitos(self.cleaned_data.get("cest"))
        if cest and len(cest) != 7:
            raise forms.ValidationError("O CEST tem 7 dígitos.")
        return cest

    def clean_cfop(self):
        cfop = _digitos(self.cleaned_data.get("cfop"))
        if len(cfop) != 4 or cfop[0] != "5":
            raise forms.ValidationError("CFOP de venda dentro do estado começa com 5 (4 dígitos).")
        return cfop

    def clean_unidade(self):
        return (self.cleaned_data.get("unidade") or "").strip().upper()


class InutilizacaoForm(BootstrapFormMixin, forms.Form):
    serie = forms.IntegerField(label="Série", min_value=1, initial=1)
    inicio = forms.IntegerField(label="Número inicial", min_value=1)
    fim = forms.IntegerField(label="Número final", min_value=1)
    justificativa = forms.CharField(label="Justificativa (15+ caracteres)", min_length=15, max_length=255)

    def clean(self):
        dados = super().clean()
        if dados.get("inicio") and dados.get("fim") and dados["inicio"] > dados["fim"]:
            raise forms.ValidationError("O número inicial não pode ser maior que o final.")
        return dados


class ClienteForm(BootstrapFormMixin, forms.ModelForm):
    documento = forms.CharField(label="CPF ou CNPJ", max_length=18, help_text="Pode digitar com pontuação.")
    cep = forms.CharField(label="CEP", max_length=9)

    class Meta:
        model = Cliente
        fields = [
            "nome", "documento", "ind_ie", "inscricao_estadual", "email", "telefone",
            "logradouro", "numero", "complemento", "bairro", "municipio", "codigo_municipio_ibge",
            "uf", "cep", "ativo",
        ]
        widgets = {"nome": forms.TextInput(attrs={"autofocus": True})}

    def clean_documento(self):
        documento = limpar_cnpj(self.cleaned_data.get("documento"))
        validar_documento(documento)
        return documento

    def clean_cep(self):
        cep = _digitos(self.cleaned_data.get("cep"))
        if len(cep) != 8:
            raise forms.ValidationError("CEP deve ter 8 dígitos.")
        return cep

    def clean_codigo_municipio_ibge(self):
        codigo = _digitos(self.cleaned_data.get("codigo_municipio_ibge"))
        if len(codigo) != 7:
            raise forms.ValidationError("O código do município (IBGE) tem 7 dígitos.")
        return codigo

    def clean_inscricao_estadual(self):
        return _digitos(self.cleaned_data.get("inscricao_estadual"))

    def clean(self):
        dados = super().clean()
        if dados.get("ind_ie") == Cliente.IndIE.CONTRIBUINTE and not dados.get("inscricao_estadual"):
            self.add_error("inscricao_estadual", "Contribuinte precisa da inscrição estadual.")
        if dados.get("ind_ie") != Cliente.IndIE.CONTRIBUINTE:
            dados["inscricao_estadual"] = ""
        if len(dados.get("documento") or "") == 11 and dados.get("ind_ie") == Cliente.IndIE.CONTRIBUINTE:
            pass  # produtor rural PF com IE é permitido
        return dados


class NfeEmitirForm(BootstrapFormMixin, forms.Form):
    cliente = forms.ModelChoiceField(queryset=Cliente.objects.none(), label="Destinatário")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["cliente"].queryset = Cliente.objects.filter(ativo=True)


class CartaCorrecaoForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(
        label="Texto da correção", min_length=15, max_length=1000,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="15 a 1000 caracteres. Não vale para valores, impostos, quantidade, destinatário ou datas.",
    )
