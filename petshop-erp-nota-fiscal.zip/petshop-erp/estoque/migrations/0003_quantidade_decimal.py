import core.fields
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('estoque', '0002_movimentacaoestoque_delete_estoque_and_more'),
        ('produtos', '0003_pesavel_quantidade_decimal'),
    ]

    operations = [
        migrations.AlterField(
            model_name='movimentacaoestoque',
            name='quantidade',
            field=core.fields.QuantidadeField(decimal_places=3, help_text='Unidades (ou kg) movimentadas. No AJUSTE, é o novo estoque contado.', max_digits=12, verbose_name='quantidade'),
        ),
        migrations.AlterField(
            model_name='movimentacaoestoque',
            name='quantidade_anterior',
            field=core.fields.QuantidadeField(decimal_places=3, max_digits=12, verbose_name='quantidade anterior'),
        ),
        migrations.AlterField(
            model_name='movimentacaoestoque',
            name='quantidade_nova',
            field=core.fields.QuantidadeField(decimal_places=3, max_digits=12, verbose_name='quantidade nova'),
        ),
        migrations.AddConstraint(
            model_name='movimentacaoestoque',
            constraint=models.CheckConstraint(condition=models.Q(('quantidade__gte', 0), ('quantidade_anterior__gte', 0), ('quantidade_nova__gte', 0)), name='mov_estoque_valores_nao_negativos'),
        ),
    ]
