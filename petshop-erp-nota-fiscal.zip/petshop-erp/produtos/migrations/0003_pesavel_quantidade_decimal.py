import core.fields
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('produtos', '0002_alter_produto_categoria_alter_produto_options_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='produto',
            name='pesavel',
            field=models.BooleanField(default=False, help_text='Marque para produtos vendidos por quilo (aceita fração, ex.: 0,745 kg).', verbose_name='vendido por peso'),
        ),
        migrations.AlterField(
            model_name='produto',
            name='quantidade',
            field=core.fields.QuantidadeField(blank=True, decimal_places=3, default=0, help_text='Somente leitura: altere apenas por movimentação de estoque.', max_digits=12, null=True, verbose_name='quantidade em estoque'),
        ),
        migrations.AddConstraint(
            model_name='produto',
            constraint=models.CheckConstraint(condition=models.Q(('quantidade__isnull', True), ('quantidade__gte', 0), _connector='OR'), name='produto_quantidade_nao_negativa'),
        ),
    ]
