import core.fields
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('vendas', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='itemvenda',
            name='quantidade',
            field=core.fields.QuantidadeField(decimal_places=3, max_digits=12, verbose_name='quantidade'),
        ),
    ]
