"""
Produtos vendidos por peso (kg): quantidade fracionada, arredondamento por item,
etiqueta de balança. Rodar:  python manage.py test vendas.test_pesaveis
"""

from decimal import Decimal

from django.contrib.auth.models import Group, User
from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from accounts.models import GRUPO_ADMINISTRADOR, GRUPO_VENDEDOR
from core.fields import QuantidadeField
from core.utils import ler_quantidade, valor_item
from estoque.forms import MovimentacaoEstoqueForm
from estoque.models import MovimentacaoEstoque
from fiscal import services as fiscal_services
from fiscal.models import ProdutoFiscal
from pdv import balanca, services as pdv_services
from pdv.models import FormaPagamento
from produtos.models import Produto
from vendas.forms import ItemVendaForm
from vendas.models import Venda

D = Decimal


class CampoEUtilTests(SimpleTestCase):
    def test_campo_devolve_inteiro_quando_inteiro_e_decimal_quando_fracionado(self):
        campo = QuantidadeField()
        self.assertEqual(campo.from_db_value(D("2.000"), None, None), 2)
        self.assertIsInstance(campo.from_db_value(D("2.000"), None, None), int)
        self.assertEqual(campo.from_db_value(D("0.745"), None, None), D("0.745"))
        self.assertEqual(campo.from_db_value(D("10.500"), None, None), D("10.5"))
        self.assertIsNone(campo.from_db_value(None, None, None))

    def test_ler_quantidade(self):
        self.assertEqual(ler_quantidade("0,745", pesavel=True), D("0.745"))
        self.assertEqual(ler_quantidade(3), D("3"))
        for ruim in ("abc", "0.7451", "NaN", "Infinity"):
            with self.assertRaises(ValueError):
                ler_quantidade(ruim, pesavel=True)
        with self.assertRaises(ValueError):
            ler_quantidade("1.5", pesavel=False)

    def test_valor_item_arredonda_meio_para_cima(self):
        self.assertEqual(valor_item(D("0.745"), D("39.90")), D("29.73"))  # 29,7255
        self.assertEqual(valor_item(D("0.125"), D("1.00")), D("0.13"))    # 0,125 -> 0,13


class BalancaTests(SimpleTestCase):
    def etiqueta(self, codigo="000123", valor="01250", prefixo="2"):
        doze = prefixo + codigo + valor
        return doze + str(balanca.dv_ean13(doze))

    def test_etiqueta_de_peso(self):
        cod = self.etiqueta()
        self.assertEqual(balanca.interpretar(cod), ("000123", 1250))
        self.assertEqual(balanca.quantidade_da_etiqueta(1250, balanca.FormatoBalanca()), D("1.250"))

    def test_etiqueta_de_preco_calcula_o_peso(self):
        formato = balanca.FormatoBalanca(modo="PRECO")
        self.assertEqual(balanca.quantidade_da_etiqueta(2990, formato, D("39.90")), D("0.749"))
        with self.assertRaises(ValueError):
            balanca.quantidade_da_etiqueta(2990, formato, None)

    def test_codigos_que_nao_sao_de_balanca(self):
        self.assertIsNone(balanca.interpretar("7891234567895"))   # prefixo 7
        self.assertIsNone(balanca.interpretar(self.etiqueta()[:-1] + "0"))  # DV errado
        self.assertIsNone(balanca.interpretar("123"))
        self.assertIsNone(balanca.interpretar(self.etiqueta(), balanca.FormatoBalanca(digitos_codigo=4)))


@override_settings(
    SECURE_SSL_REDIRECT=False, SESSION_COOKIE_SECURE=False, CSRF_COOKIE_SECURE=False
)
class PesaveisTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        admin_grupo = Group.objects.create(name=GRUPO_ADMINISTRADOR)
        vend_grupo = Group.objects.create(name=GRUPO_VENDEDOR)
        cls.admin = User.objects.create_user("admin", password="x-12345678")
        cls.admin.groups.add(admin_grupo)
        cls.vendedor = User.objects.create_user("vend", password="x-12345678")
        cls.vendedor.groups.add(vend_grupo)

    def produto(self, nome="Ração a granel", preco="39.90", estoque="10", pesavel=True, codigo="000123"):
        p = Produto.objects.create(nome=nome, codigo_barras=codigo, preco_venda=D(preco), pesavel=pesavel)
        MovimentacaoEstoque.registrar(produto=p, tipo=MovimentacaoEstoque.Tipo.ENTRADA,
                                      quantidade=D(estoque), usuario=self.admin)
        p.refresh_from_db()
        return p

    def vender(self, produto, qtd, preco=None):
        item = {"produto": produto, "quantidade": D(qtd)}
        if preco is not None:
            item["preco"] = D(preco)
        return Venda.registrar_venda(vendedor=self.vendedor, itens=[item])

    def test_venda_por_peso_baixa_estoque_fracionado_e_arredonda(self):
        produto = self.produto()
        venda = self.vender(produto, "0.745")
        self.assertEqual(venda.valor_total, D("29.73"))
        item = venda.itens.get()
        self.assertEqual(item.quantidade, D("0.745"))
        self.assertEqual(item.subtotal, D("29.73"))
        produto.refresh_from_db()
        self.assertEqual(produto.quantidade, D("9.255"))
        mov = MovimentacaoEstoque.objects.filter(tipo="VENDA").get()
        self.assertEqual((mov.quantidade_anterior, mov.quantidade_nova), (10, D("9.255")))

    def test_total_e_a_soma_dos_itens_arredondados(self):
        a = self.produto("A", "1.00", pesavel=True, codigo="1")
        b = self.produto("B", "1.00", pesavel=True, codigo="2")
        c = self.produto("C", "1.00", pesavel=True, codigo="3")
        venda = Venda.registrar_venda(vendedor=self.vendedor, itens=[
            {"produto": p, "quantidade": D("0.125")} for p in (a, b, c)])
        self.assertEqual(venda.valor_total, D("0.39"))
        self.assertEqual(sum(i.subtotal for i in venda.itens.all()), venda.valor_total)

    def test_produto_por_unidade_recusa_fracao_e_mais_de_3_casas(self):
        unidade = self.produto("Coleira", "20.00", "10", pesavel=False, codigo="9")
        with self.assertRaises(ValidationError):
            self.vender(unidade, "1.5")
        kg = self.produto()
        with self.assertRaises(ValidationError):
            self.vender(kg, "0.7451")
        self.assertEqual(Venda.objects.count(), 0)
        unidade.refresh_from_db()
        self.assertEqual(unidade.quantidade, 10)

    def test_estoque_insuficiente_em_kg(self):
        kg = self.produto(estoque="1.5")
        with self.assertRaises(ValidationError):
            self.vender(kg, "1.501")
        self.assertEqual(self.vender(kg, "1.5").valor_total, D("59.85"))
        kg.refresh_from_db()
        self.assertEqual(kg.quantidade, 0)

    def test_movimentacao_manual_fracionada(self):
        kg = self.produto(estoque="0.5")
        MovimentacaoEstoque.registrar(produto=kg, tipo="ENTRADA", quantidade=D("2.25"), usuario=self.admin)
        kg.refresh_from_db()
        self.assertEqual(kg.quantidade, D("2.75"))
        MovimentacaoEstoque.registrar(produto=kg, tipo="AJUSTE", quantidade=D("1.2"), usuario=self.admin)
        kg.refresh_from_db()
        self.assertEqual(kg.quantidade, D("1.2"))
        unidade = self.produto("Brinquedo", "5.00", "3", pesavel=False, codigo="8")
        with self.assertRaises(ValidationError):
            MovimentacaoEstoque.registrar(produto=unidade, tipo="ENTRADA", quantidade=D("0.5"), usuario=self.admin)

    def test_formularios(self):
        unidade = self.produto("Brinquedo", "5.00", "3", pesavel=False, codigo="8")
        kg = self.produto()
        f = ItemVendaForm({"produto": unidade.pk, "quantidade": "1.5"})
        self.assertIn("quantidade", f.errors)
        f = ItemVendaForm({"produto": kg.pk, "quantidade": "1.5"})
        self.assertTrue(f.is_valid(), f.errors)
        m = MovimentacaoEstoqueForm({"produto": unidade.pk, "tipo": "ENTRADA", "quantidade": "0.5"}, usuario=self.admin)
        self.assertIn("quantidade", m.errors)
        m = MovimentacaoEstoqueForm({"produto": kg.pk, "tipo": "ENTRADA", "quantidade": "0.5"}, usuario=self.admin)
        self.assertTrue(m.is_valid(), m.errors)

    def test_pdv_com_peso_e_pagamento(self):
        kg = self.produto()
        sessao = pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("0"))
        venda, troco = pdv_services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor,
            itens=[{"produto": kg, "quantidade": D("0.745"), "preco": kg.preco_venda}],
            pagamentos={FormaPagamento.DINHEIRO: D("30.00")},
        )
        self.assertEqual(venda.valor_total, D("29.73"))
        self.assertEqual(troco, D("0.27"))

    def test_nfce_usa_kg_e_quantidade_fracionada(self):
        kg = self.produto()
        ProdutoFiscal.objects.create(produto=kg, ncm="23091000", unidade="UN")
        venda = self.vender(kg, "0.745")
        itens = fiscal_services._itens_da_venda(venda)
        itens = itens[0] if isinstance(itens, tuple) else itens
        self.assertEqual(itens[0].unidade, "KG")
        self.assertEqual(itens[0].quantidade, D("0.745"))

    def test_formulario_de_produto_exige_inteiro_se_nao_pesavel(self):
        from produtos.forms import ProdutoForm

        base = {"nome": "X", "codigo_barras": "", "categoria": "", "fornecedor": "", "estoque_minimo": 0,
                "preco_venda": "10.00", "quantidade_inicial": "2.5", "ativo": "on"}
        self.assertIn("quantidade_inicial", ProdutoForm(base, usuario=self.admin).errors)
        ok = ProdutoForm({**base, "pesavel": "on"}, usuario=self.admin)
        self.assertTrue(ok.is_valid(), ok.errors)
        produto = ok.save()
        produto.refresh_from_db()
        self.assertEqual(produto.quantidade, D("2.5"))
        # não dá para tirar "por peso" com estoque fracionado
        edicao = ProdutoForm({"nome": "X", "codigo_barras": "", "categoria": "", "fornecedor": "",
                              "estoque_minimo": 0, "preco_venda": "10.00", "ativo": "on"},
                             instance=produto, usuario=self.admin)
        self.assertIn("pesavel", edicao.errors)

    def test_tela_de_venda_expoe_pesavel_e_formato_da_balanca(self):
        self.produto()
        self.client.force_login(self.vendedor)
        html = self.client.get(reverse("vendas:create")).content.decode()
        self.assertIn('data-pesavel="1"', html)
        self.assertIn('data-balanca-prefixo="2"', html)
