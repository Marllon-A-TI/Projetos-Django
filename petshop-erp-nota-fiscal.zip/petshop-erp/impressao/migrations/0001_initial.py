import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('vendas', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='ContadorSenha',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('data', models.DateField(unique=True, verbose_name='data')),
                ('ultimo', models.PositiveIntegerField(default=0, verbose_name='última senha')),
            ],
            options={
                'verbose_name': 'contador de senha',
                'verbose_name_plural': 'contadores de senha',
            },
        ),
        migrations.CreateModel(
            name='Impressora',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('nome', models.CharField(max_length=60, unique=True, verbose_name='nome')),
                ('finalidade', models.CharField(choices=[('CUPOM', 'Cupom / notas / caixa'), ('ETIQUETA', 'Etiquetas')], default='CUPOM', max_length=10, verbose_name='finalidade')),
                ('marca', models.CharField(choices=[('GENERICA', 'Genérica ESC/POS'), ('DARUMA', 'Daruma'), ('ELGIN', 'Elgin'), ('BEMATECH', 'Bematech'), ('EPSON', 'Epson')], default='GENERICA', max_length=10, verbose_name='marca')),
                ('conexao', models.CharField(choices=[('REDE', 'Rede (IP:porta, normalmente 9100)'), ('WINDOWS', 'Impressora instalada no Windows (USB)'), ('SERIAL', 'Porta serial (COM)'), ('ARQUIVO', 'Arquivo (teste, sem impressora)')], max_length=10, verbose_name='conexão')),
                ('endereco', models.CharField(blank=True, help_text='Rede: 192.168.0.50 ou 192.168.0.50:9100. Windows: nome exato da impressora. Serial: COM3 ou COM3:9600. Arquivo: deixe em branco.', max_length=150, verbose_name='endereço')),
                ('colunas', models.PositiveSmallIntegerField(default=48, help_text='Bobina 80 mm: 48 (ou 42). Bobina 58 mm: 32.', verbose_name='colunas')),
                ('pagina_codigo', models.PositiveSmallIntegerField(default=3, help_text='Acentos errados na impressão? Troque este número (veja o manual da marca).', verbose_name='página de código (ESC t)')),
                ('codec', models.CharField(default='cp860', max_length=20, verbose_name='codificação')),
                ('corte', models.CharField(choices=[('GS_V', 'Padrão (GS V)'), ('ESC_M', 'Antigo (ESC m)'), ('NENHUM', 'Sem guilhotina')], default='GS_V', max_length=8, verbose_name='tipo de corte')),
                ('tem_gaveta', models.BooleanField(default=False, verbose_name='tem gaveta de dinheiro ligada')),
                ('pino_gaveta', models.PositiveSmallIntegerField(default=0, help_text='0 ou 1. Se não abrir, tente o outro.', verbose_name='pino da gaveta')),
                ('padrao', models.BooleanField(default=False, verbose_name='padrão da finalidade')),
                ('ativo', models.BooleanField(default=True, verbose_name='ativa')),
                ('situacao', models.CharField(choices=[('DESCONHECIDA', 'Ainda não verificada'), ('ONLINE', 'Online'), ('OFFLINE', 'Sem resposta')], default='DESCONHECIDA', editable=False, max_length=12, verbose_name='situação')),
                ('situacao_detalhe', models.CharField(blank=True, default='', editable=False, max_length=200, verbose_name='detalhe')),
                ('verificada_em', models.DateTimeField(blank=True, editable=False, null=True, verbose_name='verificada em')),
            ],
            options={
                'verbose_name': 'impressora',
                'verbose_name_plural': 'impressoras',
                'ordering': ['nome'],
            },
        ),
        migrations.AddConstraint(
            model_name='impressora',
            constraint=models.UniqueConstraint(condition=models.Q(('padrao', True)), fields=('finalidade',), name='impressora_uma_padrao_por_finalidade'),
        ),
        migrations.CreateModel(
            name='TrabalhoImpressao',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('criado_em', models.DateTimeField(auto_now_add=True, verbose_name='criado em')),
                ('atualizado_em', models.DateTimeField(auto_now=True, verbose_name='atualizado em')),
                ('tipo', models.CharField(choices=[('CUPOM', 'Cupom não fiscal'), ('DANFE', 'DANFE NFC-e'), ('PEDIDO', 'Pedido'), ('ETIQUETA', 'Etiqueta'), ('SENHA', 'Senha'), ('CAIXA', 'Comprovante de caixa'), ('RECIBO', 'Recibo'), ('GAVETA', 'Abrir gaveta'), ('TESTE', 'Teste')], max_length=10, verbose_name='tipo')),
                ('titulo', models.CharField(max_length=150, verbose_name='título')),
                ('conteudo', models.BinaryField(editable=False, verbose_name='conteúdo ESC/POS')),
                ('previa', models.TextField(blank=True, default='', verbose_name='prévia')),
                ('status', models.CharField(choices=[('PENDENTE', 'Na fila'), ('IMPRESSO', 'Impresso'), ('ERRO', 'Falhou'), ('CANCELADO', 'Cancelado')], db_index=True, default='PENDENTE', max_length=10, verbose_name='situação')),
                ('tentativas', models.PositiveSmallIntegerField(default=0, verbose_name='tentativas')),
                ('max_tentativas', models.PositiveSmallIntegerField(default=5, verbose_name='máximo de tentativas')),
                ('proxima_tentativa', models.DateTimeField(blank=True, null=True, verbose_name='próxima tentativa')),
                ('erro', models.TextField(blank=True, default='', verbose_name='último erro')),
                ('impresso_em', models.DateTimeField(blank=True, null=True, verbose_name='impresso em')),
                ('impressora', models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name='trabalhos', to='impressao.impressora', verbose_name='impressora')),
                ('reimpressao_de', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='reimpressoes', to='impressao.trabalhoimpressao', verbose_name='reimpressão de')),
                ('usuario', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='trabalhos_impressao', to=settings.AUTH_USER_MODEL, verbose_name='usuário')),
                ('venda', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='trabalhos_impressao', to='vendas.venda', verbose_name='venda')),
            ],
            options={
                'verbose_name': 'trabalho de impressão',
                'verbose_name_plural': 'fila de impressão',
                'ordering': ['-id'],
                'indexes': [models.Index(fields=['status', 'proxima_tentativa'], name='trabimp_status_prox_idx')],
            },
        ),
    ]
