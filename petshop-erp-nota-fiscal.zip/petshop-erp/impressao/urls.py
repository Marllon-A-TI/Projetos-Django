from django.urls import path

from . import views

app_name = "impressao"

urlpatterns = [
    path("", views.TrabalhoListView.as_view(), name="trabalho_list"),
    path("trabalhos/<int:pk>/", views.TrabalhoDetailView.as_view(), name="trabalho_detail"),
    path("trabalhos/<int:pk>/reimprimir/", views.TrabalhoReimprimirView.as_view(), name="trabalho_reimprimir"),
    path("trabalhos/<int:pk>/tentar-novamente/", views.TrabalhoRetentarView.as_view(), name="trabalho_retentar"),
    path("trabalhos/<int:pk>/cancelar/", views.TrabalhoCancelarView.as_view(), name="trabalho_cancelar"),
    path("processar/", views.ProcessarFilaView.as_view(), name="processar_fila"),
    path("impressoras/", views.ImpressoraListView.as_view(), name="impressora_list"),
    path("impressoras/nova/", views.ImpressoraCreateView.as_view(), name="impressora_create"),
    path("impressoras/<int:pk>/editar/", views.ImpressoraUpdateView.as_view(), name="impressora_update"),
    path("impressoras/<int:pk>/testar/", views.ImpressoraTestarView.as_view(), name="impressora_testar"),
    path("impressoras/verificar/", views.ImpressoraVerificarView.as_view(), name="impressora_verificar_todas"),
    path("impressoras/<int:pk>/verificar/", views.ImpressoraVerificarView.as_view(), name="impressora_verificar"),
    path("venda/<int:pk>/cupom/", views.ImprimirCupomView.as_view(), name="imprimir_cupom"),
    path("venda/<int:pk>/pedido/", views.ImprimirPedidoView.as_view(), name="imprimir_pedido"),
    path("documento/<int:pk>/danfe/", views.ImprimirDanfeView.as_view(), name="imprimir_danfe"),
    path("produto/<int:pk>/etiqueta/", views.ImprimirEtiquetaView.as_view(), name="imprimir_etiqueta"),
    path("senha/", views.ImprimirSenhaView.as_view(), name="imprimir_senha"),
    path("gaveta/", views.AbrirGavetaView.as_view(), name="abrir_gaveta"),
    path("caixa/<int:pk>/comprovante/", views.ComprovanteCaixaView.as_view(), name="comprovante_caixa"),
]
