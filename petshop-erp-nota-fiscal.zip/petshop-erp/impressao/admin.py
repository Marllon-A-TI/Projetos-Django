from django.contrib import admin

from core.admin import ImutavelAdminMixin, SomenteLeituraAdminMixin

from .models import Impressora, TrabalhoImpressao


@admin.register(Impressora)
class ImpressoraAdmin(ImutavelAdminMixin, admin.ModelAdmin):
    list_display = ("nome", "finalidade", "conexao", "endereco", "padrao", "ativo", "situacao")
    list_filter = ("finalidade", "conexao", "ativo")
    list_per_page = 50


@admin.register(TrabalhoImpressao)
class TrabalhoImpressaoAdmin(SomenteLeituraAdminMixin, admin.ModelAdmin):
    list_display = ("__str__", "impressora", "status", "tentativas", "usuario", "criado_em")
    list_filter = ("status", "tipo", "impressora")
    list_select_related = ("impressora", "usuario")
    exclude = ("conteudo",)
    list_per_page = 50
