"""
Testes da impressão. Rodar:  python manage.py test impressao
(precisa do PostgreSQL configurado no .env; o Django cria um banco de teste).
Nenhum teste usa impressora de verdade: rede é simulada com um servidor local
e o resto grava em arquivo.
"""

import socket
import tempfile
import threading
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

from django.contrib.auth.models import Group, User
from django.core.exceptions import ValidationError
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from accounts.models import GRUPO_ADMINISTRADOR, GRUPO_VENDEDOR
from estoque.models import MovimentacaoEstoque
from logs.models import LogAcao
from pdv import services as pdv_services
from pdv.models import FormaPagamento
from produtos.models import Produto
from vendas.models import Venda

from . import documentos, escpos, services, transports
from .forms import ImpressoraForm
from .models import ContadorSenha, Impressora, TrabalhoImpressao

D = Decimal
Status = TrabalhoImpressao.Status


class EscposTests(SimpleTestCase):
    def loja(self):
        return documentos.Loja(nome="Pet Shop Teste", cnpj="11222333000181")

    def test_cupom_tem_corte_gaveta_e_acentos_em_cp860(self):
        dados = documentos.DadosCupom(
            loja=self.loja(), numero="7", data_hora="01/01/2026 10:00", operador="Ana",
            itens=[documentos.LinhaItem("Ração Premium", D(2), D("10.50"))], total=D("21.00"),
            pagamentos=[("Dinheiro", D("21.00"))],
        )
        doc = documentos.cupom_nao_fiscal(dados, escpos.Perfil(), gaveta=True)
        corpo = doc.bytes()
        self.assertTrue(corpo.endswith(b"\x1dV\x42\x00"))
        self.assertIn(b"\x1bp\x00", corpo)
        self.assertIn("Ração".encode("cp860"), corpo)
        self.assertIn("R$ 21,00", doc.previa())

    def test_corte_e_gaveta_seguem_o_perfil(self):
        antigo = escpos.Perfil(corte=escpos.CORTE_ESC_M, pino_gaveta=1)
        doc = documentos.teste("X", antigo)
        self.assertTrue(doc.bytes().endswith(b"\x1bm"))
        self.assertIn(b"\x1bp\x01", documentos.abrir_gaveta(antigo).bytes())
        self.assertNotIn(b"\x1dV", documentos.teste("X", escpos.Perfil(corte=escpos.CORTE_NENHUM)).bytes())

    def test_linha_respeita_colunas(self):
        doc = documentos.teste("X", escpos.Perfil(colunas=32))
        self.assertTrue(all(len(l) <= 32 for l in doc.previa().splitlines()))

    def test_etiqueta_escolhe_ean13_ou_code128(self):
        self.assertIn("[EAN-13", documentos.etiqueta("Ração", D("9.90"), "7891234567895").previa())
        self.assertIn("[Code128", documentos.etiqueta("Ração", D("9.90"), "ABC-1").previa())

    def test_senha_grande(self):
        self.assertIn("007", documentos.senha(self.loja(), 7, "01/01 10:00").previa())


class TransporteTests(SimpleTestCase):
    def impressora(self, **campos):
        base = dict(conexao="ARQUIVO", endereco="", nome="T")
        base.update(campos)
        return SimpleNamespace(**base)

    def servidor(self):
        recebido = []
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        s.listen(1)

        def aceitar():
            conn, _ = s.accept()
            with conn:
                while True:
                    parte = conn.recv(4096)
                    if not parte:
                        break
                    recebido.append(parte)
            s.close()

        threading.Thread(target=aceitar, daemon=True).start()
        return s.getsockname()[1], recebido

    def test_rede_entrega_os_bytes(self):
        porta, recebido = self.servidor()
        transports.enviar(self.impressora(conexao="REDE", endereco=f"127.0.0.1:{porta}"), b"abc\x1dV")
        for _ in range(50):
            if recebido:
                break
            threading.Event().wait(0.02)
        self.assertEqual(b"".join(recebido), b"abc\x1dV")

    def test_rede_sem_resposta_da_erro_claro(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        porta = s.getsockname()[1]
        s.close()  # ninguém escutando
        with self.assertRaises(transports.ImpressaoErro):
            transports.enviar(self.impressora(conexao="REDE", endereco=f"127.0.0.1:{porta}"), b"x")
        ok, texto = transports.testar_conexao(self.impressora(conexao="REDE", endereco=f"127.0.0.1:{porta}"))
        self.assertFalse(ok)
        self.assertIn("Sem resposta", texto)

    def test_rede_sem_endereco(self):
        ok, texto = transports.testar_conexao(self.impressora(conexao="REDE", endereco=""))
        self.assertFalse(ok)

    def test_arquivo(self):
        with tempfile.TemporaryDirectory() as pasta, override_settings(IMPRESSAO_DIR_ARQUIVOS=pasta):
            transports.enviar(self.impressora(), b"dados", "trabalho-1")
            self.assertEqual((Path(pasta) / "trabalho-1.bin").read_bytes(), b"dados")
            self.assertTrue(transports.testar_conexao(self.impressora())[0])

    def test_windows_sem_pywin32_explica_a_instalacao(self):
        try:
            import win32print  # noqa: F401
        except ImportError:
            with self.assertRaises(transports.ImpressaoErro) as ctx:
                transports.enviar(self.impressora(conexao="WINDOWS", endereco="X"), b"x")
            self.assertIn("pywin32", str(ctx.exception))
        else:
            self.skipTest("pywin32 instalado")

    def test_serial_endereco_invalido(self):
        ok, _ = transports.testar_conexao(self.impressora(conexao="SERIAL", endereco=""))
        self.assertFalse(ok)


@override_settings(
    SECURE_SSL_REDIRECT=False, SESSION_COOKIE_SECURE=False, CSRF_COOKIE_SECURE=False
)
class BaseImpressao(TestCase):
    @classmethod
    def setUpTestData(cls):
        admin_grupo = Group.objects.create(name=GRUPO_ADMINISTRADOR)
        vend_grupo = Group.objects.create(name=GRUPO_VENDEDOR)
        cls.admin = User.objects.create_user("admin", password="x-12345678")
        cls.admin.groups.add(admin_grupo)
        cls.vendedor = User.objects.create_user("vend", password="x-12345678")
        cls.vendedor.groups.add(vend_grupo)
        cls.outro = User.objects.create_user("outro", password="x-12345678")
        cls.outro.groups.add(vend_grupo)

    def setUp(self):
        self._pasta = tempfile.TemporaryDirectory()
        self.addCleanup(self._pasta.cleanup)
        sobrescrita = override_settings(IMPRESSAO_DIR_ARQUIVOS=self._pasta.name)
        sobrescrita.enable()
        self.addCleanup(sobrescrita.disable)

    def impressora(self, **campos):
        base = dict(nome="Balcão", conexao="ARQUIVO", padrao=True, tem_gaveta=True)
        base.update(campos)
        return Impressora.objects.create(**base)

    def porta_fechada(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        porta = s.getsockname()[1]
        s.close()
        return f"127.0.0.1:{porta}"

    def produto(self, nome="Ração", preco="10.00"):
        p = Produto.objects.create(nome=nome, codigo_barras="7891234567895", preco_venda=D(preco))
        MovimentacaoEstoque.registrar(produto=p, tipo=MovimentacaoEstoque.Tipo.ENTRADA, quantidade=50,
                                      usuario=self.admin)
        p.refresh_from_db()
        return p

    def venda(self, vendedor=None, produto=None, quantidade=2):
        produto = produto or self.produto()
        return Venda.registrar_venda(
            vendedor=vendedor or self.vendedor,
            itens=[{"produto": produto, "quantidade": quantidade, "preco": produto.preco_venda}],
        )

    def venda_pdv_dinheiro(self):
        sessao = pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("50.00"))
        produto = self.produto()
        venda, _ = pdv_services.registrar_venda_pdv(
            sessao=sessao, operador=self.vendedor,
            itens=[{"produto": produto, "quantidade": 1, "preco": produto.preco_venda}],
            pagamentos={FormaPagamento.DINHEIRO: D("20.00")},
        )
        return venda, sessao


class FilaTests(BaseImpressao):
    def test_cupom_imprime_e_grava_trabalho(self):
        self.impressora()
        venda = self.venda()
        trabalho = services.imprimir_cupom(venda, self.vendedor)
        self.assertEqual(trabalho.status, Status.IMPRESSO)
        self.assertEqual(trabalho.venda, venda)
        self.assertIn("CUPOM NAO FISCAL", trabalho.previa)
        self.assertTrue((Path(self._pasta.name) / f"trabalho-{trabalho.pk}.bin").exists())

    def test_falha_deixa_na_fila_com_nova_tentativa_agendada(self):
        self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho = services.imprimir_cupom(self.venda(), self.vendedor)
        self.assertEqual(trabalho.status, Status.PENDENTE)
        self.assertEqual(trabalho.tentativas, 1)
        self.assertIn("Sem resposta", trabalho.erro)
        self.assertGreater(trabalho.proxima_tentativa, timezone.now())

    def test_fila_respeita_espera_e_imprime_quando_a_impressora_volta(self):
        imp = self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho = services.imprimir_cupom(self.venda(), self.vendedor)
        self.assertEqual(services.processar_fila(), (0, 0))  # ainda esperando o intervalo
        imp.conexao = "ARQUIVO"
        imp.save()
        TrabalhoImpressao.objects.filter(pk=trabalho.pk).update(proxima_tentativa=timezone.now() - timedelta(seconds=1))
        self.assertEqual(services.processar_fila(), (1, 0))
        trabalho.refresh_from_db()
        self.assertEqual(trabalho.status, Status.IMPRESSO)
        self.assertEqual(trabalho.erro, "")

    def test_esgotadas_as_tentativas_vira_erro_e_pode_tentar_de_novo(self):
        imp = self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho = services.imprimir_cupom(self.venda(), self.vendedor)
        TrabalhoImpressao.objects.filter(pk=trabalho.pk).update(max_tentativas=2, tentativas=1)
        trabalho.refresh_from_db()
        trabalho = services.imprimir_agora(trabalho)
        self.assertEqual(trabalho.status, Status.ERRO)
        self.assertIsNone(trabalho.proxima_tentativa)
        imp.conexao = "ARQUIVO"
        imp.save()
        self.assertEqual(services.tentar_novamente(trabalho).status, Status.IMPRESSO)

    def test_cancelar_e_regras(self):
        self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho = services.imprimir_cupom(self.venda(), self.vendedor)
        self.assertEqual(services.cancelar(trabalho).status, Status.CANCELADO)
        with self.assertRaises(ValidationError):
            services.cancelar(trabalho)
        self.assertEqual(services.processar_fila(), (0, 0))  # cancelado não é reenviado

    def test_reimpressao_gera_copia_identica(self):
        self.impressora()
        original = services.imprimir_cupom(self.venda(), self.vendedor)
        copia = services.reimprimir(original, self.admin)
        self.assertNotEqual(copia.pk, original.pk)
        self.assertEqual(bytes(copia.conteudo), bytes(original.conteudo))
        self.assertEqual(copia.reimpressao_de, original)
        self.assertEqual(copia.status, Status.IMPRESSO)

    def test_sem_impressora_levanta_erro_claro_e_o_automatico_nao_faz_nada(self):
        venda = self.venda()
        with self.assertRaises(ValidationError):
            services.imprimir_cupom(venda, self.vendedor)
        self.assertEqual(services.imprimir_venda_pdv_automatico(venda, self.vendedor), (None, ""))

    def test_automatico_avisa_mas_nao_levanta_quando_impressora_cai(self):
        self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho, aviso = services.imprimir_venda_pdv_automatico(self.venda(), self.vendedor)
        self.assertEqual(trabalho.status, Status.PENDENTE)
        self.assertIn("fila de impressão", aviso)

    def test_gaveta_so_abre_com_dinheiro_e_impressora_com_gaveta(self):
        self.impressora()
        venda, _ = self.venda_pdv_dinheiro()
        self.assertIn("[abre gaveta]", services.imprimir_cupom(venda, self.vendedor).previa)
        sem_dinheiro = self.venda()  # venda comum: sem pagamento registrado
        self.assertNotIn("[abre gaveta]", services.imprimir_cupom(sem_dinheiro, self.vendedor).previa)
        Impressora.objects.update(tem_gaveta=False)
        self.assertNotIn("[abre gaveta]", services.imprimir_cupom(venda, self.vendedor).previa)

    def test_abrir_gaveta_manual_exige_gaveta(self):
        self.impressora(tem_gaveta=False)
        with self.assertRaises(ValidationError):
            services.abrir_gaveta(self.admin)
        Impressora.objects.update(tem_gaveta=True)
        self.assertEqual(services.abrir_gaveta(self.admin).status, Status.IMPRESSO)

    def test_senhas_sequenciais_e_recomecam_a_cada_dia(self):
        self.impressora()
        self.assertEqual([services.proxima_senha() for _ in range(3)], [1, 2, 3])
        ContadorSenha.objects.update(data=timezone.localdate() - timedelta(days=1))
        self.assertEqual(services.proxima_senha(), 1)
        self.assertIn("002", services.imprimir_senha(self.vendedor).previa)

    def test_etiquetas_usam_a_impressora_de_etiqueta(self):
        self.impressora()  # cupom
        produto = self.produto()
        with self.assertRaises(ValidationError):
            services.imprimir_etiquetas(produto, self.admin)
        self.impressora(nome="Etiquetas", finalidade="ETIQUETA")
        trabalhos = services.imprimir_etiquetas(produto, self.admin, copias=3)
        self.assertEqual(len(trabalhos), 3)
        self.assertTrue(all(t.status == Status.IMPRESSO for t in trabalhos))

    def test_comprovante_de_caixa(self):
        self.impressora()
        _, sessao = self.venda_pdv_dinheiro()
        trabalho = services.imprimir_comprovante_caixa(sessao, pdv_services.resumo_sessao(sessao), self.vendedor)
        self.assertIn("Dinheiro esperado", trabalho.previa)
        self.assertIn("R$ 70,00", trabalho.previa)  # 50 de fundo + 20 em dinheiro

    def test_monitoramento_e_verificacao(self):
        imp = self.impressora()
        self.impressora(nome="Fora", conexao="REDE", endereco=self.porta_fechada(), padrao=False, finalidade="ETIQUETA")
        ok, _ = services.verificar(imp)
        self.assertTrue(ok)
        imp.refresh_from_db()
        self.assertEqual(imp.situacao, Impressora.Situacao.ONLINE)
        fora = Impressora.objects.get(nome="Fora")
        self.assertFalse(services.verificar(fora)[0])
        self.assertEqual(Impressora.objects.get(nome="Fora").situacao, Impressora.Situacao.OFFLINE)
        self.assertEqual(len(services.monitorar()), 2)

    def test_impressora_padrao_por_finalidade_e_fallback(self):
        a = self.impressora(nome="A", padrao=False)
        b = self.impressora(nome="B", padrao=True)
        self.assertEqual(services.impressora_para("CUPOM"), b)
        Impressora.objects.filter(pk=b.pk).update(ativo=False)
        self.assertEqual(services.impressora_para("CUPOM"), a)
        self.assertIsNone(services.impressora_para("ETIQUETA"))

    def test_cabecalho_usa_empresa_fiscal_padrao(self):
        from fiscal.models import Empresa

        Empresa.objects.create(
            razao_social="Pet Shop Ltda", nome_fantasia="Pet Feliz", cnpj="11222333000181", uf="RJ",
            logradouro="Rua A", numero="1", bairro="Centro", municipio="Itaboraí",
            codigo_municipio_ibge="3301900", cep="24800000", padrao=True,
        )
        self.assertEqual(services.loja_atual().nome, "Pet Feliz")


class FormularioTests(BaseImpressao):
    def dados(self, **extra):
        base = dict(nome="Caixa", finalidade="CUPOM", marca="GENERICA", conexao="REDE", endereco="192.168.0.50",
                    colunas=48, pagina_codigo=3, codec="cp860", corte="GS_V", tem_gaveta="on",
                    pino_gaveta=0, padrao="on", ativo="on")
        base.update(extra)
        return base

    def test_so_uma_padrao_por_finalidade(self):
        antiga = self.impressora(nome="Antiga")
        form = ImpressoraForm(self.dados())
        self.assertTrue(form.is_valid(), form.errors)
        nova = form.save()
        antiga.refresh_from_db()
        self.assertTrue(nova.padrao)
        self.assertFalse(antiga.padrao)

    def test_validacoes(self):
        self.assertIn("endereco", ImpressoraForm(self.dados(endereco="")).errors)
        self.assertIn("codec", ImpressoraForm(self.dados(codec="inventado")).errors)
        self.assertIn("colunas", ImpressoraForm(self.dados(colunas=5)).errors)
        self.assertIn("pino_gaveta", ImpressoraForm(self.dados(pino_gaveta=7)).errors)
        self.assertIn("padrao", ImpressoraForm(self.dados(ativo="")).errors)


class ViewsTests(BaseImpressao):
    def test_vendedor_nao_acessa_impressoras_nem_etiqueta(self):
        self.impressora()
        self.client.force_login(self.vendedor)
        self.assertEqual(self.client.get(reverse("impressao:impressora_list")).status_code, 403)
        produto = self.produto()
        self.assertEqual(self.client.post(reverse("impressao:imprimir_etiqueta", args=[produto.pk])).status_code, 403)

    def test_anonimo_vai_para_o_login(self):
        resposta = self.client.get(reverse("impressao:trabalho_list"))
        self.assertEqual(resposta.status_code, 302)

    def test_vendedor_imprime_cupom_da_propria_venda_e_audita(self):
        self.impressora()
        venda = self.venda(vendedor=self.vendedor)
        self.client.force_login(self.vendedor)
        resposta = self.client.post(reverse("impressao:imprimir_cupom", args=[venda.pk]), follow=True)
        self.assertContains(resposta, "Cupom enviado para a impressora")
        self.assertEqual(TrabalhoImpressao.objects.filter(venda=venda, status=Status.IMPRESSO).count(), 1)
        self.assertTrue(LogAcao.objects.filter(acao=LogAcao.Acao.IMPRESSAO).exists())

    def test_vendedor_nao_imprime_venda_de_outro(self):
        self.impressora()
        venda = self.venda(vendedor=self.outro)
        self.client.force_login(self.vendedor)
        self.assertEqual(self.client.post(reverse("impressao:imprimir_cupom", args=[venda.pk])).status_code, 404)
        self.assertEqual(TrabalhoImpressao.objects.count(), 0)

    def test_sem_impressora_mostra_mensagem_e_nao_quebra(self):
        venda = self.venda()
        self.client.force_login(self.admin)
        resposta = self.client.post(reverse("impressao:imprimir_cupom", args=[venda.pk]), follow=True)
        self.assertContains(resposta, "Nenhuma impressora configurada")

    def test_fila_do_vendedor_mostra_so_os_seus(self):
        self.impressora()
        meu = services.imprimir_cupom(self.venda(vendedor=self.vendedor), self.vendedor)
        alheio = services.imprimir_cupom(self.venda(vendedor=self.outro), self.outro)
        self.client.force_login(self.vendedor)
        self.assertContains(self.client.get(reverse("impressao:trabalho_list")), f"#{meu.venda_id}")
        self.assertNotContains(self.client.get(reverse("impressao:trabalho_list")), f"#{alheio.venda_id}</")
        self.assertEqual(self.client.get(reverse("impressao:trabalho_detail", args=[alheio.pk])).status_code, 404)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse("impressao:trabalho_detail", args=[alheio.pk])).status_code, 200)

    def test_reimprimir_cancelar_e_retentar_pelas_telas(self):
        self.impressora(conexao="REDE", endereco=self.porta_fechada())
        trabalho = services.imprimir_cupom(self.venda(), self.admin)
        self.client.force_login(self.admin)
        self.client.post(reverse("impressao:trabalho_cancelar", args=[trabalho.pk]))
        trabalho.refresh_from_db()
        self.assertEqual(trabalho.status, Status.CANCELADO)
        Impressora.objects.update(conexao="ARQUIVO")
        self.client.post(reverse("impressao:trabalho_retentar", args=[trabalho.pk]))
        trabalho.refresh_from_db()
        self.assertEqual(trabalho.status, Status.IMPRESSO)
        self.client.post(reverse("impressao:trabalho_reimprimir", args=[trabalho.pk]))
        self.assertEqual(TrabalhoImpressao.objects.filter(reimpressao_de=trabalho).count(), 1)

    def test_next_externo_e_ignorado(self):
        self.impressora()
        venda = self.venda()
        self.client.force_login(self.admin)
        resposta = self.client.post(reverse("impressao:imprimir_cupom", args=[venda.pk]), {"next": "https://evil.example/"})
        self.assertEqual(resposta.status_code, 302)
        self.assertTrue(resposta["Location"].startswith("/"))

    def test_admin_cadastra_e_testa_impressora(self):
        self.client.force_login(self.admin)
        resposta = self.client.post(reverse("impressao:impressora_create"), {
            "nome": "Térmica", "finalidade": "CUPOM", "marca": "ELGIN", "conexao": "ARQUIVO", "endereco": "",
            "colunas": 48, "pagina_codigo": 3, "codec": "cp860", "corte": "GS_V", "pino_gaveta": 0,
            "padrao": "on", "ativo": "on",
        })
        self.assertEqual(resposta.status_code, 302)
        imp = Impressora.objects.get(nome="Térmica")
        self.client.post(reverse("impressao:impressora_testar", args=[imp.pk]))
        self.assertEqual(TrabalhoImpressao.objects.get(impressora=imp).tipo, "TESTE")
        self.assertContains(self.client.get(reverse("impressao:impressora_list")), "Térmica")

    def test_comprovante_de_caixa_so_do_proprio_operador(self):
        self.impressora()
        _, sessao = self.venda_pdv_dinheiro()
        self.client.force_login(self.outro)
        self.assertEqual(self.client.post(reverse("impressao:comprovante_caixa", args=[sessao.pk])).status_code, 404)
        self.client.force_login(self.vendedor)
        self.client.post(reverse("impressao:comprovante_caixa", args=[sessao.pk]))
        self.assertTrue(TrabalhoImpressao.objects.filter(tipo="CAIXA").exists())

    def test_gaveta_e_senha_pelo_painel_do_pdv(self):
        self.impressora()
        self.client.force_login(self.vendedor)
        pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("0"))
        self.assertContains(self.client.get(reverse("pdv:painel")), "Abrir gaveta")
        self.client.post(reverse("impressao:abrir_gaveta"))
        self.client.post(reverse("impressao:imprimir_senha"))
        self.assertEqual(set(TrabalhoImpressao.objects.values_list("tipo", flat=True)), {"GAVETA", "SENHA"})

    def test_venda_do_pdv_imprime_sozinha_e_a_venda_sobrevive_a_impressora_fora(self):
        self.impressora(conexao="REDE", endereco=self.porta_fechada())
        self.client.force_login(self.vendedor)
        pdv_services.abrir_caixa(operador=self.vendedor, fundo_troco=D("0"))
        produto = self.produto()
        resposta = self.client.post(reverse("pdv:venda"), {
            "form-TOTAL_FORMS": "1", "form-INITIAL_FORMS": "0",
            "form-MIN_NUM_FORMS": "1", "form-MAX_NUM_FORMS": "1000",
            "form-0-produto": str(produto.pk), "form-0-quantidade": "1",
            "DINHEIRO": "10",
        }, follow=True)
        self.assertEqual(Venda.objects.count(), 1)
        self.assertEqual(TrabalhoImpressao.objects.filter(status=Status.PENDENTE).count(), 1)
        self.assertContains(resposta, "fila de impressão")

    @override_settings(IMPRESSAO_AUTO_PDV=False)
    def test_impressao_automatica_pode_ser_desligada(self):
        self.impressora()
        venda, _ = self.venda_pdv_dinheiro()
        from pdv.views import _imprimir_cupom_automatico
        _imprimir_cupom_automatico(SimpleNamespace(user=self.vendedor, META={}), venda)
        self.assertEqual(TrabalhoImpressao.objects.count(), 0)
