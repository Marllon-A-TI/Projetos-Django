import codecs

from django import forms
from django.db import transaction

from core.forms import BootstrapFormMixin

from .models import Impressora


class ImpressoraForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Impressora
        fields = [
            "nome", "finalidade", "marca", "conexao", "endereco", "colunas", "pagina_codigo", "codec",
            "corte", "tem_gaveta", "pino_gaveta", "padrao", "ativo",
        ]

    def clean_codec(self):
        codec = (self.cleaned_data["codec"] or "").strip().lower()
        try:
            codecs.lookup(codec)
        except LookupError:
            raise forms.ValidationError("Codificação desconhecida. O padrão para português é cp860.")
        return codec

    def clean_colunas(self):
        colunas = self.cleaned_data["colunas"]
        if not 20 <= colunas <= 80:
            raise forms.ValidationError("Use entre 20 e 80 colunas (80 mm = 48, 58 mm = 32).")
        return colunas

    def clean_pino_gaveta(self):
        pino = self.cleaned_data["pino_gaveta"]
        if pino not in (0, 1):
            raise forms.ValidationError("Use 0 ou 1.")
        return pino

    def clean(self):
        dados = super().clean()
        if dados.get("conexao") in ("REDE", "SERIAL") and not (dados.get("endereco") or "").strip():
            self.add_error("endereco", "Informe o endereço para este tipo de conexão.")
        if dados.get("padrao") and not dados.get("ativo", True):
            self.add_error("padrao", "A impressora padrão precisa estar ativa.")
        return dados

    @transaction.atomic
    def save(self, commit=True):
        impressora = super().save(commit=commit)
        if commit and impressora.padrao:
            Impressora.objects.filter(finalidade=impressora.finalidade, padrao=True).exclude(
                pk=impressora.pk).update(padrao=False)
        return impressora


class EtiquetaForm(BootstrapFormMixin, forms.Form):
    copias = forms.IntegerField(label="Cópias", min_value=1, max_value=100, initial=1)
