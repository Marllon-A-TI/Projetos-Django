"""
Regras da impressão: fila, tentativas, reimpressão, monitoramento e os
"adaptadores" que transformam venda/nota/caixa/produto em documentos ESC/POS.

Regra de ouro: imprimir NUNCA pode impedir uma venda. Os adaptadores gravam o
trabalho na fila e tentam enviar; se a impressora falhar, o trabalho fica na
fila para nova tentativa (automática ou pelo botão).
"""

import logging
from datetime import timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from pdv.models import FormaPagamento

from . import documentos, transports
from .escpos import Perfil
from .models import ContadorSenha, Impressora, TrabalhoImpressao

log = logging.getLogger(__name__)
Tipo = TrabalhoImpressao.Tipo
Status = TrabalhoImpressao.Status


# --------------------------------------------------------------------------
# Impressoras
# --------------------------------------------------------------------------

def perfil_da(impressora):
    return Perfil(
        colunas=impressora.colunas, pagina_codigo=impressora.pagina_codigo, codec=impressora.codec,
        corte=impressora.corte, pino_gaveta=impressora.pino_gaveta,
    )


def impressora_para(finalidade=Impressora.Finalidade.CUPOM):
    """Impressora ativa: a padrão da finalidade, senão qualquer ativa dela, senão None."""
    ativas = Impressora.objects.filter(ativo=True, finalidade=finalidade)
    return ativas.filter(padrao=True).first() or ativas.order_by("id").first()


def _exigir(finalidade):
    impressora = impressora_para(finalidade)
    if impressora is None:
        raise ValidationError(
            "Nenhuma impressora configurada para isso. Cadastre em Impressão > Impressoras."
        )
    return impressora


def loja_atual():
    """Cabeçalho dos documentos: empresa fiscal padrão ou, na falta, um nome genérico."""
    try:
        from fiscal.models import Empresa

        e = Empresa.objects.filter(ativo=True, padrao=True).first()
    except Exception:  # app fiscal ausente/sem tabela: segue sem cabeçalho fiscal
        e = None
    if e is None:
        return documentos.Loja(nome="Pet Shop")
    endereco = f"{e.logradouro}, {e.numero} - {e.bairro} - {e.municipio}/{e.uf}"
    return documentos.Loja(
        nome=e.nome_fantasia or e.razao_social, cnpj=e.cnpj, inscricao_estadual=e.inscricao_estadual,
        endereco=endereco, telefone=e.telefone,
    )


def verificar(impressora):
    """Testa a comunicação e grava a situação (não imprime nada)."""
    ok, detalhe = transports.testar_conexao(impressora)
    impressora.situacao = Impressora.Situacao.ONLINE if ok else Impressora.Situacao.OFFLINE
    impressora.situacao_detalhe = detalhe[:200]
    impressora.verificada_em = timezone.now()
    impressora.save(update_fields=["situacao", "situacao_detalhe", "verificada_em", "atualizado_em"])
    return ok, detalhe


def monitorar():
    """Resumo por impressora: situação + trabalhos na fila/com erro."""
    linhas = []
    for imp in Impressora.objects.all():
        trabalhos = imp.trabalhos
        linhas.append({
            "impressora": imp,
            "na_fila": trabalhos.filter(status=Status.PENDENTE).count(),
            "com_erro": trabalhos.filter(status=Status.ERRO).count(),
        })
    return linhas


# --------------------------------------------------------------------------
# Fila
# --------------------------------------------------------------------------

def enfileirar(*, impressora, tipo, titulo, doc, usuario=None, venda=None, reimpressao_de=None):
    return TrabalhoImpressao.objects.create(
        impressora=impressora, tipo=tipo, titulo=titulo[:150], conteudo=doc.bytes(), previa=doc.previa(),
        usuario=usuario, venda=venda, reimpressao_de=reimpressao_de,
    )


def _atraso(tentativas):
    return timedelta(seconds=min(300, 5 * 2 ** max(0, tentativas - 1)))


def _tentar(trabalho):
    """Uma tentativa de envio (o chamador já travou o trabalho). Nunca levanta."""
    agora = timezone.now()
    trabalho.tentativas += 1
    try:
        transports.enviar(trabalho.impressora, bytes(trabalho.conteudo), f"trabalho-{trabalho.pk}")
    except transports.ImpressaoErro as exc:
        trabalho.erro = str(exc)
        if trabalho.tentativas >= trabalho.max_tentativas:
            trabalho.status = Status.ERRO
            trabalho.proxima_tentativa = None
        else:
            trabalho.proxima_tentativa = agora + _atraso(trabalho.tentativas)
    except Exception as exc:  # defeito inesperado: registra e segue a fila
        log.exception("Erro inesperado imprimindo o trabalho %s", trabalho.pk)
        trabalho.erro = f"Erro inesperado: {exc}"
        trabalho.status = Status.ERRO
        trabalho.proxima_tentativa = None
    else:
        trabalho.status = Status.IMPRESSO
        trabalho.impresso_em = agora
        trabalho.erro = ""
        trabalho.proxima_tentativa = None
    trabalho.save()
    return trabalho


def imprimir_agora(trabalho):
    """Tenta imprimir já. Se não conseguir, o trabalho segue na fila. Devolve o trabalho atualizado."""
    with transaction.atomic():
        atual = (TrabalhoImpressao.objects.select_for_update()
                 .select_related("impressora").get(pk=trabalho.pk))
        if atual.status != Status.PENDENTE:
            return atual
        return _tentar(atual)


def processar_fila(limite=50):
    """Tenta os trabalhos pendentes que já podem ser reenviados. Devolve (impressos, falhas)."""
    impressos = falhas = 0
    agora = timezone.now()
    pendentes = TrabalhoImpressao.objects.filter(status=Status.PENDENTE, impressora__ativo=True)
    pendentes = pendentes.filter(Q(proxima_tentativa__isnull=True) | Q(proxima_tentativa__lte=agora))
    for trabalho in list(pendentes.order_by("id")[:limite]):
        resultado = imprimir_agora(trabalho)
        if resultado.status == Status.IMPRESSO:
            impressos += 1
        elif resultado.erro:
            falhas += 1
    return impressos, falhas


def tentar_novamente(trabalho):
    if trabalho.status not in (Status.ERRO, Status.CANCELADO):
        raise ValidationError("Só dá para tentar de novo um trabalho que falhou ou foi cancelado.")
    trabalho.status = Status.PENDENTE
    trabalho.tentativas = 0
    trabalho.proxima_tentativa = None
    trabalho.save()
    return imprimir_agora(trabalho)


def cancelar(trabalho):
    if trabalho.status not in (Status.PENDENTE, Status.ERRO):
        raise ValidationError("Este trabalho já foi impresso ou cancelado.")
    trabalho.status = Status.CANCELADO
    trabalho.proxima_tentativa = None
    trabalho.save()
    return trabalho


def reimprimir(trabalho, usuario):
    """Nova cópia, idêntica, de um trabalho já impresso (ou não): vai para a fila e tenta imprimir."""
    copia = TrabalhoImpressao.objects.create(
        impressora=trabalho.impressora, tipo=trabalho.tipo, titulo=f"{trabalho.titulo} (reimpressão)"[:150],
        conteudo=bytes(trabalho.conteudo), previa=trabalho.previa, usuario=usuario, venda=trabalho.venda,
        reimpressao_de=trabalho,
    )
    return imprimir_agora(copia)


# --------------------------------------------------------------------------
# Adaptadores
# --------------------------------------------------------------------------

def _agora_texto():
    return timezone.localtime().strftime("%d/%m/%Y %H:%M")


def _nome(usuario):
    return (usuario.get_full_name() or usuario.username) if usuario else "-"


def _dados_cupom(venda):
    itens = [
        documentos.LinhaItem(
            descricao=i.produto.nome, quantidade=Decimal(i.quantidade), preco=i.preco,
            unidade="KG" if i.produto.pesavel else "UN",
            codigo=i.produto.codigo_barras or str(i.produto_id),
        )
        for i in venda.itens.select_related("produto")
    ]
    rotulos = dict(FormaPagamento.choices)
    pagamentos = [(rotulos.get(p.forma, p.forma), p.valor) for p in venda.pagamentos.all()]
    info = getattr(venda, "caixa_info", None)
    return documentos.DadosCupom(
        loja=loja_atual(), numero=str(venda.pk), data_hora=f"{venda.data:%d/%m/%Y} {venda.hora:%H:%M}",
        operador=_nome(venda.vendedor), itens=itens, total=venda.valor_total, pagamentos=pagamentos,
        troco=info.troco if info else Decimal("0.00"),
    ), any(p.forma == FormaPagamento.DINHEIRO for p in venda.pagamentos.all())


def imprimir_cupom(venda, usuario, abrir_gaveta=None):
    impressora = _exigir(Impressora.Finalidade.CUPOM)
    dados, tem_dinheiro = _dados_cupom(venda)
    gaveta = impressora.tem_gaveta and (tem_dinheiro if abrir_gaveta is None else abrir_gaveta)
    doc = documentos.cupom_nao_fiscal(dados, perfil_da(impressora), gaveta=gaveta)
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.CUPOM, titulo=f"Cupom da venda #{venda.pk}",
                          doc=doc, usuario=usuario, venda=venda)
    return imprimir_agora(trabalho)


def imprimir_pedido(venda, usuario, observacao=""):
    impressora = _exigir(Impressora.Finalidade.CUPOM)
    dados, _ = _dados_cupom(venda)
    doc = documentos.pedido(dados.loja, venda.pk, dados.data_hora, dados.itens, dados.operador,
                            observacao, perfil_da(impressora))
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.PEDIDO, titulo=f"Pedido da venda #{venda.pk}",
                          doc=doc, usuario=usuario, venda=venda)
    return imprimir_agora(trabalho)


def imprimir_danfe(documento_fiscal, usuario):
    impressora = _exigir(Impressora.Finalidade.CUPOM)
    xml = documento_fiscal.xml_autorizado or documento_fiscal.xml_assinado
    dados = documentos.dados_danfe_do_xml(
        xml, loja_atual(), protocolo=documento_fiscal.protocolo,
        data_autorizacao=timezone.localtime(documento_fiscal.atualizado_em).strftime("%d/%m/%Y %H:%M:%S"),
        autorizada=documento_fiscal.status == "AUTORIZADA",
    )
    doc = documentos.danfe_nfce(dados, perfil_da(impressora))
    trabalho = enfileirar(
        impressora=impressora, tipo=Tipo.DANFE, titulo=f"DANFE NFC-e {documento_fiscal.serie}/{documento_fiscal.numero}",
        doc=doc, usuario=usuario, venda=documento_fiscal.venda,
    )
    return imprimir_agora(trabalho)


def imprimir_etiquetas(produto, usuario, copias=1):
    impressora = _exigir(Impressora.Finalidade.ETIQUETA)
    copias = max(1, min(100, int(copias)))
    trabalhos = []
    for _ in range(copias):
        doc = documentos.etiqueta(produto.nome, produto.preco_venda, produto.codigo_barras or "",
                                  perfil_da(impressora))
        trabalhos.append(enfileirar(impressora=impressora, tipo=Tipo.ETIQUETA,
                                    titulo=f"Etiqueta: {produto.nome}", doc=doc, usuario=usuario))
    return [imprimir_agora(t) for t in trabalhos]


def proxima_senha():
    """Próximo número de senha do dia (sem repetir, mesmo com dois caixas ao mesmo tempo)."""
    hoje = timezone.localdate()
    with transaction.atomic():
        contador, _ = ContadorSenha.objects.select_for_update().get_or_create(data=hoje)
        contador.ultimo += 1
        contador.save(update_fields=["ultimo"])
        return contador.ultimo


def imprimir_senha(usuario):
    impressora = _exigir(Impressora.Finalidade.CUPOM)
    numero = proxima_senha()
    doc = documentos.senha(loja_atual(), numero, _agora_texto(), perfil_da(impressora))
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.SENHA, titulo=f"Senha {numero:03d}",
                          doc=doc, usuario=usuario)
    return imprimir_agora(trabalho)


def imprimir_comprovante_caixa(sessao, resumo, usuario):
    from pdv.models import MovimentoCaixa  # noqa: F401  (documenta a origem dos dados)

    impressora = _exigir(Impressora.Finalidade.CUPOM)
    linhas = [("Fundo de troco", documentos.moeda(resumo.fundo_troco)),
              ("Vendas", f"{resumo.qtd_vendas} / {documentos.moeda(resumo.total_vendas)}")]
    linhas += [(rotulo, documentos.moeda(valor)) for rotulo, valor in resumo.linhas_formas]
    linhas += [("Suprimentos", documentos.moeda(resumo.suprimentos)),
               ("Sangrias", documentos.moeda(resumo.sangrias)),
               ("Dinheiro esperado", documentos.moeda(resumo.dinheiro_esperado))]
    if sessao.valor_contado is not None:
        linhas += [("Dinheiro contado", documentos.moeda(sessao.valor_contado)),
                   ("Diferenca", documentos.moeda(sessao.diferenca))]
    titulo = f"CAIXA #{sessao.pk} - {'FECHAMENTO' if not sessao.aberto else 'PARCIAL'}"
    doc = documentos.comprovante_caixa(loja_atual(), titulo, linhas, _agora_texto(), _nome(sessao.operador),
                                       perfil_da(impressora))
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.CAIXA, titulo=f"Comprovante do caixa #{sessao.pk}",
                          doc=doc, usuario=usuario)
    return imprimir_agora(trabalho)


def abrir_gaveta(usuario):
    impressora = _exigir(Impressora.Finalidade.CUPOM)
    if not impressora.tem_gaveta:
        raise ValidationError("A impressora padrão não está marcada com gaveta ligada.")
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.GAVETA, titulo="Abrir gaveta",
                          doc=documentos.abrir_gaveta(perfil_da(impressora)), usuario=usuario)
    return imprimir_agora(trabalho)


def imprimir_teste(impressora, usuario):
    doc = documentos.teste(impressora.nome, perfil_da(impressora))
    trabalho = enfileirar(impressora=impressora, tipo=Tipo.TESTE, titulo=f"Teste: {impressora.nome}",
                          doc=doc, usuario=usuario)
    return imprimir_agora(trabalho)


def imprimir_venda_pdv_automatico(venda, usuario):
    """
    Chamado logo após a venda do PDV. Devolve (trabalho, aviso) e NUNCA levanta:
    sem impressora configurada não faz nada; com falha, o cupom fica na fila.
    """
    try:
        if impressora_para(Impressora.Finalidade.CUPOM) is None:
            return None, ""
        trabalho = imprimir_cupom(venda, usuario)
    except Exception:
        log.exception("Falha ao enfileirar o cupom da venda %s", venda.pk)
        return None, "Não foi possível preparar o cupom para impressão. A venda foi registrada normalmente."
    if trabalho.status == Status.IMPRESSO:
        return trabalho, ""
    return trabalho, "Impressora indisponível: o cupom ficou na fila de impressão e sai quando ela voltar."
