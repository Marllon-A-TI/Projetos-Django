"""
Envio dos bytes à impressora. Sem Django: recebe a impressora como objeto
com os campos conexao/endereco/nome (facilita testar).

pywin32 (Windows/USB) e pyserial (COM) são opcionais: só são importados se a
impressora usar essa conexão.
"""

import socket
from pathlib import Path


class ImpressaoErro(Exception):
    """Falha ao falar com a impressora (mensagem pronta para o usuário)."""


TIMEOUT = 5


def _host_porta(endereco, porta_padrao=9100):
    endereco = (endereco or "").strip()
    if not endereco:
        raise ImpressaoErro("Informe o endereço IP da impressora.")
    host, _, porta = endereco.partition(":")
    try:
        return host, int(porta) if porta else porta_padrao
    except ValueError:
        raise ImpressaoErro(f"Porta inválida em '{endereco}'.")


def _serial(endereco):
    nome, _, velocidade = (endereco or "").strip().partition(":")
    if not nome:
        raise ImpressaoErro("Informe a porta serial (ex.: COM3).")
    try:
        return nome, int(velocidade) if velocidade else 9600
    except ValueError:
        raise ImpressaoErro(f"Velocidade inválida em '{endereco}'.")


def _win32print():
    try:
        import win32print
    except ImportError:
        raise ImpressaoErro(
            "Para imprimir via Windows instale o pywin32: .venv\\Scripts\\pip install pywin32"
        )
    return win32print


def _pyserial():
    try:
        import serial
    except ImportError:
        raise ImpressaoErro("Para usar porta serial instale o pyserial: .venv\\Scripts\\pip install pyserial")
    return serial


def pasta_arquivos():
    from django.conf import settings

    pasta = Path(getattr(settings, "IMPRESSAO_DIR_ARQUIVOS", Path(settings.BASE_DIR) / "var" / "impressao"))
    pasta.mkdir(parents=True, exist_ok=True)
    return pasta


def enviar(impressora, dados, identificador="trabalho"):
    """Envia `dados` (bytes). Levanta ImpressaoErro com texto claro se falhar."""
    conexao = impressora.conexao
    if conexao == "REDE":
        host, porta = _host_porta(impressora.endereco)
        try:
            with socket.create_connection((host, porta), timeout=TIMEOUT) as s:
                s.settimeout(TIMEOUT)
                s.sendall(dados)
        except OSError as exc:
            raise ImpressaoErro(f"Sem resposta de {host}:{porta} ({exc}).")
    elif conexao == "WINDOWS":
        w = _win32print()
        nome = (impressora.endereco or "").strip() or w.GetDefaultPrinter()
        try:
            h = w.OpenPrinter(nome)
        except Exception as exc:
            raise ImpressaoErro(f"Impressora '{nome}' não encontrada no Windows ({exc}).")
        try:
            w.StartDocPrinter(h, 1, ("PetShop ERP", None, "RAW"))
            try:
                w.StartPagePrinter(h)
                w.WritePrinter(h, dados)
                w.EndPagePrinter(h)
            finally:
                w.EndDocPrinter(h)
        except Exception as exc:
            raise ImpressaoErro(f"Falha ao imprimir em '{nome}' ({exc}).")
        finally:
            w.ClosePrinter(h)
    elif conexao == "SERIAL":
        s = _pyserial()
        porta, velocidade = _serial(impressora.endereco)
        try:
            with s.Serial(porta, velocidade, timeout=TIMEOUT, write_timeout=TIMEOUT) as p:
                p.write(dados)
        except Exception as exc:
            raise ImpressaoErro(f"Falha na porta {porta} ({exc}).")
    elif conexao == "ARQUIVO":
        try:
            (pasta_arquivos() / f"{identificador}.bin").write_bytes(dados)
        except OSError as exc:
            raise ImpressaoErro(f"Não foi possível gravar o arquivo ({exc}).")
    else:
        raise ImpressaoErro(f"Conexão desconhecida: {conexao}.")


def testar_conexao(impressora):
    """(ok, mensagem) — só verifica se dá para falar com a impressora, sem imprimir."""
    try:
        conexao = impressora.conexao
        if conexao == "REDE":
            host, porta = _host_porta(impressora.endereco)
            try:
                socket.create_connection((host, porta), timeout=TIMEOUT).close()
            except OSError as exc:
                raise ImpressaoErro(f"Sem resposta de {host}:{porta} ({exc}).")
            return True, f"Respondendo em {host}:{porta}."
        if conexao == "WINDOWS":
            w = _win32print()
            nome = (impressora.endereco or "").strip() or w.GetDefaultPrinter()
            try:
                w.ClosePrinter(w.OpenPrinter(nome))
            except Exception as exc:
                raise ImpressaoErro(f"Impressora '{nome}' não encontrada no Windows ({exc}).")
            return True, f"Impressora '{nome}' encontrada no Windows."
        if conexao == "SERIAL":
            s = _pyserial()
            porta, velocidade = _serial(impressora.endereco)
            try:
                s.Serial(porta, velocidade, timeout=1).close()
            except Exception as exc:
                raise ImpressaoErro(f"Não abriu a porta {porta} ({exc}).")
            return True, f"Porta {porta} disponível."
        if conexao == "ARQUIVO":
            return True, f"Gravando em {pasta_arquivos()}."
        raise ImpressaoErro(f"Conexão desconhecida: {conexao}.")
    except ImpressaoErro as exc:
        return False, str(exc)
