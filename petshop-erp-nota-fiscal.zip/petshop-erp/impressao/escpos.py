"""
Gerador de comandos ESC/POS (sem Django, sem hardware).

Daruma, Elgin, Bematech e Epson térmicas falam o núcleo ESC/POS; as diferenças
(página de código, corte, gaveta) ficam em campos configuráveis da impressora.
Os valores padrão abaixo seguem o ESC/POS "de manual" e NÃO foram testados em
equipamento real: ajuste em Impressoras depois do teste de impressão.
"""

import textwrap
from dataclasses import dataclass

ESC = b"\x1b"
GS = b"\x1d"
LF = b"\n"

CORTE_GS_V = "GS_V"      # GS V 66 0: corte parcial com avanço (padrão)
CORTE_ESC_M = "ESC_M"    # ESC m: corte parcial (modelos antigos, ex.: Bematech)
CORTE_NENHUM = "NENHUM"


@dataclass
class Perfil:
    colunas: int = 48
    pagina_codigo: int = 3        # ESC t n: 3 = PC860 (português) na maioria
    codec: str = "cp860"
    corte: str = CORTE_GS_V
    pino_gaveta: int = 0          # ESC p m: 0 ou 1


class Documento:
    """Monta bytes ESC/POS e, junto, uma prévia em texto puro."""

    def __init__(self, perfil=None):
        self.perfil = perfil or Perfil()
        self._dados = bytearray()
        self._previa = []
        self._dados += ESC + b"@"  # inicializa
        self._dados += ESC + b"t" + bytes([self.perfil.pagina_codigo])

    # --- internos ---
    def _bytes(self, texto):
        return texto.encode(self.perfil.codec, errors="replace")

    @property
    def colunas(self):
        return self.perfil.colunas

    # --- formatação ---
    def alinhar(self, modo):
        """'esq', 'centro' ou 'dir'."""
        self._dados += ESC + b"a" + bytes([{"esq": 0, "centro": 1, "dir": 2}[modo]])
        return self

    def negrito(self, ligado=True):
        self._dados += ESC + b"E" + bytes([1 if ligado else 0])
        return self

    def tamanho(self, largura=1, altura=1):
        """1 a 8 vezes (GS ! n)."""
        largura, altura = max(1, min(8, largura)), max(1, min(8, altura))
        self._dados += GS + b"!" + bytes([((largura - 1) << 4) | (altura - 1)])
        return self

    def normal(self):
        return self.tamanho(1, 1).negrito(False).alinhar("esq")

    # --- conteúdo ---
    def texto(self, texto="", quebrar=True):
        linhas = [""]
        if texto:
            linhas = (
                textwrap.wrap(texto, self.colunas, break_long_words=True) or [""]
                if quebrar else [texto]
            )
        for linha in linhas:
            self._dados += self._bytes(linha) + LF
            self._previa.append(linha)
        return self

    def linha(self, caractere="-"):
        return self.texto(caractere * self.colunas, quebrar=False)

    def par(self, esquerda, direita):
        """Texto à esquerda e valor à direita na mesma linha (quebra se não couber)."""
        esquerda, direita = str(esquerda), str(direita)
        espaco = self.colunas - len(esquerda) - len(direita)
        if espaco >= 1:
            return self.texto(esquerda + " " * espaco + direita, quebrar=False)
        self.texto(esquerda)
        return self.alinhar("dir").texto(direita, quebrar=False).alinhar("esq")

    def avancar(self, linhas=1):
        self._dados += ESC + b"d" + bytes([max(0, min(255, linhas))])
        self._previa.extend([""] * linhas)
        return self

    def qrcode(self, conteudo, modulo=5, correcao="M"):
        """QR-Code nativo da impressora (GS ( k, modelo 2)."""
        dados = conteudo.encode("utf-8")
        if len(dados) > 700:
            raise ValueError("Conteúdo grande demais para o QR-Code.")
        nivel = {"L": 48, "M": 49, "Q": 50, "H": 51}[correcao]
        comprimento = len(dados) + 3
        self._dados += GS + b"(k" + bytes([4, 0, 49, 65, 50, 0])               # modelo 2
        self._dados += GS + b"(k" + bytes([3, 0, 49, 67, max(1, min(16, modulo))])  # tamanho
        self._dados += GS + b"(k" + bytes([3, 0, 49, 69, nivel])               # correção
        self._dados += GS + b"(k" + bytes([comprimento % 256, comprimento // 256, 49, 80, 48]) + dados
        self._dados += GS + b"(k" + bytes([3, 0, 49, 81, 48])                  # imprime
        self._previa.append("[QR-Code]")
        return self

    def ean13(self, codigo, altura=80):
        if not (codigo.isdigit() and len(codigo) in (12, 13)):
            raise ValueError("EAN-13 precisa de 12 ou 13 dígitos.")
        self._dados += GS + b"h" + bytes([altura]) + GS + b"w" + bytes([2]) + GS + b"H" + bytes([2])
        self._dados += GS + b"k" + bytes([67, len(codigo)]) + codigo.encode("ascii")
        self._previa.append(f"[EAN-13 {codigo}]")
        return self

    def code128(self, codigo, altura=80):
        dados = b"{B" + codigo.encode("ascii", errors="replace")
        self._dados += GS + b"h" + bytes([altura]) + GS + b"w" + bytes([2]) + GS + b"H" + bytes([2])
        self._dados += GS + b"k" + bytes([73, len(dados)]) + dados
        self._previa.append(f"[Code128 {codigo}]")
        return self

    # --- hardware ---
    def cortar(self):
        corte = self.perfil.corte
        if corte == CORTE_GS_V:
            self._dados += GS + b"V" + bytes([66, 0])
        elif corte == CORTE_ESC_M:
            self._dados += ESC + b"m"
        self._previa.append("-- corte --")
        return self

    def gaveta(self):
        """Pulso para abrir a gaveta (ESC p m t1 t2)."""
        self._dados += ESC + b"p" + bytes([self.perfil.pino_gaveta, 25, 250])
        self._previa.append("[abre gaveta]")
        return self

    # --- saída ---
    def bytes(self):
        return bytes(self._dados)

    def previa(self):
        return "\n".join(self._previa)
