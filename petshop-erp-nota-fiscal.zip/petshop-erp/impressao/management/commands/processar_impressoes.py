"""
Imprime os trabalhos que ficaram na fila (impressora desligada, sem papel, rede fora).

Uso:  python manage.py processar_impressoes             (uma vez)
      python manage.py processar_impressoes --continuo  (repete; para o Agendador de Tarefas)
"""

import time

from django.core.management.base import BaseCommand

from impressao import services


class Command(BaseCommand):
    help = "Tenta imprimir os trabalhos pendentes da fila de impressão."

    def add_arguments(self, parser):
        parser.add_argument("--continuo", action="store_true", help="repete a cada --intervalo segundos")
        parser.add_argument("--intervalo", type=int, default=5)

    def handle(self, *args, **opcoes):
        while True:
            impressos, falhas = services.processar_fila()
            if impressos or falhas:
                self.stdout.write(f"Impressos: {impressos} | com falha: {falhas}")
            if not opcoes["continuo"]:
                break
            time.sleep(max(2, opcoes["intervalo"]))
