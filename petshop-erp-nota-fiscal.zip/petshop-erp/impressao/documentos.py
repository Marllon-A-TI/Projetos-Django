"""
Layouts de impressão (cupom, DANFE NFC-e, recibo, pedido, etiqueta, senha,
comprovante de caixa). Recebem dados simples e devolvem um Documento ESC/POS.
Sem Django: testáveis sem banco e sem impressora.
"""

from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal

from lxml import etree

from .escpos import Documento, Perfil

NS = {"n": "http://www.portalfiscal.inf.br/nfe"}
TPAG = {"01": "Dinheiro", "02": "Cheque", "03": "Cartao de credito", "04": "Cartao de debito",
        "17": "PIX", "99": "Outros"}


def moeda(valor):
    valor = Decimal(valor).quantize(Decimal("0.01"))
    inteiro, _, fracao = f"{valor:.2f}".partition(".")
    inteiro = f"{int(inteiro):,}".replace(",", ".")
    return f"R$ {inteiro},{fracao}"


@dataclass
class Loja:
    nome: str
    cnpj: str = ""
    inscricao_estadual: str = ""
    endereco: str = ""
    telefone: str = ""


@dataclass
class LinhaItem:
    descricao: str
    quantidade: Decimal
    preco: Decimal
    unidade: str = "UN"
    codigo: str = ""

    @property
    def total(self):
        return (self.quantidade * self.preco).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass
class DadosCupom:
    loja: Loja
    numero: str
    data_hora: str
    operador: str
    itens: list
    total: Decimal
    pagamentos: list = field(default_factory=list)  # [(rótulo, valor)]
    troco: Decimal = Decimal("0.00")


def _cabecalho_loja(doc, loja):
    doc.alinhar("centro").negrito(True).texto(loja.nome).negrito(False)
    if loja.cnpj:
        doc.texto(f"CNPJ {loja.cnpj}" + (f"  IE {loja.inscricao_estadual}" if loja.inscricao_estadual else ""))
    if loja.endereco:
        doc.texto(loja.endereco)
    if loja.telefone:
        doc.texto(f"Tel {loja.telefone}")
    doc.alinhar("esq")


def _itens(doc, itens):
    for n, item in enumerate(itens, start=1):
        doc.texto(f"{n:02d} {item.descricao}")
        doc.par(f"   {item.quantidade:g} {item.unidade} x {moeda(item.preco)}", moeda(item.total))


def cupom_nao_fiscal(d: DadosCupom, perfil: Perfil, gaveta=False):
    doc = Documento(perfil)
    if gaveta:
        doc.gaveta()
    _cabecalho_loja(doc, d.loja)
    doc.linha().alinhar("centro").negrito(True).texto("CUPOM NAO FISCAL").negrito(False)
    doc.texto("Sem valor fiscal").alinhar("esq").linha()
    doc.texto(f"Venda #{d.numero}  {d.data_hora}").texto(f"Operador: {d.operador}").linha()
    _itens(doc, d.itens)
    doc.linha().negrito(True).tamanho(1, 2).par("TOTAL", moeda(d.total)).normal()
    for rotulo, valor in d.pagamentos:
        doc.par(rotulo, moeda(valor))
    if d.troco:
        doc.par("Troco", moeda(d.troco))
    doc.linha().alinhar("centro").texto("Obrigado pela preferencia!").avancar(3).cortar()
    return doc


@dataclass
class DadosDanfe:
    loja: Loja
    numero: str
    serie: str
    emissao: str
    chave: str
    protocolo: str
    data_autorizacao: str
    itens: list
    total: Decimal
    pagamentos: list
    troco: Decimal
    qrcode: str
    url_consulta: str
    homologacao: bool
    contingencia: bool
    autorizada: bool


def chave_formatada(chave):
    return " ".join(chave[i:i + 4] for i in range(0, len(chave), 4))


def danfe_nfce(d: DadosDanfe, perfil: Perfil, gaveta=False):
    """DANFE NFC-e (documento auxiliar), formato bobina, conforme o leiaute da NFC-e."""
    doc = Documento(perfil)
    if gaveta:
        doc.gaveta()
    _cabecalho_loja(doc, d.loja)
    doc.linha().alinhar("centro").negrito(True)
    doc.texto("DANFE NFC-e - Documento Auxiliar da Nota Fiscal de Consumidor Eletronica").negrito(False)
    if d.homologacao:
        doc.negrito(True).texto("EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL").negrito(False)
    if d.contingencia and not d.autorizada:
        doc.negrito(True).texto("EMITIDA EM CONTINGENCIA - Pendente de autorizacao").negrito(False)
    doc.alinhar("esq").linha()
    for n, item in enumerate(d.itens, start=1):
        doc.texto(f"{n:03d} {item.codigo} {item.descricao}".replace("  ", " "))
        doc.par(f"    {item.quantidade:g} {item.unidade} x {item.preco:.2f}", f"{item.total:.2f}")
    doc.linha()
    doc.par("Qtd. total de itens", str(len(d.itens)))
    doc.negrito(True).par("VALOR TOTAL R$", f"{d.total:.2f}").negrito(False)
    doc.texto("FORMA DE PAGAMENTO / VALOR PAGO")
    for rotulo, valor in d.pagamentos:
        doc.par(rotulo, f"{valor:.2f}")
    if d.troco:
        doc.par("Troco", f"{d.troco:.2f}")
    doc.linha().alinhar("centro")
    doc.texto(f"NFC-e n {d.numero} Serie {d.serie}  {d.emissao}")
    doc.texto("Consulte pela Chave de Acesso em")
    doc.texto(d.url_consulta, quebrar=True)
    doc.texto(chave_formatada(d.chave))
    doc.linha().texto("CONSUMIDOR NAO IDENTIFICADO").avancar(1)
    if d.qrcode:
        doc.qrcode(d.qrcode, modulo=4)
    if d.autorizada:
        doc.texto(f"Protocolo de autorizacao: {d.protocolo}").texto(d.data_autorizacao)
    doc.avancar(3).cortar()
    return doc


def recibo(loja: Loja, numero, data_hora, valor, referente, pagador="", perfil=None):
    doc = Documento(perfil or Perfil())
    _cabecalho_loja(doc, loja)
    doc.linha().alinhar("centro").negrito(True).texto(f"RECIBO N {numero}").negrito(False).alinhar("esq")
    doc.texto(data_hora).linha().tamanho(1, 2).par("VALOR", moeda(valor)).normal()
    doc.texto(f"Recebi de: {pagador or '-'}").texto(f"Referente a: {referente}")
    doc.avancar(3).linha().alinhar("centro").texto("Assinatura").avancar(3).cortar()
    return doc


def pedido(loja: Loja, numero, data_hora, itens, operador, observacao="", perfil=None):
    """Pedido interno/separação: itens em destaque, sem valores."""
    doc = Documento(perfil or Perfil())
    doc.alinhar("centro").negrito(True).tamanho(2, 2).texto(f"PEDIDO {numero}").normal()
    doc.texto(loja.nome).texto(data_hora).texto(f"Atendente: {operador}").alinhar("esq").linha()
    for item in itens:
        doc.negrito(True).texto(f"{item.quantidade:g} {item.unidade}  {item.descricao}").negrito(False)
    if observacao:
        doc.linha().texto(f"Obs: {observacao}")
    doc.avancar(3).cortar()
    return doc


def etiqueta(nome, preco, codigo_barras="", perfil=None):
    """Etiqueta de gôndola em impressora térmica ESC/POS (rolo comum)."""
    doc = Documento(perfil or Perfil())
    doc.alinhar("centro").negrito(True).texto(nome[:60]).negrito(False)
    doc.tamanho(2, 2).texto(moeda(preco)).normal().alinhar("centro")
    if codigo_barras.isdigit() and len(codigo_barras) in (12, 13):
        doc.ean13(codigo_barras)
    elif codigo_barras:
        doc.code128(codigo_barras)
    doc.avancar(2).cortar()
    return doc


def senha(loja: Loja, numero, data_hora, perfil=None):
    doc = Documento(perfil or Perfil())
    doc.alinhar("centro").texto(loja.nome).texto("SENHA DE ATENDIMENTO").tamanho(6, 6)
    doc.texto(f"{int(numero):03d}", quebrar=False).normal().alinhar("centro")
    doc.texto(data_hora).avancar(3).cortar()
    return doc


def comprovante_caixa(loja: Loja, titulo, linhas, data_hora, operador, perfil=None):
    """Comprovante de fechamento/sangria/suprimento. `linhas` = [(rótulo, texto)]."""
    doc = Documento(perfil or Perfil())
    _cabecalho_loja(doc, loja)
    doc.linha().alinhar("centro").negrito(True).texto(titulo).negrito(False).alinhar("esq")
    doc.texto(data_hora).texto(f"Operador: {operador}").linha()
    for rotulo, valor in linhas:
        doc.par(rotulo, valor)
    doc.avancar(3).linha().alinhar("centro").texto("Assinatura do responsavel").avancar(3).cortar()
    return doc


def teste(nome_impressora, perfil=None):
    doc = Documento(perfil or Perfil())
    doc.alinhar("centro").negrito(True).texto("TESTE DE IMPRESSAO").negrito(False)
    doc.texto(nome_impressora).alinhar("esq").linha()
    doc.texto("Acentuacao: ação, coração, órgão, pé, açúcar, ÇÃÕ")
    doc.texto("1234567890" * 5, quebrar=False).linha().qrcode("https://exemplo.com.br/teste")
    doc.avancar(3).cortar()
    return doc


def abrir_gaveta(perfil=None):
    return Documento(perfil or Perfil()).gaveta()


def dados_danfe_do_xml(xml_texto, loja, protocolo="", data_autorizacao="", autorizada=False):
    """Monta DadosDanfe lendo o XML da nota (o que foi enviado é o que se imprime)."""
    raiz = etree.fromstring(xml_texto.encode("utf-8"))

    def t(el, caminho, padrao=""):
        achado = el.find(caminho, NS)
        return (achado.text or "").strip() if achado is not None else padrao

    inf = next(iter(raiz.iter("{%s}infNFe" % NS["n"])))
    itens = []
    for det in inf.findall("n:det", NS):
        prod = det.find("n:prod", NS)
        itens.append(LinhaItem(
            descricao=t(prod, "n:xProd"), quantidade=Decimal(t(prod, "n:qCom", "0")),
            preco=Decimal(t(prod, "n:vUnCom", "0")), unidade=t(prod, "n:uCom", "UN"),
            codigo=t(prod, "n:cProd"),
        ))
    pagamentos = [
        (TPAG.get(t(p, "n:tPag"), "Outros"), Decimal(t(p, "n:vPag", "0")))
        for p in inf.findall("n:pag/n:detPag", NS)
    ]
    chave = inf.get("Id", "")[3:]
    qr = next(iter(raiz.iter("{%s}qrCode" % NS["n"])), None)
    url_chave = next(iter(raiz.iter("{%s}urlChave" % NS["n"])), None)
    ide = inf.find("n:ide", NS)
    return DadosDanfe(
        loja=loja, numero=t(ide, "n:nNF"), serie=t(ide, "n:serie"),
        emissao=t(ide, "n:dhEmi").replace("T", " ")[:19], chave=chave, protocolo=protocolo,
        data_autorizacao=data_autorizacao, itens=itens,
        total=Decimal(t(inf, "n:total/n:ICMSTot/n:vNF", "0")), pagamentos=pagamentos,
        troco=Decimal(t(inf, "n:pag/n:vTroco", "0")),
        qrcode=(qr.text or "") if qr is not None else "",
        url_consulta=(url_chave.text or "") if url_chave is not None else "",
        homologacao=t(ide, "n:tpAmb") == "2", contingencia=t(ide, "n:tpEmis") == "9",
        autorizada=autorizada,
    )
