from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.core.exceptions import ValidationError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse, reverse_lazy
from django.views import View
from django.views.generic import CreateView, DetailView, ListView, UpdateView

from core.mixins import AdministradorRequiredMixin, VendedorOuAdministradorRequiredMixin, eh_administrador
from fiscal.models import DocumentoFiscal
from logs.models import LogAcao
from logs.utils import LogFormValidMixin, registrar_acao
from pdv.models import SessaoCaixa
from pdv.services import resumo_sessao
from produtos.models import Produto
from vendas.models import Venda

from . import services
from .forms import EtiquetaForm, ImpressoraForm
from .models import Impressora, TrabalhoImpressao

Status = TrabalhoImpressao.Status


def _voltar(request, padrao):
    destino = request.POST.get("next", "")
    if destino.startswith("/") and not destino.startswith("//"):
        return redirect(destino)
    return redirect(padrao)


def _relatar(request, trabalho, sucesso):
    """Mensagem única para o resultado de um trabalho de impressão."""
    if trabalho.status == Status.IMPRESSO:
        messages.success(request, sucesso)
    elif trabalho.status == Status.ERRO:
        messages.error(request, f"Não imprimiu: {trabalho.erro}")
    else:
        messages.warning(
            request, f"Impressora indisponível ({trabalho.erro or 'sem resposta'}). "
                     "O trabalho ficou na fila e será tentado de novo."
        )


# --- Impressoras (somente administrador) ---------------------------------

class ImpressoraListView(AdministradorRequiredMixin, View):
    def get(self, request):
        return render(request, "impressao/impressora_list.html", {"linhas": services.monitorar()})


class ImpressoraCreateView(AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, CreateView):
    model = Impressora
    form_class = ImpressoraForm
    template_name = "impressao/impressora_form.html"
    success_url = reverse_lazy("impressao:impressora_list")
    success_message = "Impressora cadastrada. Faça um teste de impressão."
    acao_log = LogAcao.Acao.CRIACAO
    prefixo_log = "Impressora criada: "
    extra_context = {"titulo": "Nova impressora"}


class ImpressoraUpdateView(AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, UpdateView):
    model = Impressora
    form_class = ImpressoraForm
    template_name = "impressao/impressora_form.html"
    success_url = reverse_lazy("impressao:impressora_list")
    success_message = "Impressora atualizada."
    acao_log = LogAcao.Acao.EDICAO
    prefixo_log = "Impressora editada: "
    extra_context = {"titulo": "Editar impressora"}


class ImpressoraTestarView(AdministradorRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request, pk):
        impressora = get_object_or_404(Impressora, pk=pk)
        trabalho = services.imprimir_teste(impressora, request.user)
        registrar_acao(request, LogAcao.Acao.IMPRESSAO,
                       f"Teste de impressão em {impressora.nome}: {trabalho.get_status_display()}")
        _relatar(request, trabalho, "Teste enviado à impressora.")
        return redirect("impressao:impressora_list")


class ImpressoraVerificarView(AdministradorRequiredMixin, View):
    """Verifica a comunicação de uma impressora (ou de todas) sem imprimir."""

    http_method_names = ["post"]

    def post(self, request, pk=None):
        alvo = Impressora.objects.filter(ativo=True)
        if pk is not None:
            alvo = alvo.filter(pk=pk)
        for impressora in alvo:
            ok, detalhe = services.verificar(impressora)
            (messages.success if ok else messages.error)(request, f"{impressora.nome}: {detalhe}")
        return redirect("impressao:impressora_list")


# --- Fila ---------------------------------------------------------------

class TrabalhoListView(VendedorOuAdministradorRequiredMixin, ListView):
    template_name = "impressao/trabalho_list.html"
    context_object_name = "trabalhos"
    paginate_by = 30

    def get_queryset(self):
        consulta = TrabalhoImpressao.objects.select_related("impressora", "usuario")
        if not eh_administrador(self.request.user):
            consulta = consulta.filter(usuario=self.request.user)
        situacao = self.request.GET.get("situacao", "")
        if situacao in Status.values:
            consulta = consulta.filter(status=situacao)
        return consulta

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["situacao"] = self.request.GET.get("situacao", "")
        contexto["situacoes"] = Status.choices
        return contexto


class _TrabalhoMixin:
    def get_queryset(self):
        consulta = TrabalhoImpressao.objects.select_related("impressora", "usuario", "venda")
        if not eh_administrador(self.request.user):
            consulta = consulta.filter(usuario=self.request.user)
        return consulta


class TrabalhoDetailView(_TrabalhoMixin, VendedorOuAdministradorRequiredMixin, DetailView):
    template_name = "impressao/trabalho_detail.html"
    context_object_name = "trabalho"


class _TrabalhoAcaoView(_TrabalhoMixin, VendedorOuAdministradorRequiredMixin, View):
    http_method_names = ["post"]
    descricao = ""

    def executar(self, request, trabalho):  # pragma: no cover
        raise NotImplementedError

    def post(self, request, pk):
        trabalho = get_object_or_404(self.get_queryset(), pk=pk)
        try:
            resultado = self.executar(request, trabalho)
        except ValidationError as erro:
            for texto in erro.messages:
                messages.error(request, texto)
        else:
            registrar_acao(request, LogAcao.Acao.IMPRESSAO,
                           f"{self.descricao} do trabalho #{trabalho.pk} ({trabalho.titulo}): "
                           f"{resultado.get_status_display()}")
            _relatar(request, resultado, f"{self.descricao}: concluída.")
        return _voltar(request, reverse("impressao:trabalho_detail", kwargs={"pk": pk}))


class TrabalhoReimprimirView(_TrabalhoAcaoView):
    descricao = "Reimpressão"

    def executar(self, request, trabalho):
        return services.reimprimir(trabalho, request.user)


class TrabalhoRetentarView(_TrabalhoAcaoView):
    descricao = "Nova tentativa"

    def executar(self, request, trabalho):
        return services.tentar_novamente(trabalho)


class TrabalhoCancelarView(_TrabalhoAcaoView):
    descricao = "Cancelamento"

    def executar(self, request, trabalho):
        return services.cancelar(trabalho)


class ProcessarFilaView(VendedorOuAdministradorRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request):
        impressos, falhas = services.processar_fila()
        messages.info(request, f"Fila processada: {impressos} impresso(s), {falhas} com falha.")
        return redirect("impressao:trabalho_list")


# --- Impressões a partir de outras telas ---------------------------------

class _ImprimirView(VendedorOuAdministradorRequiredMixin, View):
    http_method_names = ["post"]
    sucesso = "Enviado para a impressora."
    destino = "impressao:trabalho_list"

    def alvo(self, request, pk):  # pragma: no cover
        return None

    def executar(self, request, alvo):  # pragma: no cover
        raise NotImplementedError

    def post(self, request, pk=None):
        alvo = self.alvo(request, pk)
        try:
            resultado = self.executar(request, alvo)
        except ValidationError as erro:
            for texto in erro.messages:
                messages.error(request, texto)
        else:
            for trabalho in resultado if isinstance(resultado, list) else [resultado]:
                registrar_acao(request, LogAcao.Acao.IMPRESSAO,
                               f"{trabalho.titulo}: {trabalho.get_status_display()}")
            _relatar(request, resultado[-1] if isinstance(resultado, list) else resultado, self.sucesso)
        return _voltar(request, self.destino_url(pk))

    def destino_url(self, pk):
        return reverse(self.destino)


def _venda_visivel(request, pk):
    consulta = Venda.objects.select_related("vendedor")
    if not eh_administrador(request.user):
        consulta = consulta.filter(vendedor=request.user)
    return get_object_or_404(consulta, pk=pk)


class ImprimirCupomView(_ImprimirView):
    sucesso = "Cupom enviado para a impressora."

    def alvo(self, request, pk):
        return _venda_visivel(request, pk)

    def executar(self, request, venda):
        return services.imprimir_cupom(venda, request.user)

    def destino_url(self, pk):
        return reverse("vendas:detail", kwargs={"pk": pk})


class ImprimirPedidoView(ImprimirCupomView):
    sucesso = "Pedido enviado para a impressora."

    def executar(self, request, venda):
        return services.imprimir_pedido(venda, request.user, request.POST.get("observacao", "")[:100])


class ImprimirDanfeView(AdministradorRequiredMixin, _ImprimirView):
    sucesso = "DANFE enviado para a impressora."

    def alvo(self, request, pk):
        return get_object_or_404(DocumentoFiscal, pk=pk)

    def executar(self, request, documento):
        if documento.modelo != "65":
            raise ValidationError("A impressora térmica imprime só NFC-e. Para NF-e use o DANFE em PDF.")
        if documento.status not in ("AUTORIZADA", "ASSINADA"):
            raise ValidationError("Só dá para imprimir o DANFE de nota assinada ou autorizada.")
        return services.imprimir_danfe(documento, request.user)

    def destino_url(self, pk):
        return reverse("fiscal:documento_detail", kwargs={"pk": pk})


class ImprimirEtiquetaView(AdministradorRequiredMixin, _ImprimirView):
    sucesso = "Etiqueta enviada para a impressora."

    def alvo(self, request, pk):
        return get_object_or_404(Produto, pk=pk)

    def executar(self, request, produto):
        form = EtiquetaForm(request.POST)
        if not form.is_valid():
            raise ValidationError("Informe uma quantidade de cópias entre 1 e 100.")
        return services.imprimir_etiquetas(produto, request.user, form.cleaned_data["copias"])

    def destino_url(self, pk):
        return reverse("produtos:detail", kwargs={"pk": pk})


class ImprimirSenhaView(_ImprimirView):
    sucesso = "Senha impressa."
    destino = "pdv:painel"

    def executar(self, request, _):
        return services.imprimir_senha(request.user)


class AbrirGavetaView(_ImprimirView):
    sucesso = "Gaveta acionada."
    destino = "pdv:painel"

    def executar(self, request, _):
        return services.abrir_gaveta(request.user)


class ComprovanteCaixaView(_ImprimirView):
    sucesso = "Comprovante enviado para a impressora."

    def alvo(self, request, pk):
        consulta = SessaoCaixa.objects.select_related("operador")
        if not eh_administrador(request.user):
            consulta = consulta.filter(operador=request.user)
        return get_object_or_404(consulta, pk=pk)

    def executar(self, request, sessao):
        return services.imprimir_comprovante_caixa(sessao, resumo_sessao(sessao), request.user)

    def destino_url(self, pk):
        return reverse("pdv:sessao_detail", kwargs={"pk": pk})
