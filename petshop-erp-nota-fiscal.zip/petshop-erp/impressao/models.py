"""
Impressoras, fila de impressão e contador de senhas.

O conteúdo de cada trabalho (bytes ESC/POS + prévia em texto) é gravado no
momento em que o trabalho é criado: assim a reimpressão sai idêntica e uma
falha da impressora nunca impede a venda — o trabalho fica na fila.
"""

from django.conf import settings
from django.db import models
from django.db.models import Q

from core.models import ModeloBase, ModeloProtegido

from .escpos import CORTE_ESC_M, CORTE_GS_V, CORTE_NENHUM


class Impressora(ModeloBase, ModeloProtegido):
    class Finalidade(models.TextChoices):
        CUPOM = "CUPOM", "Cupom / notas / caixa"
        ETIQUETA = "ETIQUETA", "Etiquetas"

    class Conexao(models.TextChoices):
        REDE = "REDE", "Rede (IP:porta, normalmente 9100)"
        WINDOWS = "WINDOWS", "Impressora instalada no Windows (USB)"
        SERIAL = "SERIAL", "Porta serial (COM)"
        ARQUIVO = "ARQUIVO", "Arquivo (teste, sem impressora)"

    class Marca(models.TextChoices):
        GENERICA = "GENERICA", "Genérica ESC/POS"
        DARUMA = "DARUMA", "Daruma"
        ELGIN = "ELGIN", "Elgin"
        BEMATECH = "BEMATECH", "Bematech"
        EPSON = "EPSON", "Epson"

    class Situacao(models.TextChoices):
        DESCONHECIDA = "DESCONHECIDA", "Ainda não verificada"
        ONLINE = "ONLINE", "Online"
        OFFLINE = "OFFLINE", "Sem resposta"

    nome = models.CharField("nome", max_length=60, unique=True)
    finalidade = models.CharField("finalidade", max_length=10, choices=Finalidade.choices,
                                  default=Finalidade.CUPOM)
    marca = models.CharField("marca", max_length=10, choices=Marca.choices, default=Marca.GENERICA)
    conexao = models.CharField("conexão", max_length=10, choices=Conexao.choices)
    endereco = models.CharField(
        "endereço", max_length=150, blank=True,
        help_text="Rede: 192.168.0.50 ou 192.168.0.50:9100. Windows: nome exato da impressora. "
                  "Serial: COM3 ou COM3:9600. Arquivo: deixe em branco.",
    )
    colunas = models.PositiveSmallIntegerField(
        "colunas", default=48, help_text="Bobina 80 mm: 48 (ou 42). Bobina 58 mm: 32.")
    pagina_codigo = models.PositiveSmallIntegerField(
        "página de código (ESC t)", default=3,
        help_text="Acentos errados na impressão? Troque este número (veja o manual da marca).")
    codec = models.CharField("codificação", max_length=20, default="cp860")
    corte = models.CharField(
        "tipo de corte", max_length=8, default=CORTE_GS_V,
        choices=[(CORTE_GS_V, "Padrão (GS V)"), (CORTE_ESC_M, "Antigo (ESC m)"),
                 (CORTE_NENHUM, "Sem guilhotina")])
    tem_gaveta = models.BooleanField("tem gaveta de dinheiro ligada", default=False)
    pino_gaveta = models.PositiveSmallIntegerField("pino da gaveta", default=0,
                                                  help_text="0 ou 1. Se não abrir, tente o outro.")
    padrao = models.BooleanField("padrão da finalidade", default=False)
    ativo = models.BooleanField("ativa", default=True)
    situacao = models.CharField("situação", max_length=12, choices=Situacao.choices,
                                default=Situacao.DESCONHECIDA, editable=False)
    situacao_detalhe = models.CharField("detalhe", max_length=200, blank=True, default="", editable=False)
    verificada_em = models.DateTimeField("verificada em", null=True, blank=True, editable=False)

    class Meta:
        verbose_name = "impressora"
        verbose_name_plural = "impressoras"
        ordering = ["nome"]
        constraints = [
            models.UniqueConstraint(fields=["finalidade"], condition=Q(padrao=True),
                                    name="impressora_uma_padrao_por_finalidade"),
        ]

    def __str__(self):
        return self.nome


class TrabalhoImpressao(ModeloBase, ModeloProtegido):
    class Tipo(models.TextChoices):
        CUPOM = "CUPOM", "Cupom não fiscal"
        DANFE = "DANFE", "DANFE NFC-e"
        PEDIDO = "PEDIDO", "Pedido"
        ETIQUETA = "ETIQUETA", "Etiqueta"
        SENHA = "SENHA", "Senha"
        CAIXA = "CAIXA", "Comprovante de caixa"
        RECIBO = "RECIBO", "Recibo"
        GAVETA = "GAVETA", "Abrir gaveta"
        TESTE = "TESTE", "Teste"

    class Status(models.TextChoices):
        PENDENTE = "PENDENTE", "Na fila"
        IMPRESSO = "IMPRESSO", "Impresso"
        ERRO = "ERRO", "Falhou"
        CANCELADO = "CANCELADO", "Cancelado"

    impressora = models.ForeignKey(Impressora, on_delete=models.PROTECT, related_name="trabalhos",
                                   verbose_name="impressora")
    tipo = models.CharField("tipo", max_length=10, choices=Tipo.choices)
    titulo = models.CharField("título", max_length=150)
    conteudo = models.BinaryField("conteúdo ESC/POS", editable=False)
    previa = models.TextField("prévia", blank=True, default="")
    status = models.CharField("situação", max_length=10, choices=Status.choices,
                              default=Status.PENDENTE, db_index=True)
    tentativas = models.PositiveSmallIntegerField("tentativas", default=0)
    max_tentativas = models.PositiveSmallIntegerField("máximo de tentativas", default=5)
    proxima_tentativa = models.DateTimeField("próxima tentativa", null=True, blank=True)
    erro = models.TextField("último erro", blank=True, default="")
    impresso_em = models.DateTimeField("impresso em", null=True, blank=True)
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True,
                                blank=True, related_name="trabalhos_impressao", verbose_name="usuário")
    venda = models.ForeignKey("vendas.Venda", on_delete=models.PROTECT, null=True, blank=True,
                              related_name="trabalhos_impressao", verbose_name="venda")
    reimpressao_de = models.ForeignKey("self", on_delete=models.PROTECT, null=True, blank=True,
                                       related_name="reimpressoes", verbose_name="reimpressão de")

    class Meta:
        verbose_name = "trabalho de impressão"
        verbose_name_plural = "fila de impressão"
        ordering = ["-id"]
        indexes = [models.Index(fields=["status", "proxima_tentativa"], name="trabimp_status_prox_idx")]

    def __str__(self):
        return f"#{self.pk} {self.get_tipo_display()}: {self.titulo}"


class ContadorSenha(models.Model):
    """Última senha de atendimento emitida em cada dia (recomeça em 1)."""

    data = models.DateField("data", unique=True)
    ultimo = models.PositiveIntegerField("última senha", default=0)

    class Meta:
        verbose_name = "contador de senha"
        verbose_name_plural = "contadores de senha"
