from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.db import transaction
from django.db.models import ProtectedError
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views import View
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from core.mixins import (
    AdministradorRequiredMixin,
    FiltroListViewMixin,
    VendedorOuAdministradorRequiredMixin,
    eh_administrador,
)
from logs.models import LogAcao
from logs.utils import LogFormValidMixin, registrar_acao

from .forms import ProdutoFiltroForm, ProdutoForm
from .models import Produto


class ProdutoListView(
    VendedorOuAdministradorRequiredMixin, FiltroListViewMixin, ListView
):
    model = Produto
    template_name = "produtos/produto_list.html"
    context_object_name = "produtos"
    paginate_by = 25
    filtro_form_class = ProdutoFiltroForm

    def get_queryset(self):
        queryset = super().get_queryset()
        if not eh_administrador(self.request.user):
            queryset = queryset.filter(ativo=True)
        return queryset

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        contexto["eh_administrador"] = eh_administrador(self.request.user)
        return contexto


class ProdutoDetailView(VendedorOuAdministradorRequiredMixin, DetailView):
    model = Produto
    template_name = "produtos/produto_detail.html"
    context_object_name = "produto"

    def get_queryset(self):
        queryset = Produto.objects.all()
        if not eh_administrador(self.request.user):
            queryset = queryset.filter(ativo=True)
        return queryset

    def get_context_data(self, **kwargs):
        contexto = super().get_context_data(**kwargs)
        administrador = eh_administrador(self.request.user)
        contexto["eh_administrador"] = administrador
        if administrador:
            contexto["movimentacoes"] = self.object.movimentacoes.select_related(
                "usuario"
            )[:20]
        return contexto


class ProdutoCreateView(
    AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, CreateView
):
    model = Produto
    form_class = ProdutoForm
    template_name = "produtos/produto_form.html"
    success_message = "Produto cadastrado com sucesso."
    acao_log = LogAcao.Acao.CRIACAO
    prefixo_log = "Produto criado: "
    extra_context = {"titulo": "Novo produto"}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["usuario"] = self.request.user
        return kwargs

    def get_success_url(self):
        return reverse("produtos:detail", kwargs={"pk": self.object.pk})


class ProdutoUpdateView(
    AdministradorRequiredMixin, LogFormValidMixin, SuccessMessageMixin, UpdateView
):
    model = Produto
    form_class = ProdutoForm
    template_name = "produtos/produto_form.html"
    success_message = "Produto atualizado com sucesso."
    acao_log = LogAcao.Acao.EDICAO
    prefixo_log = "Produto editado: "
    extra_context = {"titulo": "Editar produto"}

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["usuario"] = self.request.user
        return kwargs

    def get_success_url(self):
        return reverse("produtos:detail", kwargs={"pk": self.object.pk})


class ProdutoAlternarAtivoView(AdministradorRequiredMixin, View):
    """Ativa ou desativa o produto (a forma segura de 'tirar de linha')."""

    http_method_names = ["post"]

    def post(self, request, pk):
        produto = get_object_or_404(Produto, pk=pk)
        produto.ativo = not produto.ativo
        situacao = "ativado" if produto.ativo else "desativado"

        with transaction.atomic():
            produto.save(update_fields=["ativo", "atualizado_em"])
            registrar_acao(
                request,
                LogAcao.Acao.EDICAO,
                f"Produto {situacao}: {produto} (#{produto.pk})",
            )

        messages.success(request, f"Produto {situacao}.")
        return redirect("produtos:detail", pk=produto.pk)


class ProdutoDeleteView(AdministradorRequiredMixin, DeleteView):
    model = Produto
    template_name = "produtos/produto_confirm_delete.html"
    success_url = reverse_lazy("produtos:list")

    def form_valid(self, form):
        pk = self.object.pk
        descricao = f"{self.object} (#{pk})"
        try:
            with transaction.atomic():
                resposta = super().form_valid(form)
                registrar_acao(
                    self.request,
                    LogAcao.Acao.EXCLUSAO,
                    f"Produto excluído: {descricao}",
                )
        except ProtectedError:
            messages.error(
                self.request,
                "Este produto tem movimentações ou vendas e não pode ser "
                "excluído. Desative-o.",
            )
            return redirect("produtos:detail", pk=pk)

        messages.success(self.request, "Produto excluído.")
        return resposta